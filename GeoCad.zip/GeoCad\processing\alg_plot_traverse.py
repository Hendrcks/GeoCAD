"""
GeoCad Processing Algorithm: Plot Lot Traverse.
Computes forward cadastral traverse linework and polygon from bearing and distance parameters.

Developed by GeoCad (geocad@example.com).
"""

from typing import Dict, Any

try:
    from qgis.core import (
        QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterString,
        QgsProcessingParameterNumber, QgsProcessingParameterCrs,
        QgsProcessingParameterFeatureSink, QgsFeature, QgsGeometry,
        QgsFields, QgsField, QgsWkbTypes
    )
    from qgis.PyQt.QtCore import QVariant
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm: pass

from ..core.compat import make_qgs_field
from ..core.traverse_engine import TraverseEngine
from ..core.ocr_reader import OcrTableReader


class PlotTraverseAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to plot a lot traverse."""

    LOT_NAME = "LOT_NAME"
    RECORDS_TEXT = "RECORDS_TEXT"
    START_EASTING = "START_EASTING"
    START_NORTHING = "START_NORTHING"
    CRS = "CRS"
    OUTPUT_POLYGON = "OUTPUT_POLYGON"

    def createInstance(self):
        return PlotTraverseAlgorithm()

    def name(self):
        return "plot_traverse"

    def displayName(self):
        return "Plot Lot Traverse (Bearing & Distance)"

    def group(self):
        return "Cadastral Traverse"

    def groupId(self):
        return "traverse"

    def shortHelpString(self):
        return (
            "Plots a closed or open cadastral survey traverse from multi-line bearing "
            "and distance text records (e.g. '1-2 N.28-38E. 246.48 M.')."
        )

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterString(self.LOT_NAME, "Lot Identifier", defaultValue="", optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.RECORDS_TEXT,
            "Traverse Records (From-To Bearing Distance)",
            multiLine=True,
            defaultValue="",
            optional=True
        ))
        self.addParameter(QgsProcessingParameterNumber(self.START_EASTING, "Start Easting (X)", type=QgsProcessingParameterNumber.Double, defaultValue=0.0, optional=True))
        self.addParameter(QgsProcessingParameterNumber(self.START_NORTHING, "Start Northing (Y)", type=QgsProcessingParameterNumber.Double, defaultValue=0.0, optional=True))
        self.addParameter(QgsProcessingParameterCrs(self.CRS, "Target CRS", defaultValue="EPSG:3124"))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT_POLYGON, "Lot Polygon Output", type=QgsProcessing.TypeVectorPolygon))

    def processAlgorithm(self, parameters, context, feedback):
        lot_no = self.parameterAsString(parameters, self.LOT_NAME, context)
        text = self.parameterAsString(parameters, self.RECORDS_TEXT, context)
        start_e = self.parameterAsDouble(parameters, self.START_EASTING, context)
        start_n = self.parameterAsDouble(parameters, self.START_NORTHING, context)
        crs = self.parameterAsCrs(parameters, self.CRS, context)

        rows = OcrTableReader.parse_text(text)
        legs_data = [{"from": r.from_pt, "to": r.to_pt, "bearing": r.bearing_raw, "distance": r.distance_val} for r in rows]

        res = TraverseEngine.compute_lot(
            lot_no=lot_no,
            legs_data=legs_data,
            start_coord=(start_e, start_n)
        )

        fields = QgsFields()
        fields.append(make_qgs_field("Lot_No", "string"))
        fields.append(make_qgs_field("Area_sqm", "double"))
        fields.append(make_qgs_field("Area_ha", "double"))
        fields.append(make_qgs_field("Perimeter", "double"))
        fields.append(make_qgs_field("Closure", "double"))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_POLYGON, context, fields, QgsWkbTypes.Polygon, crs
        )

        if res.wkt_polygon:
            feat = QgsFeature()
            feat.setGeometry(QgsGeometry.fromWkt(res.wkt_polygon))
            feat.setAttributes([res.lot_no, res.area_sqm, res.area_ha, res.perimeter, res.closure_error_dist])
            sink.addFeature(feat)

        return {self.OUTPUT_POLYGON: dest_id}

