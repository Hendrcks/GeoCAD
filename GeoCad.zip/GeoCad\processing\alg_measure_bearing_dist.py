"""
GeoCad Processing Algorithm: Annotate Bearings and Distances.
Measures vector linework segments and generates surveyor quadrant bearings and distances.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.core import (
        QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer,
        QgsProcessingParameterEnum, QgsProcessingParameterBoolean,
        QgsProcessingParameterNumber, QgsProcessingParameterFeatureSink,
        QgsFeature, QgsGeometry, QgsPointXY, QgsFields, QgsField, QgsWkbTypes
    )
    from qgis.PyQt.QtCore import QVariant
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm: pass

from ..core.compat import make_qgs_field
from ..core.bearing_distance_annotator import BearingDistanceAnnotator


class AnnotateBearingDistanceAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to measure bearings and distances."""

    INPUT_LAYER = "INPUT_LAYER"
    MODE = "MODE"
    UNIT = "UNIT"
    REVERSE = "REVERSE"
    TEXT_HEIGHT = "TEXT_HEIGHT"
    OUTPUT_ANNOTATIONS = "OUTPUT_ANNOTATIONS"

    def createInstance(self):
        return AnnotateBearingDistanceAlgorithm()

    def name(self):
        return "measure_bearings_distances"

    def displayName(self):
        return "Annotate Line Bearings & Distances"

    def group(self):
        return "Annotation"

    def groupId(self):
        return "annotation"

    def shortHelpString(self):
        return "Computes surveyor bearings and distances (Meters or Feet) with 8 placement configurations."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT_LAYER, "Input Linework Layer", types=[QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterEnum(self.MODE, "Placement Configuration", options=BearingDistanceAnnotator.MODES, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(self.UNIT, "Distance Unit", options=["Meters", "Feet"], defaultValue=0))
        self.addParameter(QgsProcessingParameterBoolean(self.REVERSE, "Reverse Vector Direction", defaultValue=False))
        self.addParameter(QgsProcessingParameterNumber(self.TEXT_HEIGHT, "Text Height (map units)", type=QgsProcessingParameterNumber.Double, defaultValue=2.5))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT_ANNOTATIONS, "Annotation Points Output", type=QgsProcessing.TypeVectorPoint))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT_LAYER, context)
        mode_idx = self.parameterAsEnum(parameters, self.MODE, context)
        mode = BearingDistanceAnnotator.MODES[mode_idx]
        unit = "Meters" if self.parameterAsEnum(parameters, self.UNIT, context) == 0 else "Feet"
        reverse = self.parameterAsBoolean(parameters, self.REVERSE, context)
        th = self.parameterAsDouble(parameters, self.TEXT_HEIGHT, context)

        fields = QgsFields()
        fields.append(make_qgs_field("Seg_ID", "int"))
        fields.append(make_qgs_field("Bearing", "string"))
        fields.append(make_qgs_field("Distance", "string"))
        fields.append(make_qgs_field("Text_Left", "string"))
        fields.append(make_qgs_field("Text_Right", "string"))
        fields.append(make_qgs_field("Rotation_Deg", "double"))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_ANNOTATIONS, context, fields, QgsWkbTypes.Point, layer.crs()
        )

        seg_id = 1
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
            for line in lines:
                for i in range(len(line) - 1):
                    p1 = (line[i].x(), line[i].y())
                    p2 = (line[i+1].x(), line[i+1].y())
                    ann = BearingDistanceAnnotator.annotate_segment(
                        p1, p2, mode=mode, unit=unit, reverse_direction=reverse, text_height=th, segment_id=seg_id
                    )
                    if ann:
                        f = QgsFeature()
                        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ann.midpoint[0], ann.midpoint[1])))
                        f.setAttributes([ann.segment_id, ann.bearing_str, ann.distance_str, ann.text_left, ann.text_right, ann.text_angle_deg])
                        sink.addFeature(f)
                        seg_id += 1

        return {self.OUTPUT_ANNOTATIONS: dest_id}

