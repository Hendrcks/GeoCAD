"""
GeoCad Core Engineering & Algorithm Engine.
Developed by GeoCad (geocad@example.com).
"""

from .compat import (
    HEADER_RESIZE_TO_CONTENTS,
    HEADER_STRETCH,
    HEADER_FIXED,
    HEADER_INTERACTIVE,
    ALIGN_CENTER,
    ALIGN_RIGHT,
    ALIGN_LEFT,
    ALIGN_VCENTER,
    ALIGN_RIGHT_VCENTER,
    ALIGN_LEFT_VCENTER,
    FRAME_HLINE,
    FRAME_VLINE,
    FRAME_SUNKEN,
    FIELD_TYPE_STRING,
    FIELD_TYPE_DOUBLE,
    FIELD_TYPE_INT,
    FIELD_TYPE_BOOL,
    make_qgs_field,
    exec_dialog,
)
from .bearing_parser import BearingParser
from .traverse_engine import TraverseEngine, LotTraverseResult
from .point_plotter import PointPlotter
from .bearing_distance_annotator import BearingDistanceAnnotator
from .grid_generator import SurveyGridGenerator
from .tin_engine import TinEngine, TinReport
from .contour_engine import ContourEngine
from .ocr_reader import OcrTableReader

__all__ = [
    "HEADER_RESIZE_TO_CONTENTS",
    "HEADER_STRETCH",
    "HEADER_FIXED",
    "HEADER_INTERACTIVE",
    "ALIGN_CENTER",
    "ALIGN_RIGHT",
    "ALIGN_LEFT",
    "ALIGN_VCENTER",
    "ALIGN_RIGHT_VCENTER",
    "ALIGN_LEFT_VCENTER",
    "FRAME_HLINE",
    "FRAME_VLINE",
    "FRAME_SUNKEN",
    "FIELD_TYPE_STRING",
    "FIELD_TYPE_DOUBLE",
    "FIELD_TYPE_INT",
    "FIELD_TYPE_BOOL",
    "make_qgs_field",
    "exec_dialog",
    "BearingParser",
    "TraverseEngine",
    "LotTraverseResult",
    "PointPlotter",
    "BearingDistanceAnnotator",
    "SurveyGridGenerator",
    "TinEngine",
    "TinReport",
    "ContourEngine",
    "OcrTableReader",
]
