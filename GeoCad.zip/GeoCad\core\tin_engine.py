"""
GeoCad - Triangulated Irregular Network (TIN) Surface Modeling Engine.
Implements 2.5D Delaunay Triangulation (Bowyer-Watson algorithm in pure Python
with SciPy fallback) and comprehensive 3D terrain surface analytics (tininf).

Developed by GeoCad (geocad@example.com).
"""

import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Any


@dataclass
class TinTriangle:
    """A single 3D triangular facet in the TIN."""
    id: int
    v1: Tuple[float, float, float]
    v2: Tuple[float, float, float]
    v3: Tuple[float, float, float]
    area_2d: float = 0.0
    area_3d: float = 0.0
    slope_deg: float = 0.0
    aspect_deg: float = 0.0


@dataclass
class TinReport:
    """Comprehensive terrain statistics report (tininf)."""
    surface_name: str
    vertex_count: int = 0
    triangle_count: int = 0
    min_z: float = 0.0
    max_z: float = 0.0
    mean_z: float = 0.0
    elevation_range: float = 0.0
    area_2d_sqm: float = 0.0
    area_2d_ha: float = 0.0
    area_3d_sqm: float = 0.0
    area_3d_ha: float = 0.0
    mean_slope_deg: float = 0.0
    max_slope_deg: float = 0.0

    def summary_text(self) -> str:
        """Generates a formatted report summary."""
        return (
            f"=== GeoCad TIN Surface Report: {self.surface_name} ===\n"
            f"Total Vertices: {self.vertex_count}\n"
            f"Total Triangles: {self.triangle_count}\n"
            f"Elevation Minimum: {self.min_z:.3f} m\n"
            f"Elevation Maximum: {self.max_z:.3f} m\n"
            f"Elevation Mean: {self.mean_z:.3f} m\n"
            f"Elevation Relief Range: {self.elevation_range:.3f} m\n"
            f"2D Projected Planimetric Area: {self.area_2d_sqm:,.2f} sq.m ({self.area_2d_ha:.4f} ha)\n"
            f"3D True Surface Area: {self.area_3d_sqm:,.2f} sq.m ({self.area_3d_ha:.4f} ha)\n"
            f"Mean Slope Gradient: {self.mean_slope_deg:.2f}°\n"
            f"Max Slope Gradient: {self.max_slope_deg:.2f}°\n"
        )


class TinEngine:
    """Constructs Delaunay TIN surfaces and computes terrain statistics."""

    @classmethod
    def build_tin(
        cls,
        points: List[Tuple[float, float, float]],
        surface_name: str = "TIN_Surface"
    ) -> Tuple[List[TinTriangle], TinReport]:
        """Constructs a Delaunay TIN from 3D points.

        :param points: List of (X, Y, Z) tuples
        :param surface_name: Name of the surface
        """
        if len(points) < 3:
            report = TinReport(surface_name=surface_name)
            return [], report

        # Try SciPy Delaunay first if available
        tri_indices = cls._triangulate_scipy(points)
        if tri_indices is None:
            # Fallback to pure-Python Bowyer-Watson Delaunay
            tri_indices = cls._triangulate_bowyer_watson(points)

        triangles: List[TinTriangle] = []
        tot_2d_area = 0.0
        tot_3d_area = 0.0
        slopes: List[float] = []

        for tid, (i1, i2, i3) in enumerate(tri_indices):
            p1 = points[i1]
            p2 = points[i2]
            p3 = points[i3]

            # 2D Area
            a2d = abs((p1[0] * (p2[1] - p3[1]) + p2[0] * (p3[1] - p1[1]) + p3[0] * (p1[1] - p2[1])) * 0.5)

            # 3D Normal Vector: (P2 - P1) x (P3 - P1)
            u = (p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2])
            v = (p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2])
            nx = (u[1] * v[2]) - (u[2] * v[1])
            ny = (u[2] * v[0]) - (u[0] * v[2])
            nz = (u[0] * v[1]) - (u[1] * v[0])
            norm_mag = math.hypot(math.hypot(nx, ny), nz)
            a3d = norm_mag * 0.5

            # Slope: angle between normal vector and positive Z axis (0, 0, 1)
            # cos(theta) = nz / norm_mag
            if norm_mag > 1e-9:
                cos_slope = max(-1.0, min(1.0, abs(nz) / norm_mag))
                slope_deg = math.degrees(math.acos(cos_slope))
                aspect_deg = (math.degrees(math.atan2(nx, ny)) + 360.0) % 360.0
            else:
                slope_deg = 0.0
                aspect_deg = 0.0

            tri = TinTriangle(
                id=tid + 1,
                v1=p1,
                v2=p2,
                v3=p3,
                area_2d=a2d,
                area_3d=a3d,
                slope_deg=slope_deg,
                aspect_deg=aspect_deg
            )
            triangles.append(tri)
            tot_2d_area += a2d
            tot_3d_area += a3d
            slopes.append(slope_deg)

        z_vals = [p[2] for p in points]
        min_z = min(z_vals)
        max_z = max(z_vals)
        mean_z = sum(z_vals) / len(z_vals)

        mean_slope = sum(slopes) / len(slopes) if slopes else 0.0
        max_slope = max(slopes) if slopes else 0.0

        report = TinReport(
            surface_name=surface_name,
            vertex_count=len(points),
            triangle_count=len(triangles),
            min_z=min_z,
            max_z=max_z,
            mean_z=mean_z,
            elevation_range=max_z - min_z,
            area_2d_sqm=tot_2d_area,
            area_2d_ha=tot_2d_area / 10000.0,
            area_3d_sqm=tot_3d_area,
            area_3d_ha=tot_3d_area / 10000.0,
            mean_slope_deg=mean_slope,
            max_slope_deg=max_slope
        )

        return triangles, report

    @classmethod
    def _triangulate_scipy(cls, points: List[Tuple[float, float, float]]) -> Optional[List[Tuple[int, int, int]]]:
        """Tries to use scipy.spatial.Delaunay if available."""
        try:
            from scipy.spatial import Delaunay
            import numpy as np
            coords_2d = np.array([(p[0], p[1]) for p in points])
            tri = Delaunay(coords_2d)
            return [tuple(simplex) for simplex in tri.simplices]
        except Exception:
            return None

    @classmethod
    def _triangulate_bowyer_watson(cls, points: List[Tuple[float, float, float]]) -> List[Tuple[int, int, int]]:
        """Pure-Python Bowyer-Watson Delaunay Triangulation algorithm in 2D."""
        n = len(points)
        if n < 3:
            return []

        # Find bounds
        min_x = min(p[0] for p in points)
        max_x = max(p[0] for p in points)
        min_y = min(p[1] for p in points)
        max_y = max(p[1] for p in points)

        dx = max_x - min_x
        dy = max_y - min_y
        delta_max = max(dx, dy, 1.0)
        mid_x = (min_x + max_x) * 0.5
        mid_y = (min_y + max_y) * 0.5

        # Create super-triangle containing all points
        st_p1 = (mid_x - (20.0 * delta_max), mid_y - delta_max, 0.0)
        st_p2 = (mid_x, mid_y + (20.0 * delta_max), 0.0)
        st_p3 = (mid_x + (20.0 * delta_max), mid_y - delta_max, 0.0)

        all_pts = list(points) + [st_p1, st_p2, st_p3]
        st_i1, st_i2, st_i3 = n, n + 1, n + 2

        # Triangles store tuples: (i1, i2, i3)
        triangles: List[Tuple[int, int, int]] = [(st_i1, st_i2, st_i3)]

        for p_idx in range(n):
            pt = all_pts[p_idx]
            bad_triangles = []

            for tri in triangles:
                if cls._in_circumcircle(pt, all_pts[tri[0]], all_pts[tri[1]], all_pts[tri[2]]):
                    bad_triangles.append(tri)

            # Find boundary of polygonal hole
            polygon_edges = []
            for tri in bad_triangles:
                edges = [
                    (tri[0], tri[1]),
                    (tri[1], tri[2]),
                    (tri[2], tri[0])
                ]
                for edge in edges:
                    shared = False
                    for other in bad_triangles:
                        if other == tri:
                            continue
                        other_edges = [
                            (other[0], other[1]),
                            (other[1], other[2]),
                            (other[2], other[0]),
                            (other[1], other[0]),
                            (other[2], other[1]),
                            (other[0], other[2])
                        ]
                        if edge in other_edges:
                            shared = True
                            break
                    if not shared:
                        polygon_edges.append(edge)

            # Remove bad triangles
            triangles = [t for t in triangles if t not in bad_triangles]

            # Retriangulate the polygonal hole with the new point
            for edge in polygon_edges:
                triangles.append((edge[0], edge[1], p_idx))

        # Remove triangles that share vertices with the super-triangle
        final_triangles = []
        for tri in triangles:
            if st_i1 in tri or st_i2 in tri or st_i3 in tri:
                continue
            final_triangles.append(tri)

        return final_triangles

    @staticmethod
    def _in_circumcircle(
        p: Tuple[float, float, float],
        a: Tuple[float, float, float],
        b: Tuple[float, float, float],
        c: Tuple[float, float, float]
    ) -> bool:
        """Determines if 2D point P lies inside circumcircle of triangle ABC."""
        ax, ay = a[0] - p[0], a[1] - p[1]
        bx, by = b[0] - p[0], b[1] - p[1]
        cx, cy = c[0] - p[0], c[1] - p[1]

        det = (
            (ax * ax + ay * ay) * (bx * cy - cx * by) -
            (bx * bx + by * by) * (ax * cy - cx * ay) +
            (cx * cx + cy * cy) * (ax * by - bx * ay)
        )

        # Counter-clockwise orientation check
        ccw = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        return (det > 0) if ccw > 0 else (det < 0)

