"""
GeoCad - Optical Character Recognition (OCR), Clipboard, and File Ingestion Engine.
Parses cadastral traverse tables from raw text, clipboard images, scanned files,
and structured CSV / coordinate point datasets.
"""

import os
import re
import csv
import io
import math
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import List, Optional, Tuple, Dict, Any

from .bearing_parser import BearingParser


@dataclass
class ExtractedTraverseRow:
    """A row extracted from text, CSV, or OCR."""
    from_pt: str
    to_pt: str
    bearing_raw: str
    distance_raw: str
    distance_val: float
    confidence: float = 1.0
    alternate_reading: str = ""
    is_valid: bool = True


class OcrTableReader:
    """Parses cadastral lot descriptions from OCR images, clipboard, or files."""

    # Pattern matching lines like:
    # 1-2 N.28-38E. 246.48 M.
    # 1 2 N 28°38' E 246.48
    # LOT 2 S.16-35W. 4,921.70 M.
    # N 28-38 E 246.48
    LINE_PATTERN = re.compile(
        r'^\s*'
        r'(?:(?:LINE|LOT|CORNER)?\s*([0-9a-zA-Z]+)[\s\-]+([0-9a-zA-Z]+))?'       # From - To stations
        r'[\s:,]*'
        r'([NSns][\.\s_]*[0-9a-zA-Z]{1,3}[\s°\*dD\-\.]+[0-9a-zA-Z]{1,2}(?:[\s\'\-\.]+[0-9a-zA-Z]{1,2})?[\s\"\'\.]*(?:[EWew]|VV|vv)[\.\s_]*)' # Bearing
        r'[\s,]*'
        r'([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?)' # Distance
        r'[\sMm\'\.]*$',                                 # Units
        re.IGNORECASE
    )

    @classmethod
    def ocr_image_file(cls, image_path: str) -> str:
        """Extracts text from an image file using Windows native OCR engine or Tesseract."""
        if not image_path or not os.path.exists(image_path):
            return ""

        # Normalize path
        abs_path = os.path.abspath(image_path).replace("'", "''")

        # 1. Try Windows native OCR (Windows 10/11 built-in)
        ps_script = f"""
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        [Windows.Media.Ocr.OcrEngine, Windows.Foundation.UniversalApiContract, ContentType = WindowsRuntime] | Out-Null
        [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation.UniversalApiContract, ContentType = WindowsRuntime] | Out-Null
        [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null

        $asTaskGeneric = [System.WindowsRuntimeSystemExtensions].GetMethods() | ? {{ $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.IsGenericMethod }} | Select-Object -First 1
        function Await-Async($asyncOp, $type) {{
            $m = $asTaskGeneric.MakeGenericMethod($type)
            $task = $m.Invoke($null, @($asyncOp))
            $task.Wait()
            return $task.Result
        }}

        try {{
            $file = Await-Async ([Windows.Storage.StorageFile]::GetFileFromPathAsync('{abs_path}')) ([Windows.Storage.StorageFile])
            $stream = Await-Async ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
            $decoder = Await-Async ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Await-Async ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

            $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
            if (-not $engine) {{
                $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US'))
            }}
            $result = Await-Async ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

            foreach ($line in $result.Lines) {{
                Write-Output $line.Text
            }}
        }} catch {{
            Write-Error $_.Exception.Message
        }}
        """

        # Locate PowerShell executable (QGIS Python path might omit system32\WindowsPowerShell)
        ps_exe = shutil.which("powershell")
        if not ps_exe:
            for cand in [
                os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), r"System32\WindowsPowerShell\v1.0\powershell.exe"),
                r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
                r"C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe",
            ]:
                if os.path.exists(cand):
                    ps_exe = cand
                    break

        if ps_exe:
            try:
                cmd = [ps_exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=25)
                if res.returncode == 0 and res.stdout.strip():
                    return res.stdout.strip()
            except Exception:
                pass

        # 2. Fallback to pytesseract if installed
        try:
            import pytesseract
            from PIL import Image
            img = Image.open(image_path)
            text = pytesseract.image_to_string(img)
            if text.strip():
                return text.strip()
        except Exception:
            pass

        return ""

    @classmethod
    def parse_imported_file(cls, filepath: str) -> Tuple[List[Dict[str, Any]], Optional[Tuple[float, float]]]:
        """
        Parses an imported file (CSV, TXT, DAT) into structured traverse legs.
        Detects standard cadastral CSVs, GeoCad export CSVs, and coordinate point lists.
        Returns (rows, optional_start_coords).
        """
        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
        except Exception as e:
            raise IOError(f"Could not open file: {str(e)}")

        return cls.parse_content(content)

    @classmethod
    def parse_content(cls, content: str) -> Tuple[List[Dict[str, Any]], Optional[Tuple[float, float]]]:
        """
        Intelligently parses CSV or text data into traverse legs.
        Returns: (list_of_rows, optional_start_coords)
        """
        lines = [l.strip() for l in content.strip().splitlines() if l.strip()]
        if not lines:
            return [], None

        # Check delimiter
        first_few = lines[:min(5, len(lines))]
        delimiter = None
        for d in [',', '\t', ';']:
            if all(d in l for l in first_few):
                delimiter = d
                break

        start_coords = None
        rows: List[Dict[str, Any]] = []

        if delimiter:
            reader = list(csv.reader(io.StringIO(content), delimiter=delimiter))
            if reader:
                header = [h.strip().lower() for h in reader[0]]
                col_map = {}
                for idx, h in enumerate(header):
                    if any(k in h for k in ['from', 'stn_from', 'from_stn']):
                        col_map['from'] = idx
                    elif any(k in h for k in ['to', 'stn_to', 'to_stn']):
                        col_map['to'] = idx
                    elif any(k in h for k in ['bearing', 'brg', 'azimuth', 'dir']):
                        col_map['bearing'] = idx
                    elif any(k in h for k in ['distance', 'dist', 'dist_m', 'length']):
                        col_map['distance'] = idx
                    elif any(k in h for k in ['start_e', 'easting', 'east', 'grid_x', 'x']):
                        col_map['easting'] = idx
                    elif any(k in h for k in ['start_n', 'northing', 'north', 'grid_y', 'y']):
                        col_map['northing'] = idx
                    elif any(k in h for k in ['point', 'pt', 'station', 'stn', 'name', 'id']):
                        col_map['point'] = idx

                has_header = ('bearing' in col_map or 'northing' in col_map or 'from' in col_map)
                data_rows = reader[1:] if has_header else reader

                # Sub-case A: Traverse CSV (bearing + distance)
                if 'bearing' in col_map and 'distance' in col_map:
                    for idx, r in enumerate(data_rows):
                        if not r or len(r) <= max(col_map.values()):
                            continue
                        b_str = r[col_map['bearing']].strip()
                        d_str = r[col_map['distance']].strip()
                        if not b_str or not d_str:
                            continue
                        f_str = r[col_map['from']].strip() if 'from' in col_map and len(r) > col_map['from'] else str(idx + 1)
                        t_str = r[col_map['to']].strip() if 'to' in col_map and len(r) > col_map['to'] else str(idx + 2)
                        try:
                            d_val = float(d_str.replace(',', '').rstrip('mM\'" '))
                        except ValueError:
                            continue

                        az = BearingParser.parse_to_azimuth(b_str)
                        norm_b = BearingParser.azimuth_to_quadrant(az) if az is not None else b_str

                        if 'easting' in col_map and 'northing' in col_map and start_coords is None:
                            try:
                                e_val = float(r[col_map['easting']].replace(',', ''))
                                n_val = float(r[col_map['northing']].replace(',', ''))
                                start_coords = (e_val, n_val)
                            except ValueError:
                                pass

                        rows.append({'from': f_str, 'to': t_str, 'bearing': norm_b, 'distance': d_val})

                # Sub-case B: Coordinate Points CSV (Northing + Easting)
                elif 'northing' in col_map and 'easting' in col_map:
                    p_pts = []
                    for idx, r in enumerate(data_rows):
                        if not r or len(r) <= max(col_map['northing'], col_map['easting']):
                            continue
                        try:
                            n_val = float(r[col_map['northing']].replace(',', ''))
                            e_val = float(r[col_map['easting']].replace(',', ''))
                            p_name = r[col_map['point']].strip() if 'point' in col_map and len(r) > col_map['point'] else str(idx + 1)
                            p_pts.append((p_name, e_val, n_val))
                        except ValueError:
                            continue

                    if len(p_pts) >= 2:
                        start_coords = (p_pts[0][1], p_pts[0][2])
                        for i in range(len(p_pts)):
                            p_curr = p_pts[i]
                            p_next = p_pts[(i + 1) % len(p_pts)]
                            if i == len(p_pts) - 1 and len(p_pts) < 3:
                                break
                            de = p_next[1] - p_curr[1]
                            dn = p_next[2] - p_curr[2]
                            dist = math.hypot(de, dn)
                            if dist < 1e-5:
                                continue
                            az = (math.degrees(math.atan2(de, dn))) % 360.0
                            norm_b = BearingParser.azimuth_to_quadrant(az)

                            rows.append({'from': p_curr[0], 'to': p_next[0], 'bearing': norm_b, 'distance': round(dist, 2)})

                # Sub-case C: Headerless coordinate CSV (e.g. N, E, Label or P, N, E)
                elif not has_header:
                    p_pts = []
                    for idx, r in enumerate(data_rows):
                        if not r or len(r) < 2:
                            continue
                        def is_f(s):
                            try:
                                float(s.replace(',', ''))
                                return True
                            except (ValueError, AttributeError):
                                return False

                        if is_f(r[0]) and is_f(r[1]):
                            n_val = float(r[0].replace(',', ''))
                            e_val = float(r[1].replace(',', ''))
                            p_name = r[2].strip() if len(r) > 2 and r[2].strip() else f"P{idx+1}"
                            p_pts.append((p_name, e_val, n_val))
                        elif len(r) >= 3 and not is_f(r[0]) and is_f(r[1]) and is_f(r[2]):
                            p_name = r[0].strip()
                            n_val = float(r[1].replace(',', ''))
                            e_val = float(r[2].replace(',', ''))
                            p_pts.append((p_name, e_val, n_val))

                    if len(p_pts) >= 2:
                        start_coords = (p_pts[0][1], p_pts[0][2])
                        for i in range(len(p_pts)):
                            p_curr = p_pts[i]
                            p_next = p_pts[(i + 1) % len(p_pts)]
                            if i == len(p_pts) - 1 and len(p_pts) < 3:
                                break
                            de = p_next[1] - p_curr[1]
                            dn = p_next[2] - p_curr[2]
                            dist = math.hypot(de, dn)
                            if dist < 1e-5:
                                continue
                            az = (math.degrees(math.atan2(de, dn))) % 360.0
                            norm_b = BearingParser.azimuth_to_quadrant(az)
                            rows.append({'from': p_curr[0], 'to': p_next[0], 'bearing': norm_b, 'distance': round(dist, 2)})

        # If CSV detection did not extract rows, parse as structured/OCR text lines
        if not rows:
            extracted = cls.parse_text(content)
            rows = [
                {'from': r.from_pt, 'to': r.to_pt, 'bearing': r.bearing_raw, 'distance': r.distance_val}
                for r in extracted if r.is_valid
            ]

        # If still fewer than 2 rows, try column-block matching (bearings in one column, distances in another)
        if len(rows) < 2:
            block_rows = cls.extract_column_blocks(content)
            if len(block_rows) >= 2:
                rows = block_rows

        return rows, start_coords

    @classmethod
    def extract_column_blocks(cls, raw_text: str) -> List[Dict[str, Any]]:
        """Extracts traverse legs from multi-column OCR outputs where bearings and distances appear in separate blocks."""
        lines = [l.strip() for l in raw_text.splitlines() if l.strip()]

        # 1. Identify bearings with line numbers
        b_list = []
        for idx, l in enumerate(lines):
            cleaned = re.sub(r'[_|]', ' ', l)
            cleaned = re.sub(r'VV|vv', 'W', cleaned)
            az = BearingParser.parse_to_azimuth(cleaned)
            if az is not None and ('N' in cleaned.upper() or 'S' in cleaned.upper()):
                norm_b = BearingParser.azimuth_to_quadrant(az)
                b_list.append((idx, norm_b))

        # 2. Identify distances with line numbers (allowing "M.", "m.", "M", "ft.", "'")
        d_list = []
        for idx, l in enumerate(lines):
            cleaned = re.sub(r'[_|]', ' ', l)
            m = re.match(r'^\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?)\s*[mM\'\"\.\s]*$', cleaned)
            if m:
                try:
                    val = float(m.group(1).replace(',', ''))
                    if 1.0 <= val <= 50000.0 and ('.' in m.group(1) or val > 10.0):
                        if val > 1000 and '.' not in m.group(1) and (val / 100) < 500:
                            val = val / 100.0
                        d_list.append((idx, val))
                except ValueError:
                    pass

        # 3. Find consecutive bearing clusters
        b_clusters = []
        curr_c = []
        for b in b_list:
            if not curr_c or b[0] - curr_c[-1][0] <= 3:
                curr_c.append(b)
            else:
                if len(curr_c) >= 3:
                    b_clusters.append(curr_c)
                curr_c = [b]
        if len(curr_c) >= 3:
            b_clusters.append(curr_c)

        # 4. Find consecutive distance clusters
        d_clusters = []
        curr_d = []
        for d in d_list:
            if not curr_d or d[0] - curr_d[-1][0] <= 3:
                curr_d.append(d)
            else:
                if len(curr_d) >= 3:
                    d_clusters.append(curr_d)
                curr_d = [d]
        if len(curr_d) >= 3:
            d_clusters.append(curr_d)

        # 5. Pair bearing cluster with corresponding distance cluster
        for bc in b_clusters:
            for dc in d_clusters:
                gap = dc[0][0] - bc[-1][0]
                if 0 < gap <= 50 and abs(len(bc) - len(dc)) <= 1:
                    k = min(len(bc), len(dc))
                    paired = []
                    for j in range(k):
                        f_stn = str(j + 1)
                        t_stn = str(j + 2) if j < k - 1 else "1"
                        paired.append({'from': f_stn, 'to': t_stn, 'bearing': bc[j][1], 'distance': round(dc[j][1], 2)})
                    return paired

        return []

    @classmethod
    def parse_text(cls, raw_text: str) -> List[ExtractedTraverseRow]:
        """Extracts structured traverse rows from multi-line text or OCR results."""
        rows: List[ExtractedTraverseRow] = []
        if not raw_text:
            return rows

        lines = raw_text.strip().splitlines()
        auto_stn = 1

        for line_str in lines:
            line = line_str.strip()
            if not line or line.startswith("#"):
                continue

            # Clean OCR artifacts: normalize underscores and double V
            cleaned_line = re.sub(r'VV|vv', 'W', line)
            cleaned_line = re.sub(r'[_|]', ' ', cleaned_line)

            # Try direct regex match
            m = cls.LINE_PATTERN.search(cleaned_line)
            if m:
                from_p = m.group(1) or str(auto_stn)
                to_p = m.group(2) or str(auto_stn + 1)
                b_str = m.group(3).strip()
                d_str = m.group(4).replace(",", "").strip()

                try:
                    d_val = float(d_str)
                except ValueError:
                    d_val = 0.0

                az = BearingParser.parse_to_azimuth(b_str)
                norm_b = BearingParser.azimuth_to_quadrant(az) if az is not None else b_str

                if az is not None and d_val > 0:
                    rows.append(ExtractedTraverseRow(
                        from_pt=from_p,
                        to_pt=to_p,
                        bearing_raw=norm_b,
                        distance_raw=d_str,
                        distance_val=d_val,
                        is_valid=True
                    ))
                    auto_stn += 1
                    continue

            # Fallback: split by comma, tab, or whitespace
            tokens = [t.strip() for t in re.split(r'[,;\t]+|\s{2,}', cleaned_line) if t.strip()]
            if len(tokens) >= 2:
                found_b = None
                found_d = None
                other_tokens = []

                for tok in tokens:
                    az_test = BearingParser.parse_to_azimuth(tok)
                    if az_test is not None:
                        found_b = tok
                    else:
                        cleaned_num = tok.replace(",", "").rstrip("mM'\" ")
                        try:
                            val = float(cleaned_num)
                            if found_d is None and val > 0:
                                found_d = val
                            else:
                                other_tokens.append(tok)
                        except ValueError:
                            other_tokens.append(tok)

                if found_b is not None and found_d is not None:
                    from_p = str(auto_stn)
                    to_p = str(auto_stn + 1)
                    if len(other_tokens) >= 2:
                        from_p = other_tokens[0]
                        to_p = other_tokens[1]
                    elif len(other_tokens) == 1 and "-" in other_tokens[0]:
                        parts = other_tokens[0].split("-")
                        from_p, to_p = parts[0], parts[1]

                    az = BearingParser.parse_to_azimuth(found_b)
                    norm_b = BearingParser.azimuth_to_quadrant(az) if az is not None else found_b

                    rows.append(ExtractedTraverseRow(
                        from_pt=from_p,
                        to_pt=to_p,
                        bearing_raw=norm_b,
                        distance_raw=f"{found_d:.2f}",
                        distance_val=found_d,
                        is_valid=True
                    ))
                    auto_stn += 1

        # Fix final station connection if not closed
        if rows and len(rows) >= 3:
            first_from = rows[0].from_pt
            if rows[-1].to_pt != first_from:
                rows[-1].to_pt = first_from

        return rows
