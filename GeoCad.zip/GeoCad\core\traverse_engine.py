"""
GeoCad - Cadastral Lot Traverse Engine.
Implements tie-line calculation, forward traverse station computation,
closure error analysis, Bowditch (Compass Rule) adjustment, and Shoelace polygon area calculation.

Developed by GeoCad (geocad@example.com).
"""

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict, Any

from .bearing_parser import BearingParser


@dataclass
class TraverseLeg:
    """A single leg of a traverse."""
    from_pt: str
    to_pt: str
    bearing_str: str
    distance: float
    azimuth: float = 0.0
    start_coord: Tuple[float, float] = (0.0, 0.0)
    end_coord: Tuple[float, float] = (0.0, 0.0)
    adjusted_end_coord: Tuple[float, float] = (0.0, 0.0)


@dataclass
class LotTraverseResult:
    """Complete results of a computed lot traverse."""
    lot_no: str
    description: str
    target_crs: str
    reference_point: Optional[Tuple[float, float]]
    start_point: Tuple[float, float]
    tie_bearing_str: str
    tie_distance: float
    tie_azimuth: Optional[float]
    legs: List[TraverseLeg] = field(default_factory=list)
    unadjusted_vertices: List[Tuple[float, float]] = field(default_factory=list)
    adjusted_vertices: List[Tuple[float, float]] = field(default_factory=list)
    is_closed: bool = False
    area_sqm: float = 0.0
    area_ha: float = 0.0
    perimeter: float = 0.0
    closure_dx: float = 0.0
    closure_dy: float = 0.0
    closure_error_dist: float = 0.0
    closure_precision_ratio: Optional[int] = None
    closure_azimuth: float = 0.0
    declared_area: Optional[float] = None
    area_difference: Optional[float] = None
    wkt_polygon: str = ""
    wkt_linestring: str = ""
    wkt_tie_line: str = ""

    def summary_text(self) -> str:
        """Generates a human-readable engineering traverse summary."""
        lines = [
            f"=== GeoCad Traverse Computation: {self.lot_no} ===",
            f"Target CRS: {self.target_crs or 'Unspecified / Planar'}",
            f"Start Coordinate: Easting={self.start_point[0]:.4f}, Northing={self.start_point[1]:.4f}",
        ]
        if self.reference_point:
            lines.append(f"Reference Point: Easting={self.reference_point[0]:.4f}, Northing={self.reference_point[1]:.4f}")
            lines.append(f"Tie Line: {self.tie_bearing_str} @ {self.tie_distance:.3f} m")

        lines.extend([
            f"Total Stations / Vertices: {len(self.legs)}",
            f"Perimeter: {self.perimeter:.3f} m",
            f"Computed Area: {self.area_sqm:,.2f} sq.m ({self.area_ha:.4f} ha)",
        ])
        if self.declared_area:
            diff = self.area_sqm - self.declared_area
            lines.append(f"Declared Area: {self.declared_area:,.2f} sq.m (Diff: {diff:+,.2f} sq.m)")

        if self.is_closed:
            prec = f"1:{self.closure_precision_ratio}" if self.closure_precision_ratio else "Exact"
            lines.extend([
                f"Closure Error: {self.closure_error_dist:.4f} m (dE={self.closure_dx:+.4f}, dN={self.closure_dy:+.4f})",
                f"Closure Precision: {prec}",
                f"Closure Direction: {BearingParser.azimuth_to_quadrant(self.closure_azimuth)}",
            ])
        else:
            lines.append("Traverse Status: Open (ends at a different station)")

        return "\n".join(lines)


class TraverseEngine:
    """Computes surveyor traverses from bearing and distance observations."""

    @classmethod
    def compute_lot(
        cls,
        lot_no: str,
        legs_data: List[Dict[str, Any]],
        start_coord: Tuple[float, float],
        reference_coord: Optional[Tuple[float, float]] = None,
        tie_bearing: Optional[str] = None,
        tie_distance: float = 0.0,
        declared_area: Optional[float] = None,
        description: str = "",
        target_crs: str = "",
        apply_bowditch: bool = True
    ) -> LotTraverseResult:
        """Main calculation entry point for a lot traverse.

        :param lot_no: Lot identifier (e.g. 'LOT 1')
        :param legs_data: List of dicts with keys: 'from', 'to', 'bearing', 'distance'
        :param start_coord: (Easting, Northing) of Station 1
        :param reference_coord: Optional (Easting, Northing) of control monument/tie point
        :param tie_bearing: Optional tie bearing string (e.g. 'S 16°35\' W')
        :param tie_distance: Optional tie distance in meters
        :param declared_area: Optional title/deed declared area in sq.m
        :param description: Optional job description
        :param target_crs: Target CRS auth ID (e.g. 'EPSG:3124')
        :param apply_bowditch: Whether to compute Bowditch adjusted coordinates
        """
        # If tie point and tie line provided, ensure start_coord matches tie computation
        computed_start = start_coord
        tie_az = None
        if reference_coord is not None and tie_bearing and tie_distance > 0:
            tie_az = BearingParser.parse_to_azimuth(tie_bearing)
            if tie_az is not None:
                d_e, d_n = BearingParser.delta_en(tie_az, tie_distance)
                computed_start = (reference_coord[0] + d_e, reference_coord[1] + d_n)

        computed_legs: List[TraverseLeg] = []
        unadjusted_pts: List[Tuple[float, float]] = [computed_start]
        current_pt = computed_start
        total_dist = 0.0

        for row in legs_data:
            from_pt = str(row.get("from", "")).strip()
            to_pt = str(row.get("to", "")).strip()
            b_str = str(row.get("bearing", "")).strip()
            try:
                dist = float(row.get("distance", 0.0))
            except (ValueError, TypeError):
                dist = 0.0

            az = BearingParser.parse_to_azimuth(b_str)
            if az is None:
                az = 0.0

            d_e, d_n = BearingParser.delta_en(az, dist)
            next_pt = (current_pt[0] + d_e, current_pt[1] + d_n)

            leg = TraverseLeg(
                from_pt=from_pt,
                to_pt=to_pt,
                bearing_str=b_str,
                distance=dist,
                azimuth=az,
                start_coord=current_pt,
                end_coord=next_pt
            )
            computed_legs.append(leg)
            unadjusted_pts.append(next_pt)
            current_pt = next_pt
            total_dist += dist

        # Check closure: does the last station connect to station 1?
        is_closed = False
        if computed_legs:
            first_stn = computed_legs[0].from_pt
            last_stn = computed_legs[-1].to_pt
            if first_stn == last_stn or len(computed_legs) >= 3:
                is_closed = True

        # Closure error: difference between final point and initial start point
        dx = current_pt[0] - computed_start[0]
        dy = current_pt[1] - computed_start[1]
        closure_err = math.hypot(dx, dy)
        closure_az = math.degrees(math.atan2(dx, dy)) % 360.0

        ratio = None
        if closure_err > 1e-6 and total_dist > 0:
            ratio = int(round(total_dist / closure_err))

        # Bowditch (Compass Rule) Adjustment
        adjusted_pts: List[Tuple[float, float]] = [computed_start]
        if is_closed and total_dist > 0 and apply_bowditch:
            cum_dist = 0.0
            for leg in computed_legs:
                cum_dist += leg.distance
                factor = cum_dist / total_dist
                adj_x = leg.end_coord[0] - (dx * factor)
                adj_y = leg.end_coord[1] - (dy * factor)
                leg.adjusted_end_coord = (adj_x, adj_y)
                adjusted_pts.append((adj_x, adj_y))
            # Force the last vertex to exactly equal the starting point
            adjusted_pts[-1] = computed_start
        else:
            adjusted_pts = list(unadjusted_pts)
            for leg in computed_legs:
                leg.adjusted_end_coord = leg.end_coord

        # Compute Shoelace Area (using adjusted polygon if closed, else unadjusted)
        poly_pts = adjusted_pts[:-1] if is_closed else adjusted_pts
        area_sqm = cls.shoelace_area(poly_pts)
        area_ha = area_sqm / 10000.0

        diff_area = None
        if declared_area is not None:
            diff_area = area_sqm - declared_area

        # Build WKT Geometries
        wkt_poly = ""
        wkt_line = ""
        wkt_tie = ""

        if len(adjusted_pts) >= 4 and is_closed:
            ring = ", ".join(f"{x:.6f} {y:.6f}" for x, y in adjusted_pts)
            wkt_poly = f"POLYGON(({ring}))"

        if len(adjusted_pts) >= 2:
            pts_str = ", ".join(f"{x:.6f} {y:.6f}" for x, y in adjusted_pts)
            wkt_line = f"LINESTRING({pts_str})"

        if reference_coord is not None:
            wkt_tie = f"LINESTRING({reference_coord[0]:.6f} {reference_coord[1]:.6f}, {computed_start[0]:.6f} {computed_start[1]:.6f})"

        return LotTraverseResult(
            lot_no=lot_no,
            description=description,
            target_crs=target_crs,
            reference_point=reference_coord,
            start_point=computed_start,
            tie_bearing_str=tie_bearing or "",
            tie_distance=tie_distance,
            tie_azimuth=tie_az,
            legs=computed_legs,
            unadjusted_vertices=unadjusted_pts,
            adjusted_vertices=adjusted_pts,
            is_closed=is_closed,
            area_sqm=area_sqm,
            area_ha=area_ha,
            perimeter=total_dist,
            closure_dx=dx,
            closure_dy=dy,
            closure_error_dist=closure_err,
            closure_precision_ratio=ratio,
            closure_azimuth=closure_az,
            declared_area=declared_area,
            area_difference=diff_area,
            wkt_polygon=wkt_poly,
            wkt_linestring=wkt_line,
            wkt_tie_line=wkt_tie
        )

    @classmethod
    def shoelace_area(cls, pts: List[Tuple[float, float]]) -> float:
        """Calculates planar polygon area in square meters using the Surveyor / Shoelace formula."""
        n = len(pts)
        if n < 3:
            return 0.0

        area = 0.0
        for i in range(n):
            j = (i + 1) % n
            area += (pts[i][0] * pts[j][1]) - (pts[j][0] * pts[i][1])
        return abs(area) * 0.5

