"""
GeoCad - Main QGIS Plugin Controller & Lifecycle Manager.
Handles QGIS toolbar integration, pull-down menus, hotkeys,
and Processing Provider registration.
"""

import os
from typing import Optional

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QAction, QMenu
    from qgis.core import QgsApplication
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QAction:
        def __init__(self, *args, **kwargs): pass

from .core.compat import exec_dialog
from .geocad_dialog import GeoCadDialog
from .processing.provider import GeoCadProcessingProvider
from .ui.about_dialog import AboutDialog


class GeoCad:
    """Main GeoCad Plugin Controller."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider: Optional[GeoCadProcessingProvider] = None
        self.main_dialog: Optional[GeoCadDialog] = None
        self.actions = []
        self.menu_name = "&GeoCad"

    def initProcessing(self):
        """Initializes and registers the QGIS Processing provider."""
        if HAS_QGIS:
            self.provider = GeoCadProcessingProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        """Creates the GUI actions, toolbar icon, and menu items."""
        self.initProcessing()

        # Icon path
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # Main Workbench Action
        main_action = QAction(icon, "GeoCad — Surveying & Cadastral Workbench", self.iface.mainWindow())
        main_action.triggered.connect(self.run)
        main_action.setStatusTip("Open GeoCad Complete Land Surveying & Cadastral Suite")
        self.actions.append(main_action)

        # Module Direct Launcher Actions
        act_lot = QAction(icon, "Lot Traverse Plotter (Bearing & Distance)...", self.iface.mainWindow())
        act_lot.triggered.connect(lambda: self.run(tab_index=0))
        self.actions.append(act_lot)

        act_pnt = QAction(icon, "Point Ingestion & Boundaries (NEZL / KDMS)...", self.iface.mainWindow())
        act_pnt.triggered.connect(lambda: self.run(tab_index=1))
        self.actions.append(act_pnt)

        act_bd = QAction(icon, "Bearing & Distance Annotation (M / Ft)...", self.iface.mainWindow())
        act_bd.triggered.connect(lambda: self.run(tab_index=2))
        self.actions.append(act_bd)

        act_grid = QAction(icon, "Survey Grid Generator...", self.iface.mainWindow())
        act_grid.triggered.connect(lambda: self.run(tab_index=3))
        self.actions.append(act_grid)

        act_tin = QAction(icon, "TIN Surface Modeler...", self.iface.mainWindow())
        act_tin.triggered.connect(lambda: self.run(tab_index=4))
        self.actions.append(act_tin)

        act_cnt = QAction(icon, "Topographic Contours (smocont / ezy9)...", self.iface.mainWindow())
        act_cnt.triggered.connect(lambda: self.run(tab_index=5))
        self.actions.append(act_cnt)

        act_about = QAction("About GeoCad...", self.iface.mainWindow())
        act_about.triggered.connect(self.show_about)
        self.actions.append(act_about)

        # Add to Toolbar
        self.iface.addVectorToolBarIcon(main_action)

        # Add to Plugin Menu
        for action in self.actions:
            self.iface.addPluginToVectorMenu(self.menu_name, action)

    def unload(self):
        """Cleanly removes menu entries, toolbar icons, and unregisters provider."""
        for action in self.actions:
            self.iface.removePluginVectorMenu(self.menu_name, action)
            self.iface.removeVectorToolBarIcon(action)

        if HAS_QGIS and self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

    def run(self, tab_index: int = 0):
        """Launches or displays the master GeoCad Workbench dialog."""
        if not self.main_dialog:
            self.main_dialog = GeoCadDialog(iface=self.iface, parent=self.iface.mainWindow())

        if 0 <= tab_index < self.main_dialog.tabs.count():
            self.main_dialog.tabs.setCurrentIndex(tab_index)

        self.main_dialog.show()
        self.main_dialog.raise_()
        self.main_dialog.activateWindow()

    def show_about(self):
        """Opens the About & Brand Hub dialog."""
        dlg = AboutDialog(parent=self.iface.mainWindow())
        exec_dialog(dlg)
