"""
GeoCad - Cartographic Survey Grid Generator.
Generates boundary border collars, internal grid lines or cross tic marks,
and exterior coordinate annotations (Easting/Northing callouts).

Developed by GeoCad (geocad@example.com).
"""

import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Any


@dataclass
class GridAnnotationPoint:
    """A collar coordinate annotation placement."""
    x: float
    y: float
    text: str
    side: str  # 'bottom', 'top', 'left', 'right'
    alignment: str  # 'mc', 'middle', 'mr', 'ml'
    rotation_deg: float = 0.0


@dataclass
class GridGenerationResult:
    """Output layers and geometries for a survey grid."""
    bounding_box_wkt: str = ""
    grid_lines_wkt: List[str] = field(default_factory=list)
    tic_marks_wkt: List[str] = field(default_factory=list)
    annotations: List[GridAnnotationPoint] = field(default_factory=list)
    min_x: float = 0.0
    min_y: float = 0.0
    max_x: float = 0.0
    max_y: float = 0.0
    interval_x: float = 100.0
    interval_y: float = 100.0


class SurveyGridGenerator:
    """Generates coordinate grids, collars, and perimeter annotations."""

    @classmethod
    def generate_grid(
        cls,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        interval_x: float = 100.0,
        interval_y: Optional[float] = None,
        draw_ticks: bool = False,
        tic_size: float = 5.0,
        easting_suffix: str = "m E",
        northing_suffix: str = "m N",
        text_clearance: float = 15.0,
        precision: int = 0
    ) -> GridGenerationResult:
        """Constructs a survey grid within the specified bounding extents.

        :param x1, y1: First corner coordinates (e.g. lower-left)
        :param x2, y2: Opposite corner coordinates (e.g. upper-right)
        :param interval_x: Easting spacing
        :param interval_y: Northing spacing (defaults to interval_x if None)
        :param draw_ticks: If True, draws cross tic marks at intersections instead of full lines
        :param tic_size: Size of cross arms
        :param easting_suffix: Suffix appended to Easting labels
        :param northing_suffix: Suffix appended to Northing labels
        :param text_clearance: Distance of text callout outside border
        :param precision: Decimal places for coordinates
        """
        min_x = min(x1, x2)
        max_x = max(x1, x2)
        min_y = min(y1, y2)
        max_y = max(y1, y2)

        int_x = float(interval_x) if interval_x > 0 else 100.0
        int_y = float(interval_y) if interval_y and interval_y > 0 else int_x

        res = GridGenerationResult(
            min_x=min_x,
            min_y=min_y,
            max_x=max_x,
            max_y=max_y,
            interval_x=int_x,
            interval_y=int_y
        )

        # 1. Bounding Box Rectangle
        box_wkt = (
            f"POLYGON(({min_x:.4f} {min_y:.4f}, {min_x:.4f} {max_y:.4f}, "
            f"{max_x:.4f} {max_y:.4f}, {max_x:.4f} {min_y:.4f}, {min_x:.4f} {min_y:.4f}))"
        )
        res.bounding_box_wkt = box_wkt

        # Calculate rounded grid positions
        # Use integer multiples to prevent floating-point accumulation drift
        start_k_x = math.ceil(min_x / int_x)
        end_k_x = math.floor(max_x / int_x)
        x_positions = [k * int_x for k in range(start_k_x, end_k_x + 1)]

        start_k_y = math.ceil(min_y / int_y)
        end_k_y = math.floor(max_y / int_y)
        y_positions = [k * int_y for k in range(start_k_y, end_k_y + 1)]

        # 2. Grid Elements (Lines or Tic Marks)
        if draw_ticks:
            # Draw cross tick marks at all grid intersections
            half_tic = tic_size * 0.5
            for gx in x_positions:
                for gy in y_positions:
                    # Horizontal arm
                    h_arm = f"LINESTRING({gx - half_tic:.4f} {gy:.4f}, {gx + half_tic:.4f} {gy:.4f})"
                    # Vertical arm
                    v_arm = f"LINESTRING({gx:.4f} {gy - half_tic:.4f}, {gx:.4f} {gy + half_tic:.4f})"
                    res.tic_marks_wkt.extend([h_arm, v_arm])
        else:
            # Full North-South lines
            for gx in x_positions:
                line_wkt = f"LINESTRING({gx:.4f} {min_y:.4f}, {gx:.4f} {max_y:.4f})"
                res.grid_lines_wkt.append(line_wkt)

            # Full East-West lines
            for gy in y_positions:
                line_wkt = f"LINESTRING({min_x:.4f} {gy:.4f}, {max_x:.4f} {gy:.4f})"
                res.grid_lines_wkt.append(line_wkt)

        # 3. Exterior Collar Coordinate Annotations
        # Easting labels on Bottom and Top borders
        for gx in x_positions:
            val_str = f"{gx:.{precision}f}" if precision > 0 else f"{int(round(gx))}"
            tx = f"{val_str} {easting_suffix}".strip()

            # Bottom border callout
            res.annotations.append(GridAnnotationPoint(
                x=gx,
                y=min_y - text_clearance,
                text=tx,
                side="bottom",
                alignment="mc",
                rotation_deg=0.0
            ))
            # Top border callout
            res.annotations.append(GridAnnotationPoint(
                x=gx,
                y=max_y + text_clearance,
                text=tx,
                side="top",
                alignment="middle",
                rotation_deg=0.0
            ))

        # Northing labels on Left and Right borders
        for gy in y_positions:
            val_str = f"{gy:.{precision}f}" if precision > 0 else f"{int(round(gy))}"
            tx = f"{val_str} {northing_suffix}".strip()

            # Left border callout
            res.annotations.append(GridAnnotationPoint(
                x=min_x - text_clearance,
                y=gy,
                text=tx,
                side="left",
                alignment="mr",
                rotation_deg=0.0
            ))
            # Right border callout
            res.annotations.append(GridAnnotationPoint(
                x=max_x + text_clearance,
                y=gy,
                text=tx,
                side="right",
                alignment="ml",
                rotation_deg=0.0
            ))

        return res

