"""
GeoCad - Triangulated Irregular Network (TIN) Surface Modeling Widget.
Constructs Delaunay 3D triangular surface meshes and generates comprehensive
terrain analytics reports (tininf).

Developed by GeoCad (geocad@example.com).
"""

from typing import Optional, List, Tuple

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QComboBox, QLineEdit, QPushButton, QTextEdit, QMessageBox
    )
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPoint,
        QgsField, QgsWkbTypes, QgsMapLayerProxyModel
    )
    from qgis.gui import QgsMapLayerComboBox
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QComboBox, QLineEdit, QPushButton, QTextEdit, QMessageBox
    )
    HAS_QGIS = False

from ..core.compat import make_qgs_field
from ..core.tin_engine import TinEngine, TinReport, TinTriangle


class TinWidget(QWidget):
    """UI for generating TIN terrain surfaces and surface analytics."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.last_report: Optional[TinReport] = None
        self.last_triangles: List[TinTriangle] = []
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # Input Data Group
        gb_input = QGroupBox("Input Spot Elevations / Survey Points")
        i_layout = QGridLayout(gb_input)
        i_layout.setVerticalSpacing(8)

        i_layout.addWidget(QLabel("Point Layer:"), 0, 0)
        if HAS_QGIS:
            self.cmb_pnt_layer = QgsMapLayerComboBox()
            self.cmb_pnt_layer.setFilters(QgsMapLayerProxyModel.PointLayer)
            self.cmb_pnt_layer.layerChanged.connect(self._on_layer_selected)
        else:
            self.cmb_pnt_layer = QComboBox()
            self.cmb_pnt_layer.currentIndexChanged.connect(self._on_layer_selected)

        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.clicked.connect(self._refresh_layers)

        p_row = QHBoxLayout()
        p_row.addWidget(self.cmb_pnt_layer, stretch=1)
        p_row.addWidget(self.btn_refresh)
        i_layout.addLayout(p_row, 0, 1, 1, 3)

        i_layout.addWidget(QLabel("Elevation Source:"), 1, 0)
        self.cmb_z_field = QComboBox()
        i_layout.addWidget(self.cmb_z_field, 1, 1)

        i_layout.addWidget(QLabel("Surface Layer Name:"), 1, 2)
        self.txt_surface_name = QLineEdit("GeoCad_TIN_Surface")
        i_layout.addWidget(self.txt_surface_name, 1, 3)

        layout.addWidget(gb_input)

        # Report & Diagnostics
        self.txt_report = QTextEdit()
        self.txt_report.setReadOnly(True)
        self.txt_report.setPlaceholderText("TIN surface statistics and terrain metrics (tininf) will display here...")
        layout.addWidget(self.txt_report, stretch=1)

        # Actions
        act_row = QHBoxLayout()
        self.btn_report = QPushButton("View Full Report (tininf)")
        self.btn_report.clicked.connect(self._show_report)

        self.btn_build_tin = QPushButton("Build Delaunay TIN Surface")
        self.btn_build_tin.setStyleSheet("background-color: #2e7d32; color: white; font-weight: bold; padding: 8px 20px;")
        self.btn_build_tin.clicked.connect(self._build_tin)

        act_row.addWidget(self.btn_report)
        act_row.addStretch()
        act_row.addWidget(self.btn_build_tin)
        layout.addLayout(act_row)

        self._refresh_layers()

    def _refresh_layers(self):
        """Refreshes available point layers from QgsProject."""
        if not HAS_QGIS:
            self.cmb_pnt_layer.clear()
            self.cmb_pnt_layer.addItem("Sample Point Layer (Standalone)")
            self.cmb_z_field.clear()
            self.cmb_z_field.addItem("Geometry Z", "__geom_z__")
            return

        if isinstance(self.cmb_pnt_layer, QgsMapLayerComboBox):
            self.cmb_pnt_layer.setProject(QgsProject.instance())
            self.cmb_pnt_layer.setFilters(QgsMapLayerProxyModel.PointLayer)
        else:
            self.cmb_pnt_layer.clear()
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer) and layer.geometryType() == QgsWkbTypes.PointGeometry:
                    self.cmb_pnt_layer.addItem(layer.name(), layer.id())

        self._on_layer_selected()

    def _on_layer_selected(self, layer=None):
        """Populates the elevation field dropdown dynamically based on the chosen point layer."""
        self.cmb_z_field.clear()
        self.cmb_z_field.addItem("Geometry Z (PointZ)", "__geom_z__")

        if not HAS_QGIS:
            return

        if layer is None:
            if hasattr(self.cmb_pnt_layer, 'currentLayer'):
                layer = self.cmb_pnt_layer.currentLayer()
            elif hasattr(self.cmb_pnt_layer, 'currentData'):
                layer_id = self.cmb_pnt_layer.currentData()
                layer = QgsProject.instance().mapLayer(layer_id)

        if layer and hasattr(layer, "fields"):
            for field in layer.fields():
                if field.isNumeric():
                    self.cmb_z_field.addItem(f"Field: {field.name()}", field.name())

    def _build_tin(self):
        points: List[Tuple[float, float, float]] = []

        if not HAS_QGIS or not self.iface:
            # Standalone test sample
            import random
            random.seed(42)
            for _ in range(50):
                x = 484000.0 + random.uniform(0, 1000)
                y = 1548000.0 + random.uniform(0, 1000)
                z = 100.0 + random.uniform(5, 80)
                points.append((x, y, z))
            layer = None
        else:
            layer = None
            if hasattr(self.cmb_pnt_layer, 'currentLayer'):
                layer = self.cmb_pnt_layer.currentLayer()
            elif hasattr(self.cmb_pnt_layer, 'currentData'):
                layer_id = self.cmb_pnt_layer.currentData()
                layer = QgsProject.instance().mapLayer(layer_id)

            if not layer or not isinstance(layer, QgsVectorLayer):
                QMessageBox.warning(self, "TIN", "Please select a valid point layer with survey elevations.")
                return

            z_mode = self.cmb_z_field.currentData()

            for feat in layer.getFeatures():
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue

                pt = geom.asPoint()
                x = pt.x()
                y = pt.y()

                if z_mode == "__geom_z__":
                    z = geom.constGet().z() if geom.constGet().is3D() else 0.0
                else:
                    try:
                        z = float(feat[z_mode])
                    except (ValueError, TypeError):
                        z = 0.0

                points.append((x, y, z))

        if len(points) < 3:
            QMessageBox.warning(self, "TIN", "At least 3 valid non-collinear points are required to build a surface.")
            return

        s_name = self.txt_surface_name.text().strip() or "GeoCad_TIN_Surface"
        triangles, report = TinEngine.build_tin(points, surface_name=s_name)
        self.last_triangles = triangles
        self.last_report = report

        self.txt_report.setPlainText(report.summary_text())

        if HAS_QGIS and self.iface and layer:
            # Create 3D Polyface Mesh / Triangle Layer in QGIS
            crs_str = layer.crs().authid()
            tin_layer = QgsVectorLayer(f"PolygonZ?crs={crs_str}", s_name, "memory")
            pr = tin_layer.dataProvider()
            pr.addAttributes([
                make_qgs_field("Tri_ID", "int"),
                make_qgs_field("Area_2D", "double", 10, 2),
                make_qgs_field("Area_3D", "double", 10, 2),
                make_qgs_field("Slope_deg", "double", 6, 2),
                make_qgs_field("Aspect_deg", "double", 6, 2),
            ])
            tin_layer.updateFields()

            feats = []
            for tri in triangles:
                qpts = [
                    QgsPoint(tri.v1[0], tri.v1[1], tri.v1[2]),
                    QgsPoint(tri.v2[0], tri.v2[1], tri.v2[2]),
                    QgsPoint(tri.v3[0], tri.v3[1], tri.v3[2]),
                    QgsPoint(tri.v1[0], tri.v1[1], tri.v1[2]),
                ]
                poly_geom = QgsGeometry.fromPolygonZ([qpts])
                f = QgsFeature()
                f.setGeometry(poly_geom)
                f.setAttributes([tri.id, tri.area_2d, tri.area_3d, tri.slope_deg, tri.aspect_deg])
                feats.append(f)

            pr.addFeatures(feats)
            tin_layer.updateExtents()
            QgsProject.instance().addMapLayer(tin_layer)

            canvas = self.iface.mapCanvas()
            canvas.setExtent(tin_layer.extent())
            canvas.refresh()

        QMessageBox.information(
            self,
            "TIN Complete",
            f"Successfully constructed {len(triangles)} Delaunay surface triangles!\n"
            f"3D Surface Area: {report.area_3d_sqm:,.2f} sq.m ({report.area_3d_ha:.4f} ha)\n"
            f"Elevation Range: {report.min_z:.2f} m to {report.max_z:.2f} m"
        )

    def _show_report(self):
        if not self.last_report:
            QMessageBox.information(self, "Report", "Please build a TIN surface first.")
            return
        QMessageBox.information(self, "TIN Surface Report (tininf)", self.last_report.summary_text())
