# GeoCad — Professional Land Surveying & Cadastral CAD Suite for QGIS

## 1. Overview

**GeoCad** is an enterprise-grade Land Surveying, Cadastral Lot Plotting, and Digital Terrain Modeling (DTM) CAD Workbench for QGIS Desktop. Modernized for QGIS 3 and QGIS 4, GeoCad provides a unified, production-tested CAD workflow directly inside your GIS environment.

Whether you are plotting cadastral titles from technical descriptions, importing field points from total stations/RTK-GNSS, labeling boundaries with surveyor bearings and distances, generating cartographic coordinate grids, or modeling 3D TIN surfaces and topographic contours, **GeoCad** delivers surveyor-grade precision without requiring expensive CAD licenses.

---

## 2. Key Modules & Capabilities

```
       ┌─────────────────────────────────────────────────────────────┐
       │                    GeoCad QGIS Workbench                    │
       └──────────────────────────────┬──────────────────────────────┘
                                      │
         ┌───────────────────┬────────┴──────────┬───────────────────┐
         │                   │                   │                   │
         ▼                   ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│   Lot Plotter   │ │ Point Ingestion │ │Bearing & Distant│ │   Survey Grid   │
│ Bearing/Distance│ │ NEZL / KDMS2DTM │ │ Meters & Feet   │ │ Boundary Collar │
│ Tie Line / OCR  │ │ seqline Joins   │ │ 8 Placement Pos │ │ Northing/Easting│
└─────────────────┘ └─────────────────┘ └─────────────────┘ └─────────────────┘
         │                   │                   │                   │
         └───────────────────┼───────────────────┴───────────────────┘
                             │
                  ┌──────────┴──────────┐
                  │                     │
                  ▼                     ▼
         ┌─────────────────┐   ┌─────────────────┐
         │   TIN Surface   │   │   Topographic   │
         │ Delaunay Mesh   │   │    Contours     │
         │ 3D Area / Slope │   │ smocont / ezy9  │
         └─────────────────┘   └─────────────────┘
```

### 2.1. Lot Traverse Plotter (Bearing & Distance)
- **Direct Technical Description Entry**: Input cadastral lots station by station (`From`, `To`, `Bearing`, `Distance`).
- **Multi-Source Ingestion**:
  - **Upload Image (OCR)**: Scans title images, plans, and technical descriptions with built-in OCR.
  - **Paste (Image / Text)**: Seamlessly ingests clipboard text or screenshot clips from Windows Snipping Tool.
  - **Import CSV...**: Intelligently parses cadastral CSVs, GeoCad export files, and coordinate point datasets.
- **Tie-Line Calculator**: Accurately computes Station 1 starting coordinates $(E, N)$ from a reference control monument using tie bearing and distance.
- **Closure Error & Diagnostics**: Automatically calculates Easting/Northing misclosure ($c_E, c_N$), linear misclosure distance, closure direction, and relative precision ratio ($1:N$).
- **Bowditch Adjustment (Compass Rule)**: Distributes angular and distance misclosure proportionally across traverse perimeter.

### 2.2. Coordinate Point Plotting (`seqline`)
- Support for P,N,E,Z,L, NEL, NEZL, and KDMS field files.
- Sequential line joining for boundary traverses.

### 2.3. Boundary Bearing & Distance Annotation
- 8 standard placement modes (LR, RL, LL, RR, BL, BR, DL, DR).
- Distance units in Meters (m) or Feet (').
- Automatic text flipping to ensure annotations are never upside down.

### 2.4. Cartographic Survey Grids
- Full grid lines or cross tic marks.
- Margin collar coordinate annotations with custom units and clearance.

### 2.5. Delaunay TIN Surface Modeler
- 3D triangulation and terrain modeling.
- Surface area and slope analysis.

### 2.6. Topographic Contour Generator
- Regular and index contours with elevation labeling.
- Spline smoothing and hypsometric elevation tinting.
