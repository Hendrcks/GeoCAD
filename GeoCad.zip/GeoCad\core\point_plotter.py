"""
GeoCad - Survey Coordinate Point Ingestion and Sequential Boundary Connection.
Implements coordinate ingestion for standard surveying profiles:
NEZL, NEL, NEZ, NE, PNEZL, PNEL, PNEZ, PNE, KDMS2DTM, and custom mappings.
Includes sequential boundary line connection (seqline algorithm).

Developed by GeoCad (geocad@example.com).
"""

import csv
import io
import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict, Any


@dataclass
class SurveyPointRecord:
    """A parsed survey point record."""
    point_id: str
    easting: float    # CAD X
    northing: float   # CAD Y
    elevation: float  # CAD Z
    label: str
    raw_line: str = ""
    prefix: str = ""


@dataclass
class PointPlottingResult:
    """Results of coordinate file parsing and line grouping."""
    points: List[SurveyPointRecord] = field(default_factory=list)
    boundary_lines: List[List[Tuple[float, float, float]]] = field(default_factory=list)
    skipped_rows: List[Tuple[int, str, str]] = field(default_factory=list)  # (line_no, raw, reason)
    min_easting: float = 0.0
    max_easting: float = 0.0
    min_northing: float = 0.0
    max_northing: float = 0.0
    min_elevation: float = 0.0
    max_elevation: float = 0.0


class PointPlotter:
    """Parses ASCII survey coordinate files and connects sequential boundary lines."""

    PROFILES = [
        "Auto-detect",
        "P,N,E,Z,L",
        "P,N,E,L",
        "P,N,E,Z",
        "P,N,E",
        "N,E,Z,L",
        "N,E,L",
        "N,E,Z",
        "N,E",
        "E,N,Z,L",
        "P,E,N,Z,L",
        "KDMS2DTM",
    ]

    @classmethod
    def _detect_row_format(cls, parts: List[str]) -> str:
        """Determines the best coordinate profile based on token count and types."""
        n = len(parts)

        def is_num(s):
            try:
                float(s.replace(',', ''))
                return True
            except (ValueError, AttributeError):
                return False

        if n == 2:
            return "N,E"
        elif n == 3:
            if not is_num(parts[0]) and is_num(parts[1]) and is_num(parts[2]):
                return "P,N,E"
            elif is_num(parts[0]) and is_num(parts[1]) and not is_num(parts[2]):
                return "N,E,L"
            else:
                return "N,E,Z"
        elif n == 4:
            if not is_num(parts[0]):
                if not is_num(parts[3]):
                    return "P,N,E,L"
                else:
                    return "P,N,E,Z"
            else:
                if not is_num(parts[3]):
                    return "N,E,Z,L"
                else:
                    return "N,E,Z"
        elif n >= 5:
            if not is_num(parts[0]):
                return "P,N,E,Z,L"
            else:
                return "N,E,Z,L"
        return "N,E"

    @classmethod
    def parse_file(
        cls,
        filepath_or_content: str,
        profile: str = "P,N,E,Z,L",
        delimiter: str = ",",
        enable_sequential_lines: bool = False,
        prefix_length: int = 2,
        has_header: bool = False
    ) -> PointPlottingResult:
        """Parses an ASCII survey file or raw text content."""
        # Check if argument is a file path or direct content
        lines = []
        try:
            with open(filepath_or_content, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
        except (OSError, IOError):
            lines = filepath_or_content.splitlines()

        norm_profile = profile.strip().upper().replace(" ", "")
        result = PointPlottingResult()

        if norm_profile == "KDMS2DTM":
            cls._parse_kdms(lines, result, enable_sequential_lines, prefix_length)
        else:
            cls._parse_delimited(lines, result, norm_profile, delimiter, enable_sequential_lines, prefix_length, has_header)

        # Compute bounding limits
        if result.points:
            eastings = [p.easting for p in result.points]
            northings = [p.northing for p in result.points]
            elevs = [p.elevation for p in result.points]
            result.min_easting = min(eastings)
            result.max_easting = max(eastings)
            result.min_northing = min(northings)
            result.max_northing = max(northings)
            result.min_elevation = min(elevs)
            result.max_elevation = max(elevs)

        return result

    @classmethod
    def _parse_delimited(
        cls,
        lines: List[str],
        result: PointPlottingResult,
        profile: str,
        delimiter: str,
        enable_seq: bool,
        prefix_len: int,
        has_header: bool
    ):
        """Parses standard comma/space/tab-separated coordinate files."""
        current_line_pts: List[Tuple[float, float, float]] = []
        last_prefix = None

        for idx, raw in enumerate(lines):
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("//"):
                continue
            if idx == 0 and has_header:
                continue

            # Handle automatic delimiter detection if needed
            sep = delimiter
            if sep == "auto" or not sep:
                if "," in line:
                    sep = ","
                elif ";" in line:
                    sep = ";"
                elif "\t" in line:
                    sep = "\t"
                else:
                    sep = None  # whitespace split

            parts = [p.strip() for p in (line.split(sep) if sep else line.split())]
            if not parts:
                continue

            # Auto-skip header row if first line contains text labels in coordinate positions
            if idx == 0 and not has_header:
                def is_num(s):
                    try:
                        float(s.replace(',', ''))
                        return True
                    except (ValueError, AttributeError):
                        return False
                if len(parts) >= 2 and (not is_num(parts[0]) or not is_num(parts[1])):
                    hdr_test = line.lower()
                    if any(k in hdr_test for k in ['point', 'east', 'north', 'elev', 'label', 'x', 'y', 'z', 'lat', 'lon', 'name']):
                        continue

            # Determine active profile: Auto-detect or adapt if column count is smaller
            active_profile = profile
            expected_cols = {
                "P,N,E,Z,L": 5, "P,E,N,Z,L": 5,
                "P,N,E,L": 4, "P,N,E,Z": 4, "N,E,Z,L": 4, "E,N,Z,L": 4,
                "N,E,Z": 3, "N,E,L": 3, "P,N,E": 3,
                "N,E": 2
            }
            if active_profile in ("AUTO-DETECT", "AUTODETECT", "AUTO") or len(parts) < expected_cols.get(active_profile, 4):
                active_profile = cls._detect_row_format(parts)

            point_id = ""
            north = 0.0
            east = 0.0
            elev = 0.0
            label = ""

            try:
                if active_profile == "N,E,Z,L":
                    if len(parts) < 3:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    north = float(parts[0])
                    east = float(parts[1])
                    elev = float(parts[2])
                    label = parts[3] if len(parts) > 3 else ""
                    point_id = label or f"PT_{len(result.points)+1}"

                elif active_profile == "N,E,L":
                    if len(parts) < 2:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    north = float(parts[0])
                    east = float(parts[1])
                    label = parts[2] if len(parts) > 2 else ""
                    point_id = label or f"PT_{len(result.points)+1}"

                elif active_profile == "N,E,Z":
                    if len(parts) < 3:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    north = float(parts[0])
                    east = float(parts[1])
                    elev = float(parts[2])
                    point_id = f"PT_{len(result.points)+1}"

                elif active_profile == "N,E":
                    if len(parts) < 2:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    north = float(parts[0])
                    east = float(parts[1])
                    point_id = f"PT_{len(result.points)+1}"

                elif active_profile == "P,N,E,Z,L":
                    if len(parts) < 4:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    point_id = parts[0]
                    north = float(parts[1])
                    east = float(parts[2])
                    elev = float(parts[3])
                    label = parts[4] if len(parts) > 4 else point_id

                elif active_profile == "P,N,E,L":
                    if len(parts) < 3:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    point_id = parts[0]
                    north = float(parts[1])
                    east = float(parts[2])
                    label = parts[3] if len(parts) > 3 else point_id

                elif active_profile == "P,N,E,Z":
                    if len(parts) < 4:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    point_id = parts[0]
                    north = float(parts[1])
                    east = float(parts[2])
                    elev = float(parts[3])

                elif active_profile == "P,N,E":
                    if len(parts) < 3:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    point_id = parts[0]
                    north = float(parts[1])
                    east = float(parts[2])

                elif active_profile == "E,N,Z,L":
                    if len(parts) < 3:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    east = float(parts[0])
                    north = float(parts[1])
                    elev = float(parts[2])
                    label = parts[3] if len(parts) > 3 else ""
                    point_id = label or f"PT_{len(result.points)+1}"

                elif active_profile == "P,E,N,Z,L":
                    if len(parts) < 4:
                        result.skipped_rows.append((idx + 1, line, "Too few columns"))
                        continue
                    point_id = parts[0]
                    east = float(parts[1])
                    north = float(parts[2])
                    elev = float(parts[3])
                    label = parts[4] if len(parts) > 4 else point_id

                else:
                    result.skipped_rows.append((idx + 1, line, f"Unknown profile: {active_profile}"))
                    continue

            except ValueError as e:
                result.skipped_rows.append((idx + 1, line, f"Numeric parse error: {str(e)}"))
                continue

            # Prefix extraction for boundary string joining
            search_str = label or point_id
            alpha_m = re.match(r'^([a-zA-Z]+)', search_str)
            if alpha_m:
                prefix = alpha_m.group(1).upper()
            else:
                prefix = search_str[:prefix_len].upper() if len(search_str) >= prefix_len else search_str.upper()

            rec = SurveyPointRecord(
                point_id=point_id,
                easting=east,
                northing=north,
                elevation=elev,
                label=label or point_id,
                raw_line=line,
                prefix=prefix
            )
            result.points.append(rec)

            # Sequential line connection (seqline algorithm)
            if enable_seq:
                pt_tuple = (east, north, elev)
                if last_prefix == prefix and prefix:
                    current_line_pts.append(pt_tuple)
                else:
                    if len(current_line_pts) >= 2:
                        result.boundary_lines.append(list(current_line_pts))
                    current_line_pts = [pt_tuple]
                last_prefix = prefix

        if enable_seq and len(current_line_pts) >= 2:
            result.boundary_lines.append(list(current_line_pts))

    @classmethod
    def _parse_kdms(
        cls,
        lines: List[str],
        result: PointPlottingResult,
        enable_seq: bool,
        prefix_len: int
    ):
        """Parses KDMS2DTM fixed-width column coordinate format."""
        current_line_pts: List[Tuple[float, float, float]] = []
        last_prefix = None

        # Line 0 is often header line in KDMS
        start_idx = 1 if len(lines) > 1 and not re.search(r'\d', lines[0][:6]) else 0

        for idx in range(start_idx, len(lines)):
            raw = lines[idx]
            line = raw.rstrip('\r\n')
            if len(line) < 32:
                continue

            try:
                # Substr slices (1-based in LISP: 1..6, 7..17, 18..32, 33..40)
                point_id = line[0:6].strip()
                north_str = line[6:17].strip()
                east_str = line[17:32].strip()
                elev_str = line[32:40].strip() if len(line) >= 33 else "0.0"

                north = float(north_str)
                east = float(east_str)
                elev = float(elev_str) if elev_str else 0.0

                prefix = point_id[:prefix_len].upper() if len(point_id) >= prefix_len else point_id.upper()

                rec = SurveyPointRecord(
                    point_id=point_id,
                    easting=east,
                    northing=north,
                    elevation=elev,
                    label=point_id,
                    raw_line=raw,
                    prefix=prefix
                )
                result.points.append(rec)

                if enable_seq:
                    pt_tuple = (east, north, elev)
                    if last_prefix == prefix and prefix:
                        current_line_pts.append(pt_tuple)
                    else:
                        if len(current_line_pts) >= 2:
                            result.boundary_lines.append(list(current_line_pts))
                        current_line_pts = [pt_tuple]
                    last_prefix = prefix

            except ValueError as e:
                result.skipped_rows.append((idx + 1, raw, f"KDMS parse error: {str(e)}"))

        if enable_seq and len(current_line_pts) >= 2:
            result.boundary_lines.append(list(current_line_pts))

