"""
GeoCad - Professional Land Surveying and Cadastral CAD Suite for QGIS.
"""

def classFactory(iface):
    """Load GeoCad class from file geocad.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .geocad import GeoCad
    return GeoCad(iface)
