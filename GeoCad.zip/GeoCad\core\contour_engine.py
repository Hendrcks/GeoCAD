"""
GeoCad - Topographic Contour Extraction, Spline Smoothing, and Hypsometric Tinting.
Implements linear edge interpolation on TIN surfaces, Index/Intermediate contour classification,
Chaikin polyline smoothing (smocont), and elevation zone color mapping (ezy9).

Developed by GeoCad (geocad@example.com).
"""

import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Any

from .tin_engine import TinTriangle, TinEngine


@dataclass
class ContourLine:
    """A generated topographic contour polyline."""
    id: int
    elevation: float
    is_index: bool  # True for Major/Index, False for Minor/Intermediate
    level_type: str  # 'Index' or 'Intermediate'
    coordinates: List[Tuple[float, float]]
    length: float = 0.0
    color_hex: str = "#8B4513"


@dataclass
class ContourResult:
    """Output results of contouring generation."""
    contours: List[ContourLine] = field(default_factory=list)
    index_contours: List[ContourLine] = field(default_factory=list)
    intermediate_contours: List[ContourLine] = field(default_factory=list)
    min_elevation: float = 0.0
    max_elevation: float = 0.0
    interval: float = 2.0
    index_multiplier: int = 5
    color_zones: List[Dict[str, Any]] = field(default_factory=list)


class ContourEngine:
    """Extracts, threads, smooths, and colors topographic contours."""

    DEFAULT_6_ZONE_COLORS = [
        "#1a9850",  # Zone 1: Lush valley green
        "#91cf60",  # Zone 2: Lowland light green
        "#d9ef8b",  # Zone 3: Foothill yellow-green
        "#fee08b",  # Zone 4: Midland amber
        "#fc8d59",  # Zone 5: Highland orange-brown
        "#d73027",  # Zone 6: Ridge/peak deep red
    ]

    @classmethod
    def generate_contours(
        cls,
        triangles: List[TinTriangle],
        interval: float = 2.0,
        base_elevation: float = 0.0,
        index_multiplier: int = 5,
        smooth: bool = True,
        smooth_iterations: int = 2
    ) -> ContourResult:
        """Generates contour polylines from TIN triangles.

        :param triangles: List of TinTriangle facets
        :param interval: Contour elevation step (dz)
        :param base_elevation: Reference zero contour datum
        :param index_multiplier: Every m-th contour is an index contour
        :param smooth: Whether to apply Chaikin smoothing
        :param smooth_iterations: Smoothing passes
        """
        result = ContourResult(interval=interval, index_multiplier=index_multiplier)
        if not triangles:
            return result

        # Determine surface elevation limits
        all_z = []
        for t in triangles:
            all_z.extend([t.v1[2], t.v2[2], t.v3[2]])
        min_z = min(all_z)
        max_z = max(all_z)
        result.min_elevation = min_z
        result.max_elevation = max_z

        dz = float(interval) if interval > 0 else 2.0
        z0 = float(base_elevation)
        m_mult = int(index_multiplier) if index_multiplier > 0 else 5

        # Determine elevation levels
        start_k = math.ceil((min_z - z0) / dz)
        end_k = math.floor((max_z - z0) / dz)

        contour_id = 1
        for k in range(start_k, end_k + 1):
            zc = z0 + (k * dz)
            is_index = (k % m_mult == 0)
            lvl_type = "Index" if is_index else "Intermediate"

            # 1. Collect all segment intercepts for this elevation
            segments: List[Tuple[Tuple[float, float], Tuple[float, float]]] = []
            for t in triangles:
                seg = cls._intersect_triangle(t, zc)
                if seg:
                    segments.append(seg)

            if not segments:
                continue

            # 2. Thread segments into continuous polylines
            polylines = cls._thread_segments(segments)

            # 3. Apply smoothing if requested
            for poly in polylines:
                if smooth and len(poly) >= 3:
                    poly = cls._chaikin_smooth(poly, iterations=smooth_iterations)

                line_len = 0.0
                for i in range(len(poly) - 1):
                    line_len += math.hypot(poly[i+1][0] - poly[i][0], poly[i+1][1] - poly[i][1])

                # Determine zone color
                rel_pos = (zc - min_z) / max(1e-6, max_z - min_z)
                zone_idx = min(len(cls.DEFAULT_6_ZONE_COLORS) - 1, int(rel_pos * len(cls.DEFAULT_6_ZONE_COLORS)))
                color = cls.DEFAULT_6_ZONE_COLORS[zone_idx]

                c_line = ContourLine(
                    id=contour_id,
                    elevation=zc,
                    is_index=is_index,
                    level_type=lvl_type,
                    coordinates=poly,
                    length=line_len,
                    color_hex=color
                )
                result.contours.append(c_line)
                if is_index:
                    result.index_contours.append(c_line)
                else:
                    result.intermediate_contours.append(c_line)

                contour_id += 1

        return result

    @classmethod
    def _intersect_triangle(
        cls,
        tri: TinTriangle,
        zc: float
    ) -> Optional[Tuple[Tuple[float, float], Tuple[float, float]]]:
        """Calculates line segment intercept of contour zc across triangle."""
        v = [tri.v1, tri.v2, tri.v3]
        z_vals = [pt[2] for pt in v]

        if zc < min(z_vals) or zc > max(z_vals):
            return None

        intercepts: List[Tuple[float, float]] = []
        edges = [(0, 1), (1, 2), (2, 0)]

        for i1, i2 in edges:
            p1, p2 = v[i1], v[i2]
            z1, z2 = p1[2], p2[2]

            # Does edge cross zc?
            if (z1 <= zc <= z2) or (z2 <= zc <= z1):
                if abs(z2 - z1) > 1e-9:
                    t = (zc - z1) / (z2 - z1)
                    ix = p1[0] + (t * (p2[0] - p1[0]))
                    iy = p1[1] + (t * (p2[1] - p1[1]))
                    # Avoid duplicate edge endpoints
                    if not any(math.hypot(ix - ep[0], iy - ep[1]) < 1e-5 for ep in intercepts):
                        intercepts.append((ix, iy))

        if len(intercepts) == 2:
            return (intercepts[0], intercepts[1])
        return None

    @classmethod
    def _thread_segments(
        cls,
        segments: List[Tuple[Tuple[float, float], Tuple[float, float]]],
        tolerance: float = 1e-4
    ) -> List[List[Tuple[float, float]]]:
        """Chains unordered line segments into continuous polylines."""
        if not segments:
            return []

        remaining = list(segments)
        polylines: List[List[Tuple[float, float]]] = []

        while remaining:
            first_seg = remaining.pop(0)
            chain = [first_seg[0], first_seg[1]]

            # Expand chain forward and backward
            extended = True
            while extended:
                extended = False
                head = chain[0]
                tail = chain[-1]

                for idx, (p1, p2) in enumerate(remaining):
                    # Check connection to tail
                    if math.hypot(p1[0] - tail[0], p1[1] - tail[1]) < tolerance:
                        chain.append(p2)
                        remaining.pop(idx)
                        extended = True
                        break
                    elif math.hypot(p2[0] - tail[0], p2[1] - tail[1]) < tolerance:
                        chain.append(p1)
                        remaining.pop(idx)
                        extended = True
                        break
                    # Check connection to head
                    elif math.hypot(p2[0] - head[0], p2[1] - head[1]) < tolerance:
                        chain.insert(0, p1)
                        remaining.pop(idx)
                        extended = True
                        break
                    elif math.hypot(p1[0] - head[0], p1[1] - head[1]) < tolerance:
                        chain.insert(0, p2)
                        remaining.pop(idx)
                        extended = True
                        break

            polylines.append(chain)

        return polylines

    @classmethod
    def _chaikin_smooth(
        cls,
        pts: List[Tuple[float, float]],
        iterations: int = 2
    ) -> List[Tuple[float, float]]:
        """Applies Chaikin's corner-cutting algorithm for smooth contour polylines."""
        current = list(pts)
        is_closed = (math.hypot(current[0][0] - current[-1][0], current[0][1] - current[-1][1]) < 1e-5)

        for _ in range(iterations):
            if len(current) < 3:
                break
            smoothed: List[Tuple[float, float]] = []
            if not is_closed:
                smoothed.append(current[0])

            n = len(current) - 1
            for i in range(n):
                p0 = current[i]
                p1 = current[i + 1]

                # Q = 0.75 P0 + 0.25 P1
                q = (0.75 * p0[0] + 0.25 * p1[0], 0.75 * p0[1] + 0.25 * p1[1])
                # R = 0.25 P0 + 0.75 P1
                r = (0.25 * p0[0] + 0.75 * p1[0], 0.25 * p0[1] + 0.75 * p1[1])
                smoothed.extend([q, r])

            if not is_closed:
                smoothed.append(current[-1])
            else:
                smoothed.append(smoothed[0])  # ensure closure

            current = smoothed

        return current

