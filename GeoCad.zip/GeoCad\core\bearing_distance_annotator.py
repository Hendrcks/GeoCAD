"""
GeoCad - Boundary Bearing and Distance Annotation Engine.
Implements the full functionality of Fred Bertagnolli's BEADIST and BEADISTM:
Left/Right text placement, auto upside-down flipping, Meters vs Feet units,
and quadrant bearing formatting.

Developed by GeoCad (geocad@example.com).
"""

import math
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict, Any

from .bearing_parser import BearingParser


@dataclass
class SegmentAnnotation:
    """Calculated annotation placements and texts for a line segment."""
    segment_id: int
    p1: Tuple[float, float]
    p2: Tuple[float, float]
    midpoint: Tuple[float, float]
    distance_raw: float
    distance_str: str
    azimuth_deg: float
    bearing_str: str
    text_angle_deg: float
    p_left: Tuple[float, float]
    p_right: Tuple[float, float]
    text_left: str = ""
    text_right: str = ""


class BearingDistanceAnnotator:
    """Computes surveyor bearings, distances, and normal offset text placement for line segments."""

    MODES = ["LR", "RL", "LL", "RR", "BL", "BR", "DL", "DR"]
    UNITS_METERS = "Meters"
    UNITS_FEET = "Feet"
    METERS_TO_FEET = 3.280839895013123

    @classmethod
    def annotate_segment(
        cls,
        p1: Tuple[float, float],
        p2: Tuple[float, float],
        mode: str = "LR",
        unit: str = UNITS_METERS,
        reverse_direction: bool = False,
        text_height: float = 2.5,
        offset_multiplier: float = 1.125,
        precision_dist: int = 2,
        expand_cardinals: bool = True,
        segment_id: int = 1
    ) -> Optional[SegmentAnnotation]:
        """Calculates bearing, distance, and placement points for a line segment.

        :param p1: (X1, Y1) starting vertex
        :param p2: (X2, Y2) ending vertex
        :param mode: One of 'LR', 'RL', 'LL', 'RR', 'BL', 'BR', 'DL', 'DR'
        :param unit: 'Meters' or 'Feet'
        :param reverse_direction: If True, reverses line vector direction
        :param text_height: Text height in map units
        :param offset_multiplier: Normal offset factor (default 1.125)
        :param precision_dist: Decimal places for distance
        :param expand_cardinals: Whether to spell out East/North/West/South
        :param segment_id: Identifier index
        """
        start = p2 if reverse_direction else p1
        end = p1 if reverse_direction else p2

        dx = end[0] - start[0]
        dy = end[1] - start[1]
        dist_m = math.hypot(dx, dy)

        if dist_m < 1e-6:
            return None

        # Unit distance formatting
        if unit == cls.UNITS_FEET:
            dist_val = dist_m * cls.METERS_TO_FEET
            d_str = f"{dist_val:.{precision_dist}f}'"
        else:
            d_str = f"{dist_m:.{precision_dist}f}m"

        # Survey Azimuth & Quadrant Bearing
        azimuth, _ = BearingParser.coordinates_to_azimuth_distance(start, end)
        b_str = BearingParser.azimuth_to_quadrant(azimuth)

        if expand_cardinals:
            cardinals = {"E": "East", "N": "North", "W": "West", "S": "South"}
            b_str = cardinals.get(b_str, b_str)

        # Midpoint & Perpendicular Offsets
        mid_x = (start[0] + end[0]) * 0.5
        mid_y = (start[1] + end[1]) * 0.5
        midpoint = (mid_x, mid_y)

        # Cartesian Angle theta (counterclockwise from East)
        theta = math.atan2(dy, dx)
        offset_dist = text_height * offset_multiplier

        # Left normal is theta + pi/2: (-sin theta, cos theta)
        # Right normal is theta - pi/2: (sin theta, -cos theta)
        p_left = (
            mid_x - (math.sin(theta) * offset_dist),
            mid_y + (math.cos(theta) * offset_dist)
        )
        p_right = (
            mid_x + (math.sin(theta) * offset_dist),
            mid_y - (math.cos(theta) * offset_dist)
        )

        # Upside-Down Text Flipping (cartographic readability rule)
        # If angle is between 90° and 270°, flip by 180°
        text_angle = theta
        if (0.5 * math.pi) < (text_angle % (2.0 * math.pi)) < (1.5 * math.pi):
            text_angle -= math.pi
        text_angle_deg = math.degrees(text_angle)

        norm_mode = mode.upper()
        text_left = ""
        text_right = ""

        if norm_mode == "LR":
            text_left = b_str
            text_right = d_str
        elif norm_mode == "RL":
            text_left = d_str
            text_right = b_str
        elif norm_mode == "LL":
            text_left = f"{b_str}  {d_str}"
        elif norm_mode == "RR":
            text_right = f"{b_str}  {d_str}"
        elif norm_mode == "BL":
            text_left = b_str
        elif norm_mode == "BR":
            text_right = b_str
        elif norm_mode == "DL":
            text_left = d_str
        elif norm_mode == "DR":
            text_right = d_str
        else:
            text_left = b_str
            text_right = d_str

        return SegmentAnnotation(
            segment_id=segment_id,
            p1=start,
            p2=end,
            midpoint=midpoint,
            distance_raw=dist_m,
            distance_str=d_str,
            azimuth_deg=azimuth,
            bearing_str=b_str,
            text_angle_deg=text_angle_deg,
            p_left=p_left,
            p_right=p_right,
            text_left=text_left,
            text_right=text_right
        )

    @classmethod
    def annotate_line_coords(
        cls,
        coords: List[Tuple[float, float]],
        mode: str = "LR",
        unit: str = UNITS_METERS,
        reverse_direction: bool = False,
        text_height: float = 2.5
    ) -> List[SegmentAnnotation]:
        """Annotates multiple consecutive line vertices."""
        results = []
        if len(coords) < 2:
            return results

        for i in range(len(coords) - 1):
            ann = cls.annotate_segment(
                coords[i],
                coords[i + 1],
                mode=mode,
                unit=unit,
                reverse_direction=reverse_direction,
                text_height=text_height,
                segment_id=i + 1
            )
            if ann:
                results.append(ann)
        return results

