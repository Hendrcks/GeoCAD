"""
GeoCad - Master CAD Workbench Dialog.
Integrates all survey engineering modules into a unified tabbed QGIS workstation:
1. Lot Traverse Plotter (Bearing & Distance)
2. Field Coordinate Point Ingestion (NEZL, NEL, KDMS) & Sequential Boundary Lines
3. Boundary Bearing and Distance Annotation (Meters & Feet)
4. Cartographic Survey Grid Generator
5. Delaunay TIN Surface Modeler & Diagnostics
6. Topographic Contour Generator & Hypsometric Tinting
7. About & Help
"""

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
        QPushButton, QStatusBar
    )
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtGui import QIcon
    from PyQt5.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
        QPushButton, QStatusBar
    )

from .core.compat import exec_dialog
from .ui.lot_plotter_widget import LotPlotterWidget
from .ui.point_plotter_widget import PointPlotterWidget
from .ui.bearing_distance_widget import BearingDistanceWidget
from .ui.grid_widget import SurveyGridWidget
from .ui.tin_widget import TinWidget
from .ui.contour_widget import ContourWidget
from .ui.about_dialog import AboutDialog


class GeoCadDialog(QDialog):
    """Primary CAD and Land Surveying Workbench for QGIS Desktop."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("GeoCad — Professional Land Surveying & Cadastral Suite")
        self.resize(980, 680)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(8)

        # Header Banner
        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title_lbl = QLabel("GeoCad Workbench")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #1565c0;")
        sub_lbl = QLabel("Precision Surveying & Cadastral Engine")
        sub_lbl.setStyleSheet("font-size: 11px; color: #666;")
        title_box.addWidget(title_lbl)
        title_box.addWidget(sub_lbl)
        header.addLayout(title_box)
        header.addStretch()

        self.btn_about = QPushButton("About / Help")
        self.btn_about.clicked.connect(self._open_about)
        header.addWidget(self.btn_about)
        layout.addLayout(header)

        # Main Tabbed Workspace
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)

        # Tab 1: Lot Traverse Plotter
        self.tab_traverse = LotPlotterWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_traverse, "Lot Plotter (Bearing & Distance)")

        # Tab 2: Point Plotting & Sequential Boundary Lines
        self.tab_points = PointPlotterWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_points, "Point Ingestion & Boundaries")

        # Tab 3: Bearing & Distance Annotation
        self.tab_beadist = BearingDistanceWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_beadist, "Bearing & Distance (Ft / M)")

        # Tab 4: Cartographic Survey Grid
        self.tab_grid = SurveyGridWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_grid, "Survey Grid Generator")

        # Tab 5: TIN Surface Modeling
        self.tab_tin = TinWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_tin, "TIN Surface Modeler")

        # Tab 6: Topographic Contours
        self.tab_contours = ContourWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_contours, "Topographic Contours")

        # Connect tab change listener to refresh dynamic layers
        self.tabs.currentChanged.connect(self._on_tab_changed)

        layout.addWidget(self.tabs, stretch=1)

        # Status Bar / Footer
        self.status = QStatusBar()
        self.status.showMessage("GeoCad Ready")
        self.status.setStyleSheet("color: #666; font-size: 10px;")
        layout.addWidget(self.status)

    def _on_tab_changed(self, index: int):
        """Refreshes layer dropdowns whenever the user switches tabs."""
        widget = self.tabs.widget(index)
        if widget and hasattr(widget, "_refresh_layers"):
            widget._refresh_layers()

    def showEvent(self, event):
        super().showEvent(event)
        self._on_tab_changed(self.tabs.currentIndex())

    def _open_about(self):
        dlg = AboutDialog(parent=self)
        exec_dialog(dlg)
