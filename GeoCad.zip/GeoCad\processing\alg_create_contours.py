"""
GeoCad Processing Algorithm: Extract & Smooth Topographic Contours.
Interpolates contours from TIN surfaces with cubic spline smoothing (smocont)
and Index/Intermediate classification.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.core import (
        QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer,
        QgsProcessingParameterNumber, QgsProcessingParameterBoolean,
        QgsProcessingParameterFeatureSink, QgsFeature, QgsGeometry,
        QgsPointXY, QgsFields, QgsField, QgsWkbTypes
    )
    from qgis.PyQt.QtCore import QVariant
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm: pass

from ..core.compat import make_qgs_field
from ..core.contour_engine import ContourEngine
from ..core.tin_engine import TinEngine, TinTriangle


class CreateContoursAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to extract contours from surfaces."""

    INPUT_SURFACE = "INPUT_SURFACE"
    INTERVAL = "INTERVAL"
    INDEX_MULTIPLIER = "INDEX_MULTIPLIER"
    SMOOTH = "SMOOTH"
    OUTPUT_CONTOURS = "OUTPUT_CONTOURS"

    def createInstance(self):
        return CreateContoursAlgorithm()

    def name(self):
        return "create_contours"

    def displayName(self):
        return "Extract & Smooth Topographic Contours"

    def group(self):
        return "Terrain & Surfaces"

    def groupId(self):
        return "terrain"

    def shortHelpString(self):
        return "Interpolates topographic contours at user-defined intervals with cubic spline smoothing and major/minor tagging."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT_SURFACE, "TIN Surface (PolygonZ) or Points", types=[QgsProcessing.TypeVectorPolygon, QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterNumber(self.INTERVAL, "Contour Interval dz (m)", type=QgsProcessingParameterNumber.Double, defaultValue=2.0))
        self.addParameter(QgsProcessingParameterNumber(self.INDEX_MULTIPLIER, "Index Contour Multiplier (e.g. 5 = every 5th)", type=QgsProcessingParameterNumber.Integer, defaultValue=5))
        self.addParameter(QgsProcessingParameterBoolean(self.SMOOTH, "Apply Cubic Spline Smoothing", defaultValue=True))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT_CONTOURS, "Contour Polylines Output", type=QgsProcessing.TypeVectorLine))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT_SURFACE, context)
        interval = self.parameterAsDouble(parameters, self.INTERVAL, context)
        index_mult = self.parameterAsInt(parameters, self.INDEX_MULTIPLIER, context)
        smooth = self.parameterAsBoolean(parameters, self.SMOOTH, context)

        triangles = []
        if layer.geometryType() == QgsWkbTypes.PolygonGeometry:
            tid = 1
            for feat in layer.getFeatures():
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                poly = geom.asPolygon()
                if poly and len(poly[0]) >= 4:
                    ring = poly[0]
                    v1 = (ring[0].x(), ring[0].y(), ring[0].z() if hasattr(ring[0], 'z') else 0.0)
                    v2 = (ring[1].x(), ring[1].y(), ring[1].z() if hasattr(ring[1], 'z') else 0.0)
                    v3 = (ring[2].x(), ring[2].y(), ring[2].z() if hasattr(ring[2], 'z') else 0.0)
                    triangles.append(TinTriangle(id=tid, v1=v1, v2=v2, v3=v3))
                    tid += 1
        else:
            pts = []
            for feat in layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    p = geom.asPoint()
                    z = geom.constGet().z() if geom.constGet().is3D() else 0.0
                    pts.append((p.x(), p.y(), z))
            triangles, _ = TinEngine.build_tin(pts)

        res = ContourEngine.generate_contours(
            triangles=triangles,
            interval=interval,
            index_multiplier=index_mult,
            smooth=smooth
        )

        fields = QgsFields()
        fields.append(make_qgs_field("Contour_ID", "int"))
        fields.append(make_qgs_field("Elevation", "double"))
        fields.append(make_qgs_field("Level_Type", "string"))
        fields.append(make_qgs_field("Length_m", "double"))
        fields.append(make_qgs_field("Color_Hex", "string"))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_CONTOURS, context, fields, QgsWkbTypes.LineString, layer.crs()
        )

        for c in res.contours:
            qpts = [QgsPointXY(pt[0], pt[1]) for pt in c.coordinates]
            geom = QgsGeometry.fromPolylineXY(qpts)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([c.id, c.elevation, c.level_type, c.length, c.color_hex])
            sink.addFeature(f)

        return {self.OUTPUT_CONTOURS: dest_id}

