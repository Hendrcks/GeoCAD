"""
GeoCad Compatibility Layer for Qt5 / Qt6 and QGIS 3 / QGIS 4.
Provides seamless cross-version abstractions for QHeaderView resize modes,
Qt alignment flags, QFrame styles, QgsField constructors, and PalLabelPlacement enums.

Developed by GeoCad (geocad@example.com).
"""

from typing import Any

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHeaderView, QFrame, QMessageBox
    HAS_QT = True
except ImportError:
    try:
        from PyQt5.QtCore import Qt
        from PyQt5.QtWidgets import QHeaderView, QFrame, QMessageBox
        HAS_QT = True
    except ImportError:
        HAS_QT = False


# --- QHeaderView Resize Modes ---
if HAS_QT and hasattr(QHeaderView, "ResizeMode"):
    # Qt6 / PyQt6 (QGIS 4)
    HEADER_RESIZE_TO_CONTENTS = QHeaderView.ResizeMode.ResizeToContents
    HEADER_STRETCH = QHeaderView.ResizeMode.Stretch
    HEADER_FIXED = QHeaderView.ResizeMode.Fixed
    HEADER_INTERACTIVE = QHeaderView.ResizeMode.Interactive
elif HAS_QT:
    # Qt5 / PyQt5 (QGIS 3)
    HEADER_RESIZE_TO_CONTENTS = QHeaderView.ResizeToContents
    HEADER_STRETCH = QHeaderView.Stretch
    HEADER_FIXED = QHeaderView.Fixed
    HEADER_INTERACTIVE = QHeaderView.Interactive
else:
    HEADER_RESIZE_TO_CONTENTS = 3
    HEADER_STRETCH = 1
    HEADER_FIXED = 2
    HEADER_INTERACTIVE = 0


# --- Qt Alignment Flags ---
if HAS_QT and hasattr(Qt, "AlignmentFlag"):
    # Qt6 / PyQt6 (QGIS 4)
    ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    ALIGN_RIGHT = Qt.AlignmentFlag.AlignRight
    ALIGN_LEFT = Qt.AlignmentFlag.AlignLeft
    ALIGN_VCENTER = Qt.AlignmentFlag.AlignVCenter
    ALIGN_RIGHT_VCENTER = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
    ALIGN_LEFT_VCENTER = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
elif HAS_QT:
    # Qt5 / PyQt5 (QGIS 3)
    ALIGN_CENTER = Qt.AlignCenter
    ALIGN_RIGHT = Qt.AlignRight
    ALIGN_LEFT = Qt.AlignLeft
    ALIGN_VCENTER = Qt.AlignVCenter
    ALIGN_RIGHT_VCENTER = Qt.AlignRight | Qt.AlignVCenter
    ALIGN_LEFT_VCENTER = Qt.AlignLeft | Qt.AlignVCenter
else:
    ALIGN_CENTER = 4
    ALIGN_RIGHT = 2
    ALIGN_LEFT = 1
    ALIGN_VCENTER = 128
    ALIGN_RIGHT_VCENTER = 130
    ALIGN_LEFT_VCENTER = 129


# --- QFrame Shapes & Shadows ---
if HAS_QT and hasattr(QFrame, "Shape"):
    # Qt6 / PyQt6 (QGIS 4)
    FRAME_HLINE = QFrame.Shape.HLine
    FRAME_VLINE = QFrame.Shape.VLine
    FRAME_SUNKEN = QFrame.Shadow.Sunken
elif HAS_QT:
    # Qt5 / PyQt5 (QGIS 3)
    FRAME_HLINE = QFrame.HLine
    FRAME_VLINE = QFrame.VLine
    FRAME_SUNKEN = QFrame.Sunken
else:
    FRAME_HLINE = 4
    FRAME_VLINE = 5
    FRAME_SUNKEN = 48


# --- QGIS Field Data Types ---
try:
    from qgis.PyQt.QtCore import QMetaType
    FIELD_TYPE_STRING = QMetaType.Type.QString
    FIELD_TYPE_DOUBLE = QMetaType.Type.Double
    FIELD_TYPE_INT = QMetaType.Type.Int
    FIELD_TYPE_BOOL = QMetaType.Type.Bool
except (ImportError, AttributeError):
    try:
        from qgis.PyQt.QtCore import QVariant
        FIELD_TYPE_STRING = QVariant.String
        FIELD_TYPE_DOUBLE = QVariant.Double
        FIELD_TYPE_INT = QVariant.Int
        FIELD_TYPE_BOOL = QVariant.Bool
    except (ImportError, AttributeError):
        FIELD_TYPE_STRING = 10
        FIELD_TYPE_DOUBLE = 6
        FIELD_TYPE_INT = 2
        FIELD_TYPE_BOOL = 1


def make_qgs_field(name: str, type_str: str = "string", length: int = 0, precision: int = 0):
    """Creates a QgsField compatible with both QGIS 3 (Qt5) and QGIS 4 (Qt6)."""
    t = type_str.lower()
    if t in ("string", "str"):
        ftype = FIELD_TYPE_STRING
    elif t in ("double", "float", "real"):
        ftype = FIELD_TYPE_DOUBLE
    elif t in ("int", "integer"):
        ftype = FIELD_TYPE_INT
    elif t in ("bool", "boolean"):
        ftype = FIELD_TYPE_BOOL
    else:
        ftype = FIELD_TYPE_STRING

    try:
        from qgis.core import QgsField
        return QgsField(name, ftype, typeName=t, len=length, prec=precision)
    except (TypeError, AttributeError):
        try:
            from qgis.core import QgsField
            return QgsField(name, ftype, t, length, precision)
        except (TypeError, AttributeError):
            from qgis.core import QgsField
            return QgsField(name, ftype)


def exec_dialog(dialog) -> int:
    """Executes a dialog modally across Qt5 (.exec_()) and Qt6 (.exec())."""
    if hasattr(dialog, "exec"):
        return dialog.exec()
    return dialog.exec_()


def set_label_placement(settings, placement: str = "AroundPoint"):
    """
    Sets placement on QgsPalLayerSettings compatibly across QGIS 3 and QGIS 4.
    In QGIS 4, QgsPalLayerSettings.placement expects a member of Qgis.LabelPlacement,
    whereas QgsPalLayerSettings.OverPoint is mapped to LabelPredefinedPointPosition.
    Supported placement values: 'AroundPoint', 'OverPoint', 'Line', 'Curved', 'Horizontal'.
    """
    try:
        from qgis.core import Qgis
        if hasattr(Qgis, 'LabelPlacement') and hasattr(Qgis.LabelPlacement, placement):
            settings.placement = getattr(Qgis.LabelPlacement, placement)
            return
    except (ImportError, AttributeError) as err:
        _ = err

    try:
        from qgis.core import QgsPalLayerSettings
        if hasattr(QgsPalLayerSettings, 'Placement') and hasattr(QgsPalLayerSettings.Placement, placement):
            settings.placement = getattr(QgsPalLayerSettings.Placement, placement)
            return
        if hasattr(QgsPalLayerSettings, placement):
            val = getattr(QgsPalLayerSettings, placement)
            if "LabelPredefinedPointPosition" not in str(type(val)):
                settings.placement = val
                return
    except (ImportError, AttributeError) as err:
        _ = err

    placement_map = {
        'AroundPoint': 0,
        'OverPoint': 1,
        'Line': 2,
        'Curved': 3,
        'Horizontal': 4,
    }
    fallback_val = placement_map.get(placement, 0)
    try:
        settings.placement = fallback_val
    except (AttributeError, TypeError) as err:
        _ = err


# --- Qt Cursor Shapes (Qt5 / Qt6 compatible) ---
if HAS_QT and hasattr(Qt, "CursorShape"):
    CURSOR_WAIT = Qt.CursorShape.WaitCursor
    CURSOR_CROSS = Qt.CursorShape.CrossCursor
elif HAS_QT:
    CURSOR_WAIT = Qt.WaitCursor
    CURSOR_CROSS = Qt.CrossCursor
else:
    CURSOR_WAIT = 3
    CURSOR_CROSS = 2


# --- QMessageBox StandardButtons (Qt5 / Qt6 compatible) ---
if HAS_QT and hasattr(QMessageBox, "StandardButton"):
    MSG_YES = QMessageBox.StandardButton.Yes
    MSG_NO = QMessageBox.StandardButton.No
    MSG_OK = QMessageBox.StandardButton.Ok
    MSG_CANCEL = QMessageBox.StandardButton.Cancel
elif HAS_QT:
    MSG_YES = QMessageBox.Yes
    MSG_NO = QMessageBox.No
    MSG_OK = QMessageBox.Ok
    MSG_CANCEL = QMessageBox.Cancel
else:
    MSG_YES = 16384
    MSG_NO = 65536
    MSG_OK = 1024
    MSG_CANCEL = 4194304


def get_project_crs_authid() -> str:
    """Returns the active QGIS project CRS authid (e.g. 'EPSG:32630'), or '' if unset."""
    try:
        from qgis.core import QgsProject
        crs = QgsProject.instance().crs()
        if crs and crs.isValid() and crs.authid():
            return crs.authid()
    except (ImportError, AttributeError) as err:
        _ = err
    return ""


def get_project_crs_display() -> str:
    """Returns a formatted 'AUTHID — Description' string for the active QGIS project CRS."""
    try:
        from qgis.core import QgsProject
        crs = QgsProject.instance().crs()
        if crs and crs.isValid():
            auth = crs.authid()
            desc = crs.description()
            if auth and desc:
                return f"{auth} — {desc}"
            return auth or desc or ""
    except (ImportError, AttributeError) as err:
        _ = err
    return ""


def resolve_crs_authid(text: str, fallback: str = "EPSG:4326") -> str:
    """Extracts an authid from 'AUTHID — Description' or falls back to Project CRS / WGS84."""
    if text:
        candidate = text.split("—")[0].split(" - ")[0].strip()
        if candidate:
            return candidate
    proj_crs = get_project_crs_authid()
    if proj_crs:
        return proj_crs
    return fallback


def zoom_canvas_to_layer(iface, layer):
    """Zooms the QGIS map canvas to a layer extent, transforming CRS if needed."""
    if not iface or not layer:
        return
    try:
        from qgis.core import QgsProject, QgsCoordinateTransform
        canvas = iface.mapCanvas()
        extent = layer.extent()
        if extent.isEmpty():
            return
        layer_crs = layer.crs()
        canvas_crs = canvas.mapSettings().destinationCrs()
        if layer_crs.isValid() and canvas_crs.isValid() and layer_crs != canvas_crs:
            xform = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())
            extent = xform.transformBoundingBox(extent)
        extent.scale(1.15)
        canvas.setExtent(extent)
        canvas.refresh()
    except (ImportError, AttributeError, RuntimeError) as err:
        _ = err
