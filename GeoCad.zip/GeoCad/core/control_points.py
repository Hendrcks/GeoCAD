"""
GeoCad - International Survey Control Point & Benchmark Store.
Manages user-defined survey benchmarks, control monuments, CSV catalog imports/exports,
and real-time search across saved stations without any regional hardcoding.
"""

import csv
import io
import json
import os
from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple


@dataclass
class ControlPoint:
    """Represents an international survey control monument or benchmark."""
    station_id: str
    easting: float
    northing: float
    elevation: float = 0.0
    crs_authid: str = ""
    description: str = ""
    source: str = "Saved"

    def to_dict(self) -> dict:
        data = asdict(self)
        data.pop("source", None)
        return data

    @classmethod
    def from_dict(cls, data: dict, source: str = "Saved") -> "ControlPoint":
        return cls(
            station_id=str(data.get("station_id", "")).strip(),
            easting=float(data.get("easting", 0.0)),
            northing=float(data.get("northing", 0.0)),
            elevation=float(data.get("elevation", 0.0)),
            crs_authid=str(data.get("crs_authid", "")).strip(),
            description=str(data.get("description", "")).strip(),
            source=source,
        )


class ControlPointStore:
    """Persistent JSON store and CSV importer/exporter for survey control points."""

    FILENAME = "geocad_control_points.json"

    @classmethod
    def get_storage_path(cls) -> str:
        """Returns a writable path inside the active QGIS profile or user home folder."""
        base_dir = ""
        try:
            from qgis.core import QgsApplication
            settings_dir = QgsApplication.qgisSettingsDirPath()
            if settings_dir and os.path.isdir(settings_dir):
                base_dir = settings_dir
        except (ImportError, AttributeError) as err:
            _ = err

        if not base_dir:
            base_dir = os.path.join(os.path.expanduser("~"), ".geocad")

        os.makedirs(base_dir, exist_ok=True)
        return os.path.join(base_dir, cls.FILENAME)

    @classmethod
    def load(cls, storage_path: Optional[str] = None) -> List[ControlPoint]:
        """Loads all saved control points. Returns an empty list if none are saved yet."""
        path = storage_path or cls.get_storage_path()
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            if not isinstance(raw, list):
                return []
            points: List[ControlPoint] = []
            for item in raw:
                if isinstance(item, dict) and item.get("station_id"):
                    try:
                        points.append(ControlPoint.from_dict(item, source="Saved"))
                    except (ValueError, TypeError) as err:
                        _ = err
            return points
        except (OSError, ValueError, TypeError) as err:
            _ = err
            return []

    @classmethod
    def save(cls, points: List[ControlPoint], storage_path: Optional[str] = None) -> str:
        """Persists saved control points to JSON."""
        path = storage_path or cls.get_storage_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        payload = [pt.to_dict() for pt in points if pt.source == "Saved"]
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        return path

    @classmethod
    def add_or_update(
        cls,
        point: ControlPoint,
        storage_path: Optional[str] = None
    ) -> List[ControlPoint]:
        """Adds a new control point or updates an existing one with matching station_id."""
        points = cls.load(storage_path=storage_path)
        point.source = "Saved"
        key = point.station_id.strip().lower()
        updated = False
        for idx, existing in enumerate(points):
            if existing.station_id.strip().lower() == key:
                points[idx] = point
                updated = True
                break
        if not updated:
            points.append(point)
        cls.save(points, storage_path=storage_path)
        return points

    @classmethod
    def delete(cls, station_id: str, storage_path: Optional[str] = None) -> List[ControlPoint]:
        """Deletes a saved control point by station_id."""
        points = cls.load(storage_path=storage_path)
        key = station_id.strip().lower()
        remaining = [pt for pt in points if pt.station_id.strip().lower() != key]
        cls.save(remaining, storage_path=storage_path)
        return remaining

    @classmethod
    def search(cls, points: List[ControlPoint], query: str) -> List[ControlPoint]:
        """Filters control points by station ID, description, CRS, source, or coordinates."""
        q = (query or "").strip().lower()
        if not q:
            return list(points)
        terms = q.split()
        matches: List[ControlPoint] = []
        for pt in points:
            haystack = " ".join([
                pt.station_id,
                pt.description,
                pt.crs_authid,
                pt.source,
                f"{pt.easting:.4f}",
                f"{pt.northing:.4f}",
                f"{pt.elevation:.3f}",
            ]).lower()
            if all(term in haystack for term in terms):
                matches.append(pt)
        return matches

    @classmethod
    def import_csv(
        cls,
        filepath: str,
        default_crs: str = ""
    ) -> Tuple[List[ControlPoint], List[str]]:
        """
        Imports control points from a CSV/TXT file.
        Auto-detects comma, semicolon, or tab delimiters and header column mapping.
        Supports columns: Station/ID/Name/Benchmark, Easting/X, Northing/Y,
        Elevation/Z, CRS/EPSG, Description/Notes.
        """
        with open(filepath, "r", encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        return cls.parse_csv_content(content, default_crs=default_crs)

    @classmethod
    def parse_csv_content(
        cls,
        content: str,
        default_crs: str = ""
    ) -> Tuple[List[ControlPoint], List[str]]:
        """Parses CSV/TXT text into ControlPoint records and warning messages."""
        lines = [ln.strip() for ln in content.splitlines() if ln.strip() and not ln.strip().startswith("#")]
        if not lines:
            return [], ["File is empty."]

        sample = lines[0]
        delimiter = ","
        if "," in sample:
            delimiter = ","
        elif ";" in sample:
            delimiter = ";"
        elif "\t" in sample:
            delimiter = "\t"

        rows = list(csv.reader(io.StringIO("\n".join(lines)), delimiter=delimiter))
        if not rows:
            return [], ["No rows found."]

        first = [cell.strip().lower() for cell in rows[0]]
        col_map = {}
        for idx, name in enumerate(first):
            if any(k in name for k in ("station", "benchmark", "monument", "point", "name", "id", "stn", "bm", "code")):
                col_map.setdefault("id", idx)
            elif any(k in name for k in ("east", "grid_x", "coord_x", "lon")) or name in ("x", "e"):
                col_map.setdefault("easting", idx)
            elif any(k in name for k in ("north", "grid_y", "coord_y", "lat")) or name in ("y", "n"):
                col_map.setdefault("northing", idx)
            elif any(k in name for k in ("elev", "height", "alt", "rl")) or name in ("z", "h"):
                col_map.setdefault("elevation", idx)
            elif any(k in name for k in ("crs", "epsg", "datum", "proj", "srid")):
                col_map.setdefault("crs", idx)
            elif any(k in name for k in ("desc", "note", "loc", "remark", "label")):
                col_map.setdefault("desc", idx)

        has_header = "easting" in col_map and "northing" in col_map
        data_rows = rows[1:] if has_header else rows

        imported: List[ControlPoint] = []
        warnings: List[str] = []

        for row_idx, row in enumerate(data_rows, start=2 if has_header else 1):
            cells = [c.strip() for c in row]
            if len(cells) < 3:
                warnings.append(f"Row {row_idx}: skipped (fewer than 3 columns).")
                continue
            try:
                if has_header:
                    stn_id = cells[col_map["id"]] if "id" in col_map and col_map["id"] < len(cells) else f"CP-{row_idx}"
                    easting = float(cells[col_map["easting"]].replace(",", ""))
                    northing = float(cells[col_map["northing"]].replace(",", ""))
                    elev = (
                        float(cells[col_map["elevation"]].replace(",", ""))
                        if "elevation" in col_map and col_map["elevation"] < len(cells) and cells[col_map["elevation"]]
                        else 0.0
                    )
                    crs_val = (
                        cells[col_map["crs"]]
                        if "crs" in col_map and col_map["crs"] < len(cells) and cells[col_map["crs"]]
                        else default_crs
                    )
                    desc = (
                        cells[col_map["desc"]]
                        if "desc" in col_map and col_map["desc"] < len(cells)
                        else ""
                    )
                else:
                    # Standard headerless format: Station_ID, Easting, Northing [, Elevation [, CRS [, Description]]]
                    stn_id = cells[0] or f"CP-{row_idx}"
                    easting = float(cells[1].replace(",", ""))
                    northing = float(cells[2].replace(",", ""))
                    elev = 0.0
                    crs_val = default_crs
                    desc = ""
                    if len(cells) >= 4 and cells[3]:
                        try:
                            elev = float(cells[3].replace(",", ""))
                        except ValueError:
                            desc = cells[3]
                    if len(cells) >= 5 and cells[4]:
                        if cells[4].upper().startswith("EPSG:"):
                            crs_val = cells[4]
                        elif not desc:
                            desc = cells[4]
                    if len(cells) >= 6 and cells[5]:
                        desc = cells[5]

                imported.append(
                    ControlPoint(
                        station_id=stn_id,
                        easting=easting,
                        northing=northing,
                        elevation=elev,
                        crs_authid=crs_val,
                        description=desc,
                        source="Saved",
                    )
                )
            except (ValueError, IndexError) as err:
                warnings.append(f"Row {row_idx}: invalid numeric data ({err}).")

        return imported, warnings

    @classmethod
    def export_csv(cls, filepath: str, points: List[ControlPoint]) -> None:
        """Exports control points to a standard international CSV catalog."""
        with open(filepath, "w", encoding="utf-8", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(["Station_ID", "Easting", "Northing", "Elevation", "CRS", "Description"])
            for pt in points:
                writer.writerow([
                    pt.station_id,
                    f"{pt.easting:.4f}",
                    f"{pt.northing:.4f}",
                    f"{pt.elevation:.3f}",
                    pt.crs_authid,
                    pt.description,
                ])

