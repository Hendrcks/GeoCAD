"""
GeoCad - International Survey Control Point & Benchmark Lookup Dialog.
Allows surveyors worldwide to:
1. Search & manage their own saved Benchmarks / Control Monuments (persisted in QGIS profile).
2. Import or export regional/project benchmark catalogs (CSV / TXT).
3. Search control points directly from active Point vector layers loaded in QGIS
   with automatic CRS transformation to the active Target CRS.

Compatible with QGIS 3 (Qt5) and QGIS 4 (Qt6).
"""

from typing import List, Optional

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QCheckBox, QTableWidget,
        QTableWidgetItem, QMessageBox, QFileDialog, QAbstractItemView
    )
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsWkbTypes,
        QgsCoordinateReferenceSystem, QgsCoordinateTransform
    )
    from qgis.gui import QgsProjectionSelectionDialog
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QCheckBox, QTableWidget,
        QTableWidgetItem, QMessageBox, QFileDialog, QAbstractItemView
    )
    HAS_QGIS = False

from ..core.compat import (
    HEADER_RESIZE_TO_CONTENTS,
    HEADER_STRETCH,
    ALIGN_RIGHT_VCENTER,
    MSG_YES,
    exec_dialog,
    get_project_crs_authid,
)
from ..core.control_points import ControlPoint, ControlPointStore

# Qt5 / Qt6 compatible table behavior enums
if hasattr(QAbstractItemView, "SelectionBehavior"):
    SELECT_ROWS = QAbstractItemView.SelectionBehavior.SelectRows
    SINGLE_SELECTION = QAbstractItemView.SelectionMode.SingleSelection
    NO_EDIT_TRIGGERS = QAbstractItemView.EditTrigger.NoEditTriggers
else:
    SELECT_ROWS = QAbstractItemView.SelectRows
    SINGLE_SELECTION = QAbstractItemView.SingleSelection
    NO_EDIT_TRIGGERS = QAbstractItemView.NoEditTriggers


class ControlPointDialog(QDialog):
    """International Survey Benchmark & Control Point Manager and Search Dialog."""

    def __init__(
        self,
        target_crs_authid: str = "",
        initial_query: str = "",
        parent=None
    ):
        super().__init__(parent)
        self.setWindowTitle("GeoCad — Survey Control Point & Benchmark Lookup")
        self.resize(840, 560)
        self.target_crs_authid = (target_crs_authid or get_project_crs_authid()).strip()
        self.selected_point: Optional[ControlPoint] = None
        self.apply_crs: bool = False
        self._all_points: List[ControlPoint] = []
        self._visible_points: List[ControlPoint] = []

        self._init_ui(initial_query)
        self._reload_points()

    def _init_ui(self, initial_query: str):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # === SEARCH BAR ===
        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("Search Benchmark / Station:"))
        self.txt_search = QLineEdit(initial_query)
        self.txt_search.setPlaceholderText("Filter by station ID, description, CRS, or coordinates...")
        self.txt_search.textChanged.connect(self._apply_filter)
        search_row.addWidget(self.txt_search, stretch=1)

        self.chk_qgis_layers = QCheckBox("Include QGIS Point Layers")
        self.chk_qgis_layers.setChecked(True)
        self.chk_qgis_layers.setToolTip(
            "Automatically include features from Point vector layers in the current QGIS project "
            "(transformed to the active Target CRS when needed)."
        )
        self.chk_qgis_layers.toggled.connect(self._reload_points)
        search_row.addWidget(self.chk_qgis_layers)

        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.clicked.connect(self._reload_points)
        search_row.addWidget(self.btn_refresh)
        layout.addLayout(search_row)

        # === TABLE ===
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Station / Benchmark ID", "Easting (X)", "Northing (Y)",
            "Elevation (Z)", "CRS", "Source", "Description"
        ])
        self.table.setSelectionBehavior(SELECT_ROWS)
        self.table.setSelectionMode(SINGLE_SELECTION)
        self.table.setEditTriggers(NO_EDIT_TRIGGERS)
        self.table.setAlternatingRowColors(True)

        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(0, HEADER_RESIZE_TO_CONTENTS)
        hdr.setSectionResizeMode(1, HEADER_RESIZE_TO_CONTENTS)
        hdr.setSectionResizeMode(2, HEADER_RESIZE_TO_CONTENTS)
        hdr.setSectionResizeMode(3, HEADER_RESIZE_TO_CONTENTS)
        hdr.setSectionResizeMode(4, HEADER_RESIZE_TO_CONTENTS)
        hdr.setSectionResizeMode(5, HEADER_RESIZE_TO_CONTENTS)
        hdr.setSectionResizeMode(6, HEADER_STRETCH)

        self.table.itemSelectionChanged.connect(self._on_selection_changed)
        self.table.cellDoubleClicked.connect(self._on_double_click)
        layout.addWidget(self.table, stretch=1)

        self.lbl_count = QLabel("0 control points available.")
        self.lbl_count.setStyleSheet("color: #555; font-size: 11px;")
        layout.addWidget(self.lbl_count)

        # === ADD / EDIT BENCHMARK FORM ===
        gb_edit = QGroupBox("Add / Update Saved Benchmark or Control Point")
        grid = QGridLayout(gb_edit)
        grid.setContentsMargins(10, 12, 10, 10)
        grid.setVerticalSpacing(6)

        grid.addWidget(QLabel("Station ID:"), 0, 0)
        self.txt_stn_id = QLineEdit()
        self.txt_stn_id.setPlaceholderText("e.g. BM-01, TP-104, CP-05")
        grid.addWidget(self.txt_stn_id, 0, 1)

        grid.addWidget(QLabel("Easting (X):"), 0, 2)
        self.txt_easting = QLineEdit()
        self.txt_easting.setPlaceholderText("Easting coordinate")
        grid.addWidget(self.txt_easting, 0, 3)

        grid.addWidget(QLabel("Northing (Y):"), 0, 4)
        self.txt_northing = QLineEdit()
        self.txt_northing.setPlaceholderText("Northing coordinate")
        grid.addWidget(self.txt_northing, 0, 5)

        grid.addWidget(QLabel("Elevation (Z):"), 1, 0)
        self.txt_elev = QLineEdit()
        self.txt_elev.setPlaceholderText("0.000 (optional)")
        grid.addWidget(self.txt_elev, 1, 1)

        grid.addWidget(QLabel("CRS:"), 1, 2)
        crs_row = QHBoxLayout()
        self.txt_crs = QLineEdit(self.target_crs_authid)
        self.txt_crs.setPlaceholderText("e.g. EPSG:32630")
        self.btn_pick_crs = QPushButton("...")
        self.btn_pick_crs.setFixedWidth(28)
        self.btn_pick_crs.clicked.connect(self._select_crs)
        crs_row.addWidget(self.txt_crs)
        crs_row.addWidget(self.btn_pick_crs)
        grid.addLayout(crs_row, 1, 3)

        grid.addWidget(QLabel("Description:"), 1, 4)
        self.txt_desc = QLineEdit()
        self.txt_desc.setPlaceholderText("Location / monument notes")
        grid.addWidget(self.txt_desc, 1, 5)

        # Catalog toolbar buttons
        cat_row = QHBoxLayout()
        self.btn_add_save = QPushButton("Save Benchmark")
        self.btn_add_save.clicked.connect(self._save_benchmark)
        self.btn_delete = QPushButton("Delete Selected")
        self.btn_delete.clicked.connect(self._delete_selected)
        self.btn_import_csv = QPushButton("Import CSV...")
        self.btn_import_csv.clicked.connect(self._import_csv)
        self.btn_export_csv = QPushButton("Export CSV...")
        self.btn_export_csv.clicked.connect(self._export_csv)

        cat_row.addWidget(self.btn_add_save)
        cat_row.addWidget(self.btn_delete)
        cat_row.addStretch()
        cat_row.addWidget(self.btn_import_csv)
        cat_row.addWidget(self.btn_export_csv)
        grid.addLayout(cat_row, 2, 0, 1, 6)

        layout.addWidget(gb_edit)

        # === FOOTER ===
        footer = QHBoxLayout()
        self.chk_apply_crs = QCheckBox("Also update Target CRS from selected control point")
        self.chk_apply_crs.setChecked(not bool(self.target_crs_authid))
        footer.addWidget(self.chk_apply_crs)
        footer.addStretch()

        self.btn_use = QPushButton("Use Selected Control Point")
        self.btn_use.setStyleSheet(
            "background-color: #2e7d32; color: white; font-weight: bold; padding: 6px 16px; border-radius: 4px;"
        )
        self.btn_use.clicked.connect(self._confirm_selection)

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)

        footer.addWidget(self.btn_use)
        footer.addWidget(self.btn_cancel)
        layout.addLayout(footer)

    def _scan_qgis_point_layers(self) -> List[ControlPoint]:
        """Reads point features from active QGIS point layers, transforming to Target CRS."""
        if not HAS_QGIS or not self.chk_qgis_layers.isChecked():
            return []

        results: List[ControlPoint] = []
        proj = QgsProject.instance()
        target_crs = QgsCoordinateReferenceSystem(self.target_crs_authid) if self.target_crs_authid else None
        if target_crs and not target_crs.isValid():
            target_crs = None

        id_candidates = (
            "station_id", "station", "benchmark", "bm", "point_id",
            "monument", "name", "id", "label", "code", "pt_id", "stn"
        )
        desc_candidates = ("description", "desc", "notes", "location", "remarks", "label")

        for layer in proj.mapLayers().values():
            if not isinstance(layer, QgsVectorLayer):
                continue
            if layer.geometryType() != QgsWkbTypes.PointGeometry:
                continue

            layer_crs = layer.crs()
            xform = None
            out_crs_id = layer_crs.authid() if layer_crs and layer_crs.isValid() else ""
            if target_crs and layer_crs and layer_crs.isValid() and layer_crs != target_crs:
                xform = QgsCoordinateTransform(layer_crs, target_crs, proj)
                out_crs_id = target_crs.authid()

            field_names = [f.name() for f in layer.fields()]
            lower_map = {fn.lower(): fn for fn in field_names}

            id_field = next((lower_map[c] for c in id_candidates if c in lower_map), None)
            desc_field = next((lower_map[c] for c in desc_candidates if c in lower_map and lower_map[c] != id_field), None)

            # Cap per-layer scan to avoid freezing on huge LiDAR/point-cloud layers
            count = 0
            for feat in layer.getFeatures():
                if count >= 2000:
                    break
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                if geom.isMultipart():
                    pts = geom.asMultiPoint()
                    if not pts:
                        continue
                    pt_xy = pts[0]
                    elev = 0.0
                else:
                    pt_xy = geom.asPoint()
                    g_pt = geom.constGet()
                    elev = float(g_pt.z()) if hasattr(g_pt, "z") and g_pt.is3D() else 0.0

                if xform is not None:
                    try:
                        pt_xy = xform.transform(pt_xy)
                    except RuntimeError as err:
                        _ = err

                stn_val = str(feat[id_field]).strip() if id_field and feat[id_field] is not None else f"{layer.name()} #{feat.id()}"
                desc_val = str(feat[desc_field]).strip() if desc_field and feat[desc_field] is not None else ""

                results.append(
                    ControlPoint(
                        station_id=stn_val,
                        easting=float(pt_xy.x()),
                        northing=float(pt_xy.y()),
                        elevation=elev,
                        crs_authid=out_crs_id,
                        description=desc_val,
                        source=f"Layer: {layer.name()}",
                    )
                )
                count += 1

        return results

    def _reload_points(self):
        saved = ControlPointStore.load()
        layer_pts = self._scan_qgis_point_layers()
        self._all_points = saved + layer_pts
        self._apply_filter()

    def _apply_filter(self):
        query = self.txt_search.text()
        self._visible_points = ControlPointStore.search(self._all_points, query)
        self._populate_table()

    def _populate_table(self):
        self.table.setRowCount(len(self._visible_points))
        for row_idx, pt in enumerate(self._visible_points):
            it_id = QTableWidgetItem(pt.station_id)
            it_e = QTableWidgetItem(f"{pt.easting:.4f}")
            it_n = QTableWidgetItem(f"{pt.northing:.4f}")
            it_z = QTableWidgetItem(f"{pt.elevation:.3f}")
            it_crs = QTableWidgetItem(pt.crs_authid)
            it_src = QTableWidgetItem(pt.source)
            it_desc = QTableWidgetItem(pt.description)

            it_e.setTextAlignment(ALIGN_RIGHT_VCENTER)
            it_n.setTextAlignment(ALIGN_RIGHT_VCENTER)
            it_z.setTextAlignment(ALIGN_RIGHT_VCENTER)

            self.table.setItem(row_idx, 0, it_id)
            self.table.setItem(row_idx, 1, it_e)
            self.table.setItem(row_idx, 2, it_n)
            self.table.setItem(row_idx, 3, it_z)
            self.table.setItem(row_idx, 4, it_crs)
            self.table.setItem(row_idx, 5, it_src)
            self.table.setItem(row_idx, 6, it_desc)

        total = len(self._all_points)
        shown = len(self._visible_points)
        if total == 0:
            self.lbl_count.setText(
                "No control points saved yet. Add a benchmark below, import a CSV catalog, "
                "or load a Point layer in QGIS."
            )
        else:
            self.lbl_count.setText(f"Showing {shown} of {total} control points.")

    def _on_selection_changed(self):
        row = self.table.currentRow()
        if 0 <= row < len(self._visible_points):
            pt = self._visible_points[row]
            self.txt_stn_id.setText(pt.station_id)
            self.txt_easting.setText(f"{pt.easting:.4f}")
            self.txt_northing.setText(f"{pt.northing:.4f}")
            self.txt_elev.setText(f"{pt.elevation:.3f}")
            self.txt_crs.setText(pt.crs_authid)
            self.txt_desc.setText(pt.description)

    def _on_double_click(self, row: int, _col: int):
        if 0 <= row < len(self._visible_points):
            self.selected_point = self._visible_points[row]
            self.apply_crs = self.chk_apply_crs.isChecked()
            self.accept()

    def _select_crs(self):
        if HAS_QGIS:
            selector = QgsProjectionSelectionDialog(self)
            curr = self.txt_crs.text().split("—")[0].strip()
            if curr:
                crs = QgsCoordinateReferenceSystem(curr)
                if crs.isValid():
                    selector.setCrs(crs)
            if exec_dialog(selector):
                self.txt_crs.setText(selector.crs().authid())

    def _save_benchmark(self):
        stn_id = self.txt_stn_id.text().strip()
        e_str = self.txt_easting.text().replace(",", "").strip()
        n_str = self.txt_northing.text().replace(",", "").strip()
        z_str = self.txt_elev.text().replace(",", "").strip()

        if not stn_id:
            QMessageBox.warning(self, "Missing Station ID", "Please enter a Station / Benchmark ID.")
            return
        try:
            easting = float(e_str)
            northing = float(n_str)
            elev = float(z_str) if z_str else 0.0
        except ValueError:
            QMessageBox.warning(
                self, "Invalid Coordinates", "Please enter valid numeric Easting, Northing, and Elevation values."
            )
            return

        pt = ControlPoint(
            station_id=stn_id,
            easting=easting,
            northing=northing,
            elevation=elev,
            crs_authid=self.txt_crs.text().split("—")[0].strip(),
            description=self.txt_desc.text().strip(),
            source="Saved",
        )
        ControlPointStore.add_or_update(pt)
        self._reload_points()
        # Select the saved row
        for idx, item in enumerate(self._visible_points):
            if item.station_id.lower() == stn_id.lower() and item.source == "Saved":
                self.table.selectRow(idx)
                break

    def _delete_selected(self):
        row = self.table.currentRow()
        if not (0 <= row < len(self._visible_points)):
            QMessageBox.warning(self, "Delete", "Please select a saved benchmark to delete.")
            return
        pt = self._visible_points[row]
        if pt.source != "Saved":
            QMessageBox.information(
                self,
                "Read-Only Source",
                f"'{pt.station_id}' comes from QGIS {pt.source} and cannot be deleted here."
            )
            return
        if QMessageBox.question(self, "Delete Benchmark", f"Delete saved control point '{pt.station_id}'?") == MSG_YES:
            ControlPointStore.delete(pt.station_id)
            self._reload_points()

    def _import_csv(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Import Control Points / Benchmarks Catalog",
            "",
            "CSV / Text Files (*.csv *.txt *.dat);;All Files (*.*)"
        )
        if not path:
            return
        try:
            imported, warnings = ControlPointStore.import_csv(path, default_crs=self.target_crs_authid)
            if not imported:
                msg = "\n".join(warnings[:5]) if warnings else "No valid rows found."
                QMessageBox.warning(self, "Import Notice", f"Could not import control points:\n{msg}")
                return
            for pt in imported:
                ControlPointStore.add_or_update(pt)
            self._reload_points()
            summary = f"Imported {len(imported)} control point(s) into your benchmark catalog."
            if warnings:
                summary += f"\n({len(warnings)} row(s) skipped.)"
            QMessageBox.information(self, "Import Complete", summary)
        except OSError as err:
            QMessageBox.critical(self, "Import Error", f"Failed to read file:\n{err}")

    def _export_csv(self):
        saved = ControlPointStore.load()
        if not saved:
            QMessageBox.information(self, "Export", "No saved benchmarks to export.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Saved Benchmarks", "geocad_control_points.csv", "CSV Files (*.csv)"
        )
        if not path:
            return
        try:
            ControlPointStore.export_csv(path, saved)
            QMessageBox.information(self, "Export Complete", f"Exported {len(saved)} benchmark(s) to:\n{path}")
        except OSError as err:
            QMessageBox.critical(self, "Export Error", f"Failed to export file:\n{err}")

    def _confirm_selection(self):
        row = self.table.currentRow()
        if 0 <= row < len(self._visible_points):
            self.selected_point = self._visible_points[row]
            self.apply_crs = self.chk_apply_crs.isChecked()
            self.accept()
            return

        # If user filled out the form directly and clicked "Use Selected Control Point", allow using it
        stn_id = self.txt_stn_id.text().strip()
        e_str = self.txt_easting.text().replace(",", "").strip()
        n_str = self.txt_northing.text().replace(",", "").strip()
        if e_str and n_str:
            try:
                self.selected_point = ControlPoint(
                    station_id=stn_id or "REF-01",
                    easting=float(e_str),
                    northing=float(n_str),
                    elevation=float(self.txt_elev.text().replace(",", "").strip() or 0.0),
                    crs_authid=self.txt_crs.text().split("—")[0].strip(),
                    description=self.txt_desc.text().strip(),
                    source="Manual",
                )
                self.apply_crs = self.chk_apply_crs.isChecked()
                self.accept()
                return
            except ValueError:
                QMessageBox.warning(self, "Invalid Coordinates", "Please enter valid numeric coordinates.")
                return

        QMessageBox.warning(self, "Selection Required", "Please select a control point from the list or add one below.")

