"""
GeoCad - About Dialog & Information Hub.
Compatible with QGIS 3 (Qt5) and QGIS 4 (Qt6).
"""

import os

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QPixmap
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame
    )
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtGui import QPixmap
    from PyQt5.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame
    )

from ..core.compat import ALIGN_CENTER, FRAME_HLINE, FRAME_SUNKEN


class AboutDialog(QDialog):
    """About dialog presenting GeoCad suite info."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("About GeoCad")
        self.setFixedSize(580, 520)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 20, 25, 20)
        layout.setSpacing(10)

        # Official Logo Banner
        logo_path = os.path.join(os.path.dirname(__file__), "..", "logo.png")
        if os.path.exists(logo_path):
            logo_lbl = QLabel()
            pix = QPixmap(logo_path)
            smooth = Qt.TransformationMode.SmoothTransformation if hasattr(Qt, "TransformationMode") else Qt.SmoothTransformation
            logo_lbl.setPixmap(pix.scaledToWidth(320, smooth))
            logo_lbl.setAlignment(ALIGN_CENTER)
            layout.addWidget(logo_lbl)
        else:
            title = QLabel("GeoCad")
            title.setStyleSheet("font-size: 26px; font-weight: bold; color: #d32f2f;")
            title.setAlignment(ALIGN_CENTER)
            layout.addWidget(title)

        subtitle = QLabel("Precision Land Surveying & Cadastral CAD Suite for QGIS")
        subtitle.setStyleSheet("font-size: 13px; font-weight: 500; color: #444;")
        subtitle.setAlignment(ALIGN_CENTER)
        layout.addWidget(subtitle)

        ver = QLabel("Version 2.0.0 • QGIS 3.0.0 – 4.9.9 (Qt5 & Qt6)")
        ver.setStyleSheet("font-size: 11px; color: #777; margin-bottom: 2px;")
        ver.setAlignment(ALIGN_CENTER)
        layout.addWidget(ver)

        # Separator line
        sep = QFrame()
        sep.setFrameShape(FRAME_HLINE)
        sep.setFrameShadow(FRAME_SUNKEN)
        layout.addWidget(sep)

        # Details
        info_html = (
            "<p style='font-size: 12px; line-height: 1.55; color: #333; text-align: center;'>"
            "<b>GeoCad</b> brings comprehensive land surveying, cadastral boundary computation, "
            "and terrain modeling capabilities directly to QGIS Desktop.<br><br>"
            "<b>Key Capabilities:</b><br>"
            "• Cadastral Lot Traverse Plotter (OCR, Image Upload, Clipboard Paste, CSV Import)<br>"
            "• Field Coordinate Point Ingestion & Sequential Boundaries (seqline)<br>"
            "• Surveyor Bearing & Distance Annotation (Meters & Feet)<br>"
            "• Cartographic Survey Grid Generator with Collar Callouts<br>"
            "• Delaunay TIN Surface Modeling & 3D Terrain Analytics<br>"
            "• Topographic Contour Generation with Spline Smoothing & Tinting<br><br>"
            "<b>Developer:</b> AriesPlus Geospatial Solutions<br>"
            "<b>Contact / WhatsApp:</b> +233 (0) 593400774 / 0503809181<br>"
            "<b>Email:</b> <a href='mailto:ariesplusgeo@gmail.com'>ariesplusgeo@gmail.com</a><br>"
            "<b>GitHub:</b> <a href='https://github.com/Hendrcks/GeoCAD'>https://github.com/Hendrcks/GeoCAD</a><br>"
            "<b>License:</b> GNU General Public License v2.0 or later"
            "</p>"
        )
        info_label = QLabel(info_html)
        info_label.setWordWrap(True)
        info_label.setOpenExternalLinks(True)
        info_label.setAlignment(ALIGN_CENTER)
        layout.addWidget(info_label)

        # AriesPlus Geospatial Solutions Logo Footer
        ap_logo_path = os.path.join(os.path.dirname(__file__), "..", "ariesplus_logo.png")
        if os.path.exists(ap_logo_path):
            ap_lbl = QLabel()
            ap_pix = QPixmap(ap_logo_path)
            smooth = Qt.TransformationMode.SmoothTransformation if hasattr(Qt, "TransformationMode") else Qt.SmoothTransformation
            ap_lbl.setPixmap(ap_pix.scaledToHeight(34, smooth))
            ap_lbl.setAlignment(ALIGN_CENTER)
            layout.addWidget(ap_lbl)

        layout.addStretch()

        # Close Button
        btn_box = QHBoxLayout()
        btn_box.addStretch()
        btn_close = QPushButton("Close")
        btn_close.setFixedWidth(100)
        btn_close.setStyleSheet("padding: 6px 15px; font-weight: bold;")
        btn_close.clicked.connect(self.accept)
        btn_box.addWidget(btn_close)
        btn_box.addStretch()
        layout.addLayout(btn_box)
