"""
GeoCad - Main Cadastral Lot Plotter Widget.
Implements the 4-quadrant international surveying workbench:
1. Lot Information & Dynamic Project/Target CRS
2. Coordinate System (Grid, Plane, Control Monument/Benchmark Lookup, Interactive Map Picker & Tie-Line Calculator)
3. Lot Traverse Table with OCR / CSV / Paste Ingestion
4. Live Metrics Footer & Lot Generation to QGIS Canvas

Compatible with QGIS 3 (Qt5) and QGIS 4 (Qt6).
"""

import os
from typing import List, Dict, Any, Optional

try:
    from qgis.PyQt.QtCore import Qt, pyqtSignal
    from qgis.PyQt.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QRadioButton, QTableWidget,
        QTableWidgetItem, QMessageBox, QFileDialog, QApplication
    )
    from qgis.core import (
        QgsProject, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
        QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
        QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
        QgsTextFormat, QgsTextBufferSettings
    )
    from qgis.gui import QgsProjectionSelectionDialog, QgsMapToolEmitPoint
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt, pyqtSignal
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QRadioButton, QTableWidget,
        QTableWidgetItem, QMessageBox, QFileDialog, QApplication
    )
    HAS_QGIS = False

from ..core.compat import (
    HEADER_RESIZE_TO_CONTENTS,
    HEADER_STRETCH,
    ALIGN_CENTER,
    ALIGN_RIGHT_VCENTER,
    CURSOR_WAIT,
    CURSOR_CROSS,
    MSG_YES,
    make_qgs_field,
    exec_dialog,
    set_label_placement,
    get_project_crs_display,
    resolve_crs_authid,
    zoom_canvas_to_layer,
)
from ..core.bearing_parser import BearingParser
from ..core.traverse_engine import TraverseEngine, LotTraverseResult
from ..core.ocr_reader import OcrTableReader
from ..core.control_points import ControlPoint, ControlPointStore
from .ocr_review_dialog import OcrReviewDialog
from .control_point_dialog import ControlPointDialog


if HAS_QGIS:
    class _StartPointMapTool(QgsMapToolEmitPoint):
        """Interactive QGIS map canvas tool to pick a Start / Reference point."""

        def __init__(self, canvas, on_point, on_cancel=None):
            super().__init__(canvas)
            self._on_point = on_point
            self._on_cancel = on_cancel
            self.setCursor(CURSOR_CROSS)

        def canvasReleaseEvent(self, event):
            right_btn = Qt.MouseButton.RightButton if hasattr(Qt, "MouseButton") else Qt.RightButton
            if event.button() == right_btn:
                if self._on_cancel:
                    self._on_cancel()
                return
            pt = self.toMapCoordinates(event.pos())
            if self._on_point:
                self._on_point(pt)

        def keyPressEvent(self, event):
            esc_key = Qt.Key.Key_Escape if hasattr(Qt, "Key") else Qt.Key_Escape
            if event.key() == esc_key and self._on_cancel:
                self._on_cancel()


class LotPlotterWidget(QWidget):
    """International cadastral lot plotter with benchmark lookup, tie-line calculation, and QGIS plotting."""

    lot_computed = pyqtSignal(object)  # Emits LotTraverseResult

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.current_result: Optional[LotTraverseResult] = None
        self._map_tool = None
        self._prev_map_tool = None
        self._syncing_coords = False
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Upper row: Section 1 (Lot Information) and Section 2 (Coordinate System)
        top_row = QHBoxLayout()
        top_row.setSpacing(12)

        # === 1. LOT INFORMATION ===
        gb_lot = QGroupBox("1  LOT INFORMATION")
        gb_lot_layout = QGridLayout(gb_lot)
        gb_lot_layout.setContentsMargins(10, 14, 10, 10)
        gb_lot_layout.setVerticalSpacing(8)

        gb_lot_layout.addWidget(QLabel("Lot No."), 0, 0)
        self.txt_lot_no = QLineEdit()
        self.txt_lot_no.setPlaceholderText("e.g. LOT 1")
        gb_lot_layout.addWidget(self.txt_lot_no, 0, 1)

        gb_lot_layout.addWidget(QLabel("Description"), 1, 0)
        self.txt_desc = QLineEdit()
        self.txt_desc.setPlaceholderText("Optional description / location")
        gb_lot_layout.addWidget(self.txt_desc, 1, 1)

        gb_lot_layout.addWidget(QLabel("Declared area"), 2, 0)
        area_box = QHBoxLayout()
        self.txt_decl_area = QLineEdit()
        self.txt_decl_area.setPlaceholderText("optional")
        area_box.addWidget(self.txt_decl_area)
        area_box.addWidget(QLabel("sq.m."))
        gb_lot_layout.addLayout(area_box, 2, 1)

        gb_lot_layout.addWidget(QLabel("Target CRS"), 3, 0)
        crs_box = QHBoxLayout()
        self.txt_target_crs = QLineEdit(get_project_crs_display())
        self.txt_target_crs.setPlaceholderText("Project CRS (click '...' to select, e.g. EPSG:32630)")
        self.btn_select_crs = QPushButton("...")
        self.btn_select_crs.setFixedWidth(28)
        self.btn_select_crs.setToolTip("Select any international Coordinate Reference System (EPSG / UTM / National Grid)")
        self.btn_select_crs.clicked.connect(self._select_crs)
        crs_box.addWidget(self.txt_target_crs)
        crs_box.addWidget(self.btn_select_crs)
        gb_lot_layout.addLayout(crs_box, 3, 1)

        top_row.addWidget(gb_lot, stretch=1)

        # === 2. COORDINATE SYSTEM ===
        gb_coord = QGroupBox("2  COORDINATE SYSTEM")
        gb_coord_layout = QGridLayout(gb_coord)
        gb_coord_layout.setContentsMargins(10, 10, 10, 10)
        gb_coord_layout.setVerticalSpacing(6)

        # Radio mode buttons
        radio_box = QHBoxLayout()
        radio_box.addWidget(QLabel("Coordinates:"))
        self.rb_grid = QRadioButton("Grid")
        self.rb_grid.setChecked(True)
        self.rb_grid.setToolTip("Projected Grid coordinates (Easting, Northing) with optional Tie-Line")
        self.rb_plane = QRadioButton("Plane")
        self.rb_plane.setToolTip("Local / Assumed Plane coordinates entered directly as Start X, Y")
        self.rb_control = QRadioButton("Control")
        self.rb_control.setToolTip("Survey Control Monument / Benchmark with Tie Bearing & Tie Distance")
        self.rb_map = QRadioButton("Select on Map")
        self.rb_map.setToolTip("Pick Start / Reference coordinates interactively from the QGIS Map Canvas")

        radio_box.addWidget(self.rb_grid)
        radio_box.addWidget(self.rb_plane)
        radio_box.addWidget(self.rb_control)
        radio_box.addWidget(self.rb_map)
        radio_box.addStretch()
        gb_coord_layout.addLayout(radio_box, 0, 0, 1, 4)

        # Reference point row
        gb_coord_layout.addWidget(QLabel("Reference pt."), 1, 0)
        self.txt_ref_pt = QLineEdit()
        self.txt_ref_pt.setPlaceholderText("e.g. BM-01 / Control Monument")
        gb_coord_layout.addWidget(self.txt_ref_pt, 1, 1)

        ref_btn_row = QHBoxLayout()
        ref_btn_row.setSpacing(6)
        self.btn_browse_control = QPushButton("Search Control Point...")
        self.btn_browse_control.setToolTip(
            "Search your saved benchmarks, import a CSV benchmark catalog, or pick from active QGIS Point layers"
        )
        self.btn_browse_control.clicked.connect(self._search_control_point)

        self.btn_save_control = QPushButton("Save Pt")
        self.btn_save_control.setFixedWidth(70)
        self.btn_save_control.setToolTip("Save the current Reference pt. and Easting/Northing to your benchmark library")
        self.btn_save_control.clicked.connect(self._save_current_control_point)

        ref_btn_row.addWidget(self.btn_browse_control, stretch=1)
        ref_btn_row.addWidget(self.btn_save_control)
        gb_coord_layout.addLayout(ref_btn_row, 1, 2, 1, 2)

        # Easting & Tie Bearing
        gb_coord_layout.addWidget(QLabel("Easting (Grid X)"), 2, 0)
        self.txt_ref_e = QLineEdit()
        self.txt_ref_e.setPlaceholderText("Enter Easting (X)")
        self.txt_ref_e.textChanged.connect(self._update_start_coords)
        gb_coord_layout.addWidget(self.txt_ref_e, 2, 1)

        gb_coord_layout.addWidget(QLabel("Tie bearing"), 2, 2)
        self.txt_tie_bearing = QLineEdit()
        self.txt_tie_bearing.setPlaceholderText("optional, e.g. S 16°35' W")
        self.txt_tie_bearing.textChanged.connect(self._update_start_coords)
        gb_coord_layout.addWidget(self.txt_tie_bearing, 2, 3)

        # Northing & Tie Distance
        gb_coord_layout.addWidget(QLabel("Northing (Grid Y)"), 3, 0)
        self.txt_ref_n = QLineEdit()
        self.txt_ref_n.setPlaceholderText("Enter Northing (Y)")
        self.txt_ref_n.textChanged.connect(self._update_start_coords)
        gb_coord_layout.addWidget(self.txt_ref_n, 3, 1)

        gb_coord_layout.addWidget(QLabel("Tie distance (m)"), 3, 2)
        self.txt_tie_dist = QLineEdit()
        self.txt_tie_dist.setPlaceholderText("optional distance (m)")
        self.txt_tie_dist.textChanged.connect(self._update_start_coords)
        gb_coord_layout.addWidget(self.txt_tie_dist, 3, 3)

        # Start coordinates calculation, direct entry & map picker
        start_row = QHBoxLayout()
        self.btn_select_map = QPushButton("Select Start Point on Map")
        self.btn_select_map.setToolTip("Click to pick Start coordinates directly on the QGIS Map Canvas")
        self.btn_select_map.clicked.connect(self._activate_map_picker)
        start_row.addWidget(self.btn_select_map)

        start_row.addWidget(QLabel("Start X, Y:"))
        self.txt_start_x = QLineEdit()
        self.txt_start_x.setPlaceholderText("Start Easting (X)")
        self.txt_start_x.textChanged.connect(self._on_start_coords_edited)
        self.txt_start_y = QLineEdit()
        self.txt_start_y.setPlaceholderText("Start Northing (Y)")
        self.txt_start_y.textChanged.connect(self._on_start_coords_edited)

        self.btn_copy_start = QPushButton("Copy")
        self.btn_copy_start.clicked.connect(self._copy_start_coords)

        start_row.addWidget(self.txt_start_x)
        start_row.addWidget(self.txt_start_y)
        start_row.addWidget(self.btn_copy_start)
        gb_coord_layout.addLayout(start_row, 4, 0, 1, 4)

        top_row.addWidget(gb_coord, stretch=2)
        main_layout.addLayout(top_row)

        # Wire coordinate mode radio buttons
        self.rb_grid.toggled.connect(self._on_coord_mode_changed)
        self.rb_plane.toggled.connect(self._on_coord_mode_changed)
        self.rb_control.toggled.connect(self._on_coord_mode_changed)
        self.rb_map.toggled.connect(self._on_coord_mode_changed)

        # === 3. LOT TRAVERSE (FROM, TO, BEARING, DISTANCE) ===
        gb_trav = QGroupBox("3  LOT TRAVERSE (FROM, TO, BEARING, DISTANCE)")
        gb_trav_layout = QVBoxLayout(gb_trav)
        gb_trav_layout.setContentsMargins(10, 10, 10, 10)
        gb_trav_layout.setSpacing(8)

        # Toolbar controls
        tb_layout = QHBoxLayout()
        self.btn_upload_ocr = QPushButton("Upload Image (OCR)")
        self.btn_paste_ocr = QPushButton("Paste (Image / Text)")
        self.btn_import_csv = QPushButton("Import CSV...")
        self.btn_sample = QPushButton("Sample")

        self.btn_add_above = QPushButton("+ Above")
        self.btn_add_below = QPushButton("+ Below")
        self.btn_move_up = QPushButton("↑ Up")
        self.btn_move_down = QPushButton("↓ Down")
        self.btn_remove_row = QPushButton("Remove")
        self.btn_clear_table = QPushButton("Clear Table")

        tb_layout.addWidget(self.btn_upload_ocr)
        tb_layout.addWidget(self.btn_paste_ocr)
        tb_layout.addWidget(self.btn_import_csv)
        tb_layout.addWidget(self.btn_sample)
        tb_layout.addStretch()
        tb_layout.addWidget(self.btn_add_above)
        tb_layout.addWidget(self.btn_add_below)
        tb_layout.addWidget(self.btn_move_up)
        tb_layout.addWidget(self.btn_move_down)
        tb_layout.addWidget(self.btn_remove_row)
        tb_layout.addWidget(self.btn_clear_table)
        gb_trav_layout.addLayout(tb_layout)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["#", "From", "To", "Bearing", "Distance (m)"])
        self.table.horizontalHeader().setSectionResizeMode(0, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(1, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(2, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(3, HEADER_STRETCH)
        self.table.horizontalHeader().setSectionResizeMode(4, HEADER_RESIZE_TO_CONTENTS)
        self.table.setAlternatingRowColors(True)
        self.table.cellChanged.connect(self._on_table_data_changed)
        gb_trav_layout.addWidget(self.table)

        main_layout.addWidget(gb_trav, stretch=3)

        # === 4. FOOTER & ACTIONS ===
        footer_layout = QHBoxLayout()
        footer_layout.setContentsMargins(5, 5, 5, 5)

        # Left live metrics panel
        self.lbl_area = QLabel("Area: <b>0.00 m²</b>")
        self.lbl_perimeter = QLabel("Perimeter: <b>0.00 m</b>")
        self.lbl_vertices = QLabel("Vertices: <b>0</b>")
        self.lbl_closure = QLabel("Closure error: <b>—</b>")
        self.lbl_output = QLabel("Output: <b>Ready</b>")

        metrics_box = QHBoxLayout()
        metrics_box.setSpacing(15)
        metrics_box.addWidget(self.lbl_area)
        metrics_box.addWidget(self.lbl_perimeter)
        metrics_box.addWidget(self.lbl_vertices)
        metrics_box.addWidget(self.lbl_closure)
        metrics_box.addWidget(self.lbl_output)

        footer_layout.addLayout(metrics_box)
        footer_layout.addStretch()

        # Action buttons
        self.btn_export_csv = QPushButton("Export CSV...")
        self.btn_clear_all = QPushButton("Clear All")
        self.btn_compute_lot = QPushButton("Compute Plot Lot")
        self.btn_compute_lot.setStyleSheet(
            "background-color: #2e7d32; color: white; font-weight: bold; padding: 7px 18px; border-radius: 4px;"
        )
        self.btn_save = QPushButton("Save")
        self.btn_close = QPushButton("Close")

        footer_layout.addWidget(self.btn_export_csv)
        footer_layout.addWidget(self.btn_clear_all)
        footer_layout.addWidget(self.btn_compute_lot)
        footer_layout.addWidget(self.btn_save)
        footer_layout.addWidget(self.btn_close)

        main_layout.addLayout(footer_layout)

        # Hook button signals
        self.btn_upload_ocr.clicked.connect(self._upload_ocr_image)
        self.btn_paste_ocr.clicked.connect(self._paste_ocr_text)
        self.btn_import_csv.clicked.connect(self._import_csv)
        self.btn_sample.clicked.connect(self._load_sample_data)
        self.btn_add_above.clicked.connect(self._add_row_above)
        self.btn_add_below.clicked.connect(self._add_row_below)
        self.btn_move_up.clicked.connect(self._move_row_up)
        self.btn_move_down.clicked.connect(self._move_row_down)
        self.btn_remove_row.clicked.connect(self._remove_current_row)
        self.btn_clear_table.clicked.connect(self._clear_table)
        self.btn_clear_all.clicked.connect(self._clear_all)
        self.btn_export_csv.clicked.connect(self._export_csv)
        self.btn_compute_lot.clicked.connect(self._compute_and_plot_lot)
        self.btn_save.clicked.connect(self._save_session)
        self.btn_close.clicked.connect(self._close_parent_dialog)

        # Initialize UI state for default Grid mode
        self._on_coord_mode_changed()

    def _sync_project_crs(self):
        """Auto-fills Target CRS from the active QGIS Project CRS if not already specified."""
        if not self.txt_target_crs.text().strip():
            proj_display = get_project_crs_display()
            if proj_display:
                self.txt_target_crs.setText(proj_display)

    def _on_coord_mode_changed(self):
        """Updates field availability and behavior based on selected Coordinate Mode."""
        is_plane = self.rb_plane.isChecked()
        is_control = self.rb_control.isChecked()
        is_map = self.rb_map.isChecked()

        # Plane mode focuses directly on local Start X, Y without requiring a control monument
        ref_enabled = not is_plane
        self.txt_ref_pt.setEnabled(ref_enabled)
        self.btn_browse_control.setEnabled(ref_enabled)
        self.btn_save_control.setEnabled(ref_enabled)
        self.txt_ref_e.setEnabled(ref_enabled)
        self.txt_ref_n.setEnabled(ref_enabled)
        self.txt_tie_bearing.setEnabled(ref_enabled)
        self.txt_tie_dist.setEnabled(ref_enabled)

        # Start X, Y are always directly editable except when actively derived from a tie line in Control mode
        has_tie = bool(self.txt_tie_bearing.text().strip() and self.txt_tie_dist.text().strip())
        self.txt_start_x.setReadOnly(is_control and has_tie)
        self.txt_start_y.setReadOnly(is_control and has_tie)

        # Highlight Select Start Point on Map button when Select on Map mode is active
        if is_map:
            self.btn_select_map.setStyleSheet("font-weight: bold; color: #1565c0;")
        else:
            self.btn_select_map.setStyleSheet("")

        if is_plane:
            self._syncing_coords = True
            if not self.txt_start_x.text().strip():
                self.txt_start_x.setText("0.000")
            if not self.txt_start_y.text().strip():
                self.txt_start_y.setText("0.000")
            self._syncing_coords = False
            self._recalculate_traverse()
        else:
            self._update_start_coords()

    def _on_start_coords_edited(self):
        """Recalculates traverse when Start X, Y are edited directly by the user."""
        if self._syncing_coords:
            return
        self._recalculate_traverse()

    def _update_start_coords(self):
        """
        Computes Start (X, Y) from Reference (E, N) and Tie Bearing/Distance.
        If Tie Bearing and Tie Distance are left blank, uses Reference (E, N) directly as Start (X, Y).
        """
        if self._syncing_coords or self.rb_plane.isChecked():
            return

        ref_e_str = self.txt_ref_e.text().replace(",", "").strip()
        ref_n_str = self.txt_ref_n.text().replace(",", "").strip()
        tie_b = self.txt_tie_bearing.text().strip()
        tie_d_str = self.txt_tie_dist.text().replace(",", "").strip()

        is_control = self.rb_control.isChecked()
        has_tie = bool(tie_b and tie_d_str)
        self.txt_start_x.setReadOnly(is_control and has_tie)
        self.txt_start_y.setReadOnly(is_control and has_tie)

        if not ref_e_str or not ref_n_str:
            return

        try:
            ref_e = float(ref_e_str)
            ref_n = float(ref_n_str)
        except ValueError:
            return

        self._syncing_coords = True
        try:
            if has_tie:
                try:
                    tie_d = float(tie_d_str)
                except ValueError:
                    return
                az = BearingParser.parse_to_azimuth(tie_b)
                if az is not None:
                    de, dn = BearingParser.delta_en(az, tie_d)
                    start_x = ref_e + de
                    start_y = ref_n + dn
                    self.txt_start_x.setText(f"{start_x:.6f}")
                    self.txt_start_y.setText(f"{start_y:.6f}")
            else:
                # Direct coordinates: Reference Easting/Northing acts as Corner 1 Start X, Y
                self.txt_start_x.setText(f"{ref_e:.6f}")
                self.txt_start_y.setText(f"{ref_n:.6f}")
        finally:
            self._syncing_coords = False

        self._recalculate_traverse()

    def _activate_map_picker(self):
        """Activates an interactive QGIS Map Tool so the user can pick Start X, Y on the canvas."""
        if not HAS_QGIS or not self.iface:
            QMessageBox.information(
                self,
                "Select on Map",
                "Interactive map coordinate picking requires an active QGIS map canvas."
            )
            return

        self.rb_map.setChecked(True)
        canvas = self.iface.mapCanvas()
        self.cleanup_map_tool()
        self._prev_map_tool = canvas.mapTool()
        self._map_tool = _StartPointMapTool(canvas, self._on_map_point_picked, self._cancel_map_pick)
        canvas.setMapTool(self._map_tool)

        try:
            self.iface.messageBar().pushInfo(
                "GeoCad",
                "Click anywhere on the map canvas to pick Start / Reference coordinates (Right-click or Esc to cancel)."
            )
        except AttributeError as err:
            _ = err

        parent_win = self.window()
        if parent_win and parent_win is not self:
            parent_win.showMinimized()

    def _on_map_point_picked(self, map_pt):
        """Receives the clicked point from QGIS canvas, transforms to Target CRS, and populates coordinates."""
        canvas = self.iface.mapCanvas() if (HAS_QGIS and self.iface) else None
        out_pt = map_pt

        if canvas is not None:
            canvas_crs = canvas.mapSettings().destinationCrs()
            target_auth = resolve_crs_authid(self.txt_target_crs.text(), fallback="")
            if not target_auth and canvas_crs and canvas_crs.isValid():
                self.txt_target_crs.setText(f"{canvas_crs.authid()} — {canvas_crs.description()}")
                target_auth = canvas_crs.authid()

            if target_auth and canvas_crs and canvas_crs.isValid():
                target_crs = QgsCoordinateReferenceSystem(target_auth)
                if target_crs.isValid() and target_crs != canvas_crs:
                    try:
                        xform = QgsCoordinateTransform(canvas_crs, target_crs, QgsProject.instance())
                        out_pt = xform.transform(map_pt)
                    except RuntimeError as err:
                        _ = err

        self.cleanup_map_tool()

        self._syncing_coords = True
        try:
            x_str = f"{out_pt.x():.4f}"
            y_str = f"{out_pt.y():.4f}"
            self.txt_start_x.setText(x_str)
            self.txt_start_y.setText(y_str)
            if not self.txt_tie_bearing.text().strip() and not self.txt_tie_dist.text().strip():
                self.txt_ref_e.setText(x_str)
                self.txt_ref_n.setText(y_str)
                if not self.txt_ref_pt.text().strip():
                    self.txt_ref_pt.setText("Map Point")
        finally:
            self._syncing_coords = False

        self._restore_parent_window()
        self._recalculate_traverse()

    def _cancel_map_pick(self):
        """Cancels interactive map point selection and restores previous QGIS tool."""
        self.cleanup_map_tool()
        self._restore_parent_window()

    def cleanup_map_tool(self):
        """Restores the previous QGIS map tool if our picker is currently active."""
        if HAS_QGIS and self.iface and self._map_tool is not None:
            canvas = self.iface.mapCanvas()
            if canvas.mapTool() == self._map_tool:
                if self._prev_map_tool is not None:
                    canvas.setMapTool(self._prev_map_tool)
                else:
                    canvas.unsetMapTool(self._map_tool)
            self._map_tool = None
            self._prev_map_tool = None

    def _restore_parent_window(self):
        parent_win = self.window()
        if parent_win and parent_win is not self:
            parent_win.showNormal()
            parent_win.raise_()
            parent_win.activateWindow()

    def _copy_start_coords(self):
        sx = self.txt_start_x.text().strip()
        sy = self.txt_start_y.text().strip()
        if not sx or not sy:
            QMessageBox.information(self, "No Coordinates", "Start coordinates have not been entered or calculated yet.")
            return
        text = f"{sx}, {sy}"
        QApplication.clipboard().setText(text)
        QMessageBox.information(self, "Copied", f"Start coordinates copied to clipboard:\n{text}")

    def _select_crs(self):
        if HAS_QGIS:
            selector = QgsProjectionSelectionDialog(self)
            curr = resolve_crs_authid(self.txt_target_crs.text(), fallback="")
            if curr:
                crs_obj = QgsCoordinateReferenceSystem(curr)
                if crs_obj.isValid():
                    selector.setCrs(crs_obj)
            if exec_dialog(selector):
                crs = selector.crs()
                self.txt_target_crs.setText(f"{crs.authid()} — {crs.description()}")
                self._recalculate_traverse()

    def _search_control_point(self):
        """Opens the international Survey Control Point & Benchmark Manager / Lookup dialog."""
        target_auth = resolve_crs_authid(self.txt_target_crs.text(), fallback="")
        dlg = ControlPointDialog(
            target_crs_authid=target_auth,
            initial_query=self.txt_ref_pt.text().strip(),
            parent=self
        )
        if exec_dialog(dlg) and dlg.selected_point is not None:
            pt = dlg.selected_point
            self.txt_ref_pt.setText(pt.station_id)
            self.txt_ref_e.setText(f"{pt.easting:.4f}")
            self.txt_ref_n.setText(f"{pt.northing:.4f}")
            if dlg.apply_crs and pt.crs_authid:
                if HAS_QGIS:
                    crs_obj = QgsCoordinateReferenceSystem(pt.crs_authid)
                    if crs_obj.isValid():
                        self.txt_target_crs.setText(f"{crs_obj.authid()} — {crs_obj.description()}")
                    else:
                        self.txt_target_crs.setText(pt.crs_authid)
                else:
                    self.txt_target_crs.setText(pt.crs_authid)
            self._update_start_coords()

    def _save_current_control_point(self):
        """Saves the currently entered Reference pt. and Easting/Northing to the user's benchmark library."""
        stn_id = self.txt_ref_pt.text().strip()
        e_str = self.txt_ref_e.text().replace(",", "").strip()
        n_str = self.txt_ref_n.text().replace(",", "").strip()

        if not stn_id:
            QMessageBox.warning(
                self,
                "Reference Station Required",
                "Please enter a Reference pt. / Benchmark ID (e.g. BM-01) before saving."
            )
            return
        try:
            easting = float(e_str)
            northing = float(n_str)
        except ValueError:
            QMessageBox.warning(
                self,
                "Valid Coordinates Required",
                "Please enter valid numeric Easting (Grid X) and Northing (Grid Y) values before saving."
            )
            return

        crs_auth = resolve_crs_authid(self.txt_target_crs.text(), fallback="")
        pt = ControlPoint(
            station_id=stn_id,
            easting=easting,
            northing=northing,
            elevation=0.0,
            crs_authid=crs_auth,
            description=self.txt_desc.text().strip(),
            source="Saved",
        )
        ControlPointStore.add_or_update(pt)
        QMessageBox.information(
            self,
            "Control Point Saved",
            f"Saved benchmark '{stn_id}' ({easting:.4f}, {northing:.4f}) to your GeoCad Control Point Library.\n\n"
            "You can search and reuse it anytime via 'Search Control Point...'."
        )

    def _load_sample_data(self):
        """Loads an internationally neutral 6-station cadastral sample traverse."""
        self.rb_control.setChecked(True)
        self.txt_lot_no.setText("LOT 1")
        self.txt_ref_pt.setText("CP-01")
        self.txt_ref_e.setText("500000.000")
        self.txt_ref_n.setText("1000000.000")
        self.txt_tie_bearing.setText("N 45°00' E")
        self.txt_tie_dist.setText("150.00")

        sample_rows = [
            ("1", "2", "N 28°38' E", 246.48),
            ("2", "3", "S 88°56' E", 29.99),
            ("3", "4", "S 68°50' E", 42.54),
            ("4", "5", "S 52°21' E", 52.49),
            ("5", "6", "S 30°20' W", 250.38),
            ("6", "1", "N 65°06' W", 113.42),
        ]
        self.table.blockSignals(True)
        self.table.setRowCount(len(sample_rows))

        for idx, (f_pt, t_pt, b_str, dist) in enumerate(sample_rows):
            item_num = QTableWidgetItem(str(idx + 1))
            item_f = QTableWidgetItem(f_pt)
            item_t = QTableWidgetItem(t_pt)
            item_b = QTableWidgetItem(b_str)
            item_d = QTableWidgetItem(f"{dist:.2f}")

            item_num.setTextAlignment(ALIGN_CENTER)
            item_f.setTextAlignment(ALIGN_CENTER)
            item_t.setTextAlignment(ALIGN_CENTER)
            item_d.setTextAlignment(ALIGN_RIGHT_VCENTER)

            self.table.setItem(idx, 0, item_num)
            self.table.setItem(idx, 1, item_f)
            self.table.setItem(idx, 2, item_t)
            self.table.setItem(idx, 3, item_b)
            self.table.setItem(idx, 4, item_d)

        self.table.blockSignals(False)
        self._update_start_coords()
        self._recalculate_traverse()

    def _on_table_data_changed(self, row, col):
        self._recalculate_traverse()

    def _get_legs_from_table(self) -> List[Dict[str, Any]]:
        legs = []
        for r in range(self.table.rowCount()):
            f_item = self.table.item(r, 1)
            t_item = self.table.item(r, 2)
            b_item = self.table.item(r, 3)
            d_item = self.table.item(r, 4)

            if not b_item or not d_item:
                continue

            f_str = f_item.text().strip() if f_item else str(r + 1)
            t_str = t_item.text().strip() if t_item else str(r + 2)
            b_str = b_item.text().strip()
            d_str = d_item.text().replace(",", "").strip()

            try:
                dist = float(d_str)
            except ValueError:
                dist = 0.0

            legs.append({
                "from": f_str,
                "to": t_str,
                "bearing": b_str,
                "distance": dist
            })
        return legs

    def _recalculate_traverse(self):
        """Performs live traverse computation and updates summary metrics."""
        legs = self._get_legs_from_table()
        if not legs:
            self.lbl_area.setText("Area: <b>0.00 m²</b>")
            self.lbl_perimeter.setText("Perimeter: <b>0.00 m</b>")
            self.lbl_vertices.setText("Vertices: <b>0</b>")
            self.lbl_closure.setText("Closure error: <b>—</b>")
            self.current_result = None
            return

        try:
            start_x = float(self.txt_start_x.text().replace(",", "").strip())
            start_y = float(self.txt_start_y.text().replace(",", "").strip())
        except (ValueError, AttributeError):
            start_x, start_y = (0.0, 0.0)

        decl_area = None
        if self.txt_decl_area.text().strip():
            try:
                decl_area = float(self.txt_decl_area.text().replace(",", ""))
            except ValueError:
                decl_area = None

        # Only supply reference_coord and tie parameters when not in Plane mode and a tie-line exists
        ref_coord = None
        tie_b = ""
        tie_d = 0.0
        if not self.rb_plane.isChecked():
            ref_e_txt = self.txt_ref_e.text().replace(",", "").strip()
            ref_n_txt = self.txt_ref_n.text().replace(",", "").strip()
            tie_b = self.txt_tie_bearing.text().strip()
            tie_d_txt = self.txt_tie_dist.text().replace(",", "").strip()
            try:
                tie_d = float(tie_d_txt) if tie_d_txt else 0.0
            except ValueError:
                tie_d = 0.0
            if ref_e_txt and ref_n_txt and tie_b and tie_d > 0:
                try:
                    ref_coord = (float(ref_e_txt), float(ref_n_txt))
                except ValueError:
                    ref_coord = None

        res = TraverseEngine.compute_lot(
            lot_no=self.txt_lot_no.text().strip() or "LOT 1",
            legs_data=legs,
            start_coord=(start_x, start_y),
            reference_coord=ref_coord,
            tie_bearing=tie_b,
            tie_distance=tie_d,
            declared_area=decl_area,
            description=self.txt_desc.text().strip(),
            target_crs=resolve_crs_authid(self.txt_target_crs.text(), fallback="")
        )
        self.current_result = res

        # Update metrics footer labels
        self.lbl_area.setText(f"Area: <b>{res.area_sqm:,.2f} m²</b>")
        self.lbl_perimeter.setText(f"Perimeter: <b>{res.perimeter:.2f} m</b>")
        self.lbl_vertices.setText(f"Vertices: <b>{len(res.legs)}</b>")

        if res.is_closed and res.closure_error_dist > 0.001:
            ratio_str = f"1:{res.closure_precision_ratio}" if res.closure_precision_ratio else "—"
            self.lbl_closure.setText(f"Closure error: <b>{res.closure_error_dist:.3f} m ({ratio_str})</b>")
        else:
            self.lbl_closure.setText("Closure error: <b>—</b>")

    def _paste_ocr_text(self):
        """Pastes clipboard contents (either image screenshot or raw text) and opens review dialog."""
        clipboard = QApplication.clipboard()
        raw_text = ""
        parsed_rows = []
        start_coords = None

        # 1. Check if clipboard has an image
        mime = clipboard.mimeData()
        if mime and mime.hasImage():
            img = clipboard.image()
            if not img.isNull():
                import tempfile
                with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                    tmp_path = tmp.name
                try:
                    img.save(tmp_path, "PNG")
                    QApplication.setOverrideCursor(CURSOR_WAIT)
                    try:
                        raw_text = OcrTableReader.ocr_image_file(tmp_path)
                    finally:
                        QApplication.restoreOverrideCursor()
                finally:
                    if os.path.exists(tmp_path):
                        try:
                            os.remove(tmp_path)
                        except OSError as err:
                            _ = err

        # 2. If no image or image produced no text, check if clipboard has text
        if not raw_text:
            raw_text = clipboard.text().strip()

        if not raw_text:
            QMessageBox.information(
                self,
                "Clipboard Empty",
                "Clipboard is empty or does not contain text or image data.\n\n"
                "Please copy a technical description (text or screenshot) first, then click Paste."
            )
            return

        # Parse the text into candidate rows
        parsed_rows, start_coords = OcrTableReader.parse_content(raw_text)

        dlg = OcrReviewDialog(raw_text=raw_text, parsed_rows=parsed_rows, parent=self)
        if exec_dialog(dlg) and dlg.confirmed_rows:
            self._set_rows_from_data(dlg.confirmed_rows)
            if start_coords and not self.txt_start_x.text():
                self.txt_start_x.setText(f"{start_coords[0]:.6f}")
                self.txt_start_y.setText(f"{start_coords[1]:.6f}")
            QMessageBox.information(
                self, "Import Complete", f"Successfully imported {len(dlg.confirmed_rows)} traverse records."
            )

    def _upload_ocr_image(self):
        """Uploads an image (JPG, PNG, TIFF, BMP) and performs OCR extraction."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Scanned Cadastral Map / Title",
            "",
            "Image Files (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp)"
        )
        if not path:
            return

        # Perform OCR extraction
        QApplication.setOverrideCursor(CURSOR_WAIT)
        try:
            extracted_text = OcrTableReader.ocr_image_file(path)
            rows, start_coords = OcrTableReader.parse_content(extracted_text) if extracted_text else ([], None)
        finally:
            QApplication.restoreOverrideCursor()

        dlg = OcrReviewDialog(raw_text=extracted_text, parsed_rows=rows, parent=self)
        if exec_dialog(dlg) and dlg.confirmed_rows:
            self._set_rows_from_data(dlg.confirmed_rows)
            if start_coords and not self.txt_start_x.text():
                self.txt_start_x.setText(f"{start_coords[0]:.6f}")
                self.txt_start_y.setText(f"{start_coords[1]:.6f}")
            QMessageBox.information(
                self, "OCR Complete", f"Successfully imported {len(dlg.confirmed_rows)} traverse records from image."
            )

    def _import_csv(self):
        """Imports traverse lines or coordinate points from CSV, TXT, or DAT files."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Import Traverse / Coordinate File",
            "",
            "Survey Files (*.csv *.txt *.dat);;All Files (*.*)"
        )
        if not path:
            return

        try:
            rows, start_coords = OcrTableReader.parse_imported_file(path)
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

            if not rows:
                QMessageBox.warning(
                    self,
                    "Import Notice",
                    "No valid traverse legs or coordinates could be automatically recognized in the file.\n\n"
                    "Opening review dialog so you can inspect the content."
                )
                dlg = OcrReviewDialog(raw_text=content, parsed_rows=[], parent=self)
            else:
                dlg = OcrReviewDialog(raw_text=content, parsed_rows=rows, parent=self)

            if exec_dialog(dlg) and dlg.confirmed_rows:
                self._set_rows_from_data(dlg.confirmed_rows)
                if start_coords and not self.txt_start_x.text():
                    self.txt_start_x.setText(f"{start_coords[0]:.6f}")
                    self.txt_start_y.setText(f"{start_coords[1]:.6f}")
                QMessageBox.information(
                    self, "Import Successful", f"Successfully imported {len(dlg.confirmed_rows)} traverse records."
                )
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not read survey file:\n{str(e)}")

    def _set_rows_from_data(self, rows: List[Dict[str, Any]]):
        self.table.blockSignals(True)
        self.table.setRowCount(len(rows))
        for idx, r in enumerate(rows):
            item_num = QTableWidgetItem(str(idx + 1))
            item_f = QTableWidgetItem(str(r.get("from", idx + 1)))
            item_t = QTableWidgetItem(str(r.get("to", idx + 2)))
            item_b = QTableWidgetItem(str(r.get("bearing", "")))
            dist_val = r.get("distance", 0.0)
            item_d = QTableWidgetItem(f"{float(dist_val):.2f}")

            item_num.setTextAlignment(ALIGN_CENTER)
            item_f.setTextAlignment(ALIGN_CENTER)
            item_t.setTextAlignment(ALIGN_CENTER)
            item_d.setTextAlignment(ALIGN_RIGHT_VCENTER)

            self.table.setItem(idx, 0, item_num)
            self.table.setItem(idx, 1, item_f)
            self.table.setItem(idx, 2, item_t)
            self.table.setItem(idx, 3, item_b)
            self.table.setItem(idx, 4, item_d)

        self.table.blockSignals(False)
        self._recalculate_traverse()

    def _add_row_above(self):
        curr = max(0, self.table.currentRow())
        self._insert_row_at(curr)

    def _add_row_below(self):
        curr = self.table.currentRow()
        pos = curr + 1 if curr >= 0 else self.table.rowCount()
        self._insert_row_at(pos)

    def _insert_row_at(self, pos: int):
        self.table.blockSignals(True)
        self.table.insertRow(pos)
        item_num = QTableWidgetItem(str(pos + 1))
        item_f = QTableWidgetItem(str(pos + 1))
        item_t = QTableWidgetItem(str(pos + 2))
        item_b = QTableWidgetItem("")
        item_d = QTableWidgetItem("0.00")

        item_num.setTextAlignment(ALIGN_CENTER)
        item_f.setTextAlignment(ALIGN_CENTER)
        item_t.setTextAlignment(ALIGN_CENTER)
        item_d.setTextAlignment(ALIGN_RIGHT_VCENTER)

        self.table.setItem(pos, 0, item_num)
        self.table.setItem(pos, 1, item_f)
        self.table.setItem(pos, 2, item_t)
        self.table.setItem(pos, 3, item_b)
        self.table.setItem(pos, 4, item_d)

        # Renumber rows safely
        for r in range(self.table.rowCount()):
            it = self.table.item(r, 0)
            if it is None:
                it = QTableWidgetItem(str(r + 1))
                it.setTextAlignment(ALIGN_CENTER)
                self.table.setItem(r, 0, it)
            else:
                it.setText(str(r + 1))

        self.table.blockSignals(False)

    def _move_row_up(self):
        curr = self.table.currentRow()
        if curr > 0:
            self._swap_rows(curr, curr - 1)
            self.table.setCurrentCell(curr - 1, 3)

    def _move_row_down(self):
        curr = self.table.currentRow()
        if 0 <= curr < self.table.rowCount() - 1:
            self._swap_rows(curr, curr + 1)
            self.table.setCurrentCell(curr + 1, 3)

    def _swap_rows(self, r1: int, r2: int):
        self.table.blockSignals(True)
        for c in range(1, 5):
            it1 = self.table.item(r1, c)
            it2 = self.table.item(r2, c)
            t1 = it1.text() if it1 else ""
            t2 = it2.text() if it2 else ""
            if it1 is None:
                it1 = QTableWidgetItem(t2)
                self.table.setItem(r1, c, it1)
            else:
                it1.setText(t2)
            if it2 is None:
                it2 = QTableWidgetItem(t1)
                self.table.setItem(r2, c, it2)
            else:
                it2.setText(t1)
        self.table.blockSignals(False)
        self._recalculate_traverse()

    def _remove_current_row(self):
        curr = self.table.currentRow()
        if curr >= 0:
            self.table.removeRow(curr)
            for r in range(self.table.rowCount()):
                it = self.table.item(r, 0)
                if it is not None:
                    it.setText(str(r + 1))
            self._recalculate_traverse()

    def _clear_table(self):
        self.table.setRowCount(0)
        self.current_result = None
        self.lbl_area.setText("Area: <b>0.00 m²</b>")
        self.lbl_perimeter.setText("Perimeter: <b>0.00 m</b>")
        self.lbl_vertices.setText("Vertices: <b>0</b>")
        self.lbl_closure.setText("Closure error: <b>—</b>")
        self.lbl_output.setText("Output: <b>Ready</b>")

    def _clear_all(self):
        if QMessageBox.question(self, "Clear All", "Reset all lot parameters and clear the table?") == MSG_YES:
            self._syncing_coords = True
            self.txt_lot_no.clear()
            self.txt_desc.clear()
            self.txt_decl_area.clear()
            self.txt_ref_pt.clear()
            self.txt_ref_e.clear()
            self.txt_ref_n.clear()
            self.txt_tie_bearing.clear()
            self.txt_tie_dist.clear()
            self.txt_start_x.clear()
            self.txt_start_y.clear()
            self._syncing_coords = False
            self._clear_table()

    def _export_csv(self):
        if not self.current_result or not self.current_result.legs:
            QMessageBox.warning(self, "Export", "No traverse records to export.")
            return

        path, _ = QFileDialog.getSaveFileName(self, "Export Traverse to CSV", f"{self.txt_lot_no.text()}.csv", "CSV Files (*.csv)")
        if not path:
            return

        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write("Index,From,To,Bearing,Distance_m,Azimuth_deg,Start_E,Start_N,End_E,End_N\n")
                for idx, leg in enumerate(self.current_result.legs):
                    f.write(
                        f"{idx+1},{leg.from_pt},{leg.to_pt},{leg.bearing_str},{leg.distance:.3f},"
                        f"{leg.azimuth:.4f},{leg.start_coord[0]:.4f},{leg.start_coord[1]:.4f},"
                        f"{leg.end_coord[0]:.4f},{leg.end_coord[1]:.4f}\n"
                    )
            QMessageBox.information(self, "Export Successful", f"Traverse records exported to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Failed to save CSV: {str(e)}")

    def _compute_and_plot_lot(self):
        """Executes traverse calculation and adds boundary, tie-line, and station layers to QGIS."""
        self._recalculate_traverse()
        if not self.current_result or not self.current_result.legs:
            QMessageBox.warning(self, "Computation", "Please enter traverse bearing and distance legs.")
            return

        res = self.current_result

        if not HAS_QGIS or not self.iface:
            QMessageBox.information(self, "GeoCad Traverse Output", res.summary_text())
            self.lot_computed.emit(res)
            return

        # Determine Target CRS (selected CRS -> active Project CRS -> warn if unset)
        crs_str = resolve_crs_authid(self.txt_target_crs.text(), fallback="")
        if not crs_str:
            QMessageBox.warning(
                self,
                "Target CRS Required",
                "Please select a Target CRS (e.g. your local UTM or National Grid EPSG code) "
                "using the '...' button before plotting to QGIS."
            )
            return

        lot_name = res.lot_no

        # 1. Polygon Layer
        poly_layer = QgsVectorLayer(f"Polygon?crs={crs_str}", f"{lot_name} - Boundary", "memory")
        pr = poly_layer.dataProvider()
        pr.addAttributes([
            make_qgs_field("Lot_No", "string"),
            make_qgs_field("Area_sqm", "double", 12, 2),
            make_qgs_field("Area_ha", "double", 12, 4),
            make_qgs_field("Perimeter", "double", 12, 2),
            make_qgs_field("Closure", "double", 12, 4),
        ])
        poly_layer.updateFields()

        if res.wkt_polygon:
            geom = QgsGeometry.fromWkt(res.wkt_polygon)
            feat = QgsFeature()
            feat.setGeometry(geom)
            feat.setAttributes([
                res.lot_no,
                res.area_sqm,
                res.area_ha,
                res.perimeter,
                res.closure_error_dist
            ])
            pr.addFeature(feat)
            poly_layer.updateExtents()

        # 2. Line Traverse Layer (Individual Boundary Legs with Bearings & Distances)
        line_layer = QgsVectorLayer(f"LineString?crs={crs_str}", f"{lot_name} - Linework", "memory")
        lpr = line_layer.dataProvider()
        lpr.addAttributes([
            make_qgs_field("From_Stn", "string"),
            make_qgs_field("To_Stn", "string"),
            make_qgs_field("Bearing", "string"),
            make_qgs_field("Distance_m", "double", 10, 2),
            make_qgs_field("Label_Text", "string"),
        ])
        line_layer.updateFields()

        line_features = []
        for leg in res.legs:
            p1 = QgsPointXY(leg.start_coord[0], leg.start_coord[1])
            p2 = QgsPointXY(leg.end_coord[0], leg.end_coord[1])
            l_geom = QgsGeometry.fromPolylineXY([p1, p2])
            lf = QgsFeature()
            lf.setGeometry(l_geom)
            label_display = f"{leg.bearing_str}\n{leg.distance:.2f} m"
            lf.setAttributes([
                leg.from_pt,
                leg.to_pt,
                leg.bearing_str,
                leg.distance,
                label_display
            ])
            line_features.append(lf)

        lpr.addFeatures(line_features)
        line_layer.updateExtents()

        # Add Labeling to the Linework layer
        settings = QgsPalLayerSettings()
        settings.fieldName = "Label_Text"
        set_label_placement(settings, "Line")
        settings.isExpression = False
        text_format = QgsTextFormat()
        text_format.setSize(9)
        buffer = QgsTextBufferSettings()
        buffer.setEnabled(True)
        buffer.setSize(1)
        text_format.setBuffer(buffer)
        settings.setFormat(text_format)
        line_layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        line_layer.setLabelsEnabled(True)

        # 3. Tie Line Layer (if tie point & tie line present)
        tie_layer = None
        if res.wkt_tie_line:
            tie_layer = QgsVectorLayer(f"LineString?crs={crs_str}", f"{lot_name} - Tie Line", "memory")
            tpr = tie_layer.dataProvider()
            tpr.addAttributes([
                make_qgs_field("Ref_Point", "string"),
                make_qgs_field("Bearing", "string"),
                make_qgs_field("Distance_m", "double", 10, 2),
            ])
            tie_layer.updateFields()
            t_geom = QgsGeometry.fromWkt(res.wkt_tie_line)
            tf = QgsFeature()
            tf.setGeometry(t_geom)
            tf.setAttributes([self.txt_ref_pt.text(), res.tie_bearing_str, res.tie_distance])
            tpr.addFeature(tf)
            tie_layer.updateExtents()

        # Add layers to QGIS Project
        proj = QgsProject.instance()
        if tie_layer:
            proj.addMapLayer(tie_layer)
        proj.addMapLayer(poly_layer)
        proj.addMapLayer(line_layer)

        # Zoom canvas safely (handling CRS transformation between layer and canvas)
        zoom_canvas_to_layer(self.iface, poly_layer if res.wkt_polygon else line_layer)

        self.lbl_output.setText("Output: <b>Plotted to QGIS</b>")
        QMessageBox.information(
            self,
            "Lot Computed",
            f"Successfully plotted {lot_name}!\n\n"
            f"Target CRS: {crs_str}\n"
            f"Area: {res.area_sqm:,.2f} sq.m ({res.area_ha:.4f} ha)\n"
            f"Perimeter: {res.perimeter:.2f} m\n"
            f"Closure: {res.closure_error_dist:.4f} m (Precision: 1:{res.closure_precision_ratio or 'Exact'})\n\n"
            f"Layers added to QGIS canvas."
        )
        self.lot_computed.emit(res)

    def _save_session(self):
        if not self.current_result:
            QMessageBox.warning(self, "Save", "No computed lot data to save.")
            return
        self._export_csv()

    def _close_parent_dialog(self):
        self.cleanup_map_tool()
        parent_win = self.window()
        if parent_win and parent_win is not self:
            parent_win.close()
