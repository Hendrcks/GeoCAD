"""
GeoCad - Master CAD Workbench Dialog.
Integrates all survey engineering modules into a unified tabbed QGIS workstation:
1. Lot Traverse Plotter (Bearing & Distance)
2. Field Coordinate Point Ingestion (NEZL, NEL, KDMS) & Sequential Boundary Lines
3. Boundary Bearing and Distance Annotation (Meters & Feet)
4. Cartographic Survey Grid Generator
5. Delaunay TIN Surface Modeler & Diagnostics
6. Topographic Contour Generator & Hypsometric Tinting
7. About & Help
"""

import os

try:
    from qgis.PyQt.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
    from qgis.PyQt.QtGui import QIcon, QPixmap
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
        QPushButton, QStatusBar, QFrame, QGraphicsOpacityEffect, QSizePolicy
    )
except ImportError:
    from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
    from PyQt5.QtGui import QIcon, QPixmap
    from PyQt5.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
        QPushButton, QStatusBar, QFrame, QGraphicsOpacityEffect, QSizePolicy
    )

from .core.compat import exec_dialog
from .ui.lot_plotter_widget import LotPlotterWidget
from .ui.point_plotter_widget import PointPlotterWidget
from .ui.bearing_distance_widget import BearingDistanceWidget
from .ui.grid_widget import SurveyGridWidget
from .ui.tin_widget import TinWidget
from .ui.contour_widget import ContourWidget
from .ui.about_dialog import AboutDialog


class _AriesPlusAdBanner(QFrame):
    """Smooth animated promotional & developer contact banner for AriesPlus Geospatial Solutions."""

    SLIDES = [
        (
            "<b style='color:#0b2c52;'>AriesPlus Geospatial Solutions</b>"
            " <span style='color:#c6922c;'>•</span> "
            "<span style='color:#0c7c69;'>Mapping change. Supporting better decisions.</span>"
        ),
        (
            "<b style='color:#0b2c52;'>GIS • Remote Sensing • Spatial Analytics</b>"
            " <span style='color:#c6922c;'>•</span> "
            "<span style='color:#0c7c69;'>AriesPlus Geospatial Solutions</span>"
        ),
        (
            "<b style='color:#0b2c52;'>Cadastral Surveying & Custom GIS Solutions</b>"
            " <span style='color:#c6922c;'>•</span> "
            "<span style='color:#0c7c69;'>AriesPlus Geospatial Solutions</span>"
        ),
    ]

    def __init__(self, plugin_dir: str, parent=None):
        super().__init__(parent)
        self.setObjectName("ariesplusBanner")
        self.setFixedHeight(48)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding if hasattr(QSizePolicy, "Policy") else QSizePolicy.Expanding,
            QSizePolicy.Policy.Fixed if hasattr(QSizePolicy, "Policy") else QSizePolicy.Fixed,
        )
        self.setToolTip(
            "AriesPlus Geospatial Solutions\n"
            "Mapping change. Supporting better decisions.\n"
            "GIS • Remote Sensing • Spatial Analytics\n"
            "Call / WhatsApp: +233 (0) 593400774 / 0503809181\n"
            "Email: ariesplusgeo@gmail.com"
        )
        self.setStyleSheet(
            "QFrame#ariesplusBanner {"
            "  background: qlineargradient("
            "    x1:0, y1:0, x2:1, y2:0,"
            "    stop:0 #f8f5ef, stop:0.55 #eff6f4, stop:1 #e9f2f7"
            "  );"
            "  border: 1px solid #cbdbe1;"
            "  border-left: 4px solid #0c7c69;"
            "  border-radius: 7px;"
            "}"
        )

        self._slide_idx = 0
        self._fade_anim = None

        row = QHBoxLayout(self)
        row.setContentsMargins(10, 4, 12, 4)
        row.setSpacing(10)

        # AriesPlus transparent brand logo
        logo_path = os.path.join(plugin_dir, "ariesplus_logo.png")
        if not os.path.exists(logo_path):
            logo_path = os.path.join(plugin_dir, "icons", "ariesplus_logo.png")
        if os.path.exists(logo_path):
            logo_lbl = QLabel()
            logo_lbl.setStyleSheet("background: transparent; border: none;")
            pix = QPixmap(logo_path)
            smooth = (
                Qt.TransformationMode.SmoothTransformation
                if hasattr(Qt, "TransformationMode")
                else Qt.SmoothTransformation
            )
            logo_lbl.setPixmap(pix.scaledToHeight(32, smooth))
            row.addWidget(logo_lbl)

            # Subtle gold hairline divider matching brand palette
            divider = QFrame()
            divider.setFixedWidth(1)
            divider.setFixedHeight(30)
            divider.setStyleSheet("background-color: #c6922c; border: none;")
            row.addWidget(divider)

        # Two-line smooth text stack
        text_col = QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(1)

        self.lbl_headline = QLabel(self.SLIDES[0])
        self.lbl_headline.setStyleSheet("font-size: 11px; background: transparent; border: none;")

        self._opacity_fx = QGraphicsOpacityEffect(self.lbl_headline)
        self._opacity_fx.setOpacity(1.0)
        self.lbl_headline.setGraphicsEffect(self._opacity_fx)

        self.lbl_contact = QLabel(
            "<span style='color:#0b2c52; font-weight:600;'>Contact Developer:</span> "
            "<span style='color:#0c7c69; font-weight:bold;'>+233 (0) 593400774 / 0503809181</span>"
        )
        self.lbl_contact.setStyleSheet("font-size: 11px; background: transparent; border: none;")
        selectable_flag = (
            Qt.TextInteractionFlag.TextSelectableByMouse
            if hasattr(Qt, "TextInteractionFlag")
            else Qt.TextSelectableByMouse
        )
        self.lbl_contact.setTextInteractionFlags(selectable_flag)

        text_col.addWidget(self.lbl_headline)
        text_col.addWidget(self.lbl_contact)
        row.addLayout(text_col, stretch=1)

        # Smooth cross-fade rotation timer
        self._timer = QTimer(self)
        self._timer.setInterval(4500)
        self._timer.timeout.connect(self._start_fade_out)
        self._timer.start()

    def _easing_curve(self):
        if hasattr(QEasingCurve, "Type"):
            return QEasingCurve.Type.InOutQuad
        return QEasingCurve.InOutQuad

    def _start_fade_out(self):
        self._fade_anim = QPropertyAnimation(self._opacity_fx, b"opacity", self)
        self._fade_anim.setDuration(380)
        self._fade_anim.setStartValue(1.0)
        self._fade_anim.setEndValue(0.0)
        self._fade_anim.setEasingCurve(self._easing_curve())
        self._fade_anim.finished.connect(self._swap_and_fade_in)
        self._fade_anim.start()

    def _swap_and_fade_in(self):
        self._slide_idx = (self._slide_idx + 1) % len(self.SLIDES)
        self.lbl_headline.setText(self.SLIDES[self._slide_idx])
        self._fade_anim = QPropertyAnimation(self._opacity_fx, b"opacity", self)
        self._fade_anim.setDuration(420)
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.setEasingCurve(self._easing_curve())
        self._fade_anim.start()

    def stop_animation(self):
        if self._timer.isActive():
            self._timer.stop()
        if self._fade_anim is not None:
            self._fade_anim.stop()


class GeoCadDialog(QDialog):
    """Primary CAD and Land Surveying Workbench for QGIS Desktop."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("GeoCad — Professional Land Surveying & Cadastral Suite")
        self.resize(1020, 680)

        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(8)

        # Header Banner
        header = QHBoxLayout()
        header.setSpacing(8)

        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, "icon.png")
        if os.path.exists(icon_path):
            icon_lbl = QLabel()
            pix = QPixmap(icon_path)
            smooth = (
                Qt.TransformationMode.SmoothTransformation
                if hasattr(Qt, "TransformationMode")
                else Qt.SmoothTransformation
            )
            icon_lbl.setPixmap(pix.scaledToHeight(40, smooth))
            header.addWidget(icon_lbl)

        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        title_lbl = QLabel("GeoCad Workbench")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #d32f2f;")
        sub_lbl = QLabel("Precision Surveying & Cadastral Engine")
        sub_lbl.setStyleSheet("font-size: 11px; color: #666;")
        title_box.addWidget(title_lbl)
        title_box.addWidget(sub_lbl)
        header.addLayout(title_box)

        header.addSpacing(12)

        # Smooth AriesPlus Promotional & Contact Developer Header Ad Banner
        self.ad_banner = _AriesPlusAdBanner(plugin_dir=plugin_dir, parent=self)
        header.addWidget(self.ad_banner, stretch=1)

        header.addSpacing(8)

        self.btn_about = QPushButton("About / Help")
        self.btn_about.setFixedHeight(32)
        self.btn_about.clicked.connect(self._open_about)
        header.addWidget(self.btn_about)
        layout.addLayout(header)

        # Main Tabbed Workspace
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)

        # Tab 1: Lot Traverse Plotter
        self.tab_traverse = LotPlotterWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_traverse, "Lot Plotter (Bearing & Distance)")

        # Tab 2: Point Plotting & Sequential Boundary Lines
        self.tab_points = PointPlotterWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_points, "Point Ingestion & Boundaries")

        # Tab 3: Bearing & Distance Annotation
        self.tab_beadist = BearingDistanceWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_beadist, "Bearing & Distance (Ft / M)")

        # Tab 4: Cartographic Survey Grid
        self.tab_grid = SurveyGridWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_grid, "Survey Grid Generator")

        # Tab 5: TIN Surface Modeling
        self.tab_tin = TinWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_tin, "TIN Surface Modeler")

        # Tab 6: Topographic Contours
        self.tab_contours = ContourWidget(iface=self.iface, parent=self)
        self.tabs.addTab(self.tab_contours, "Topographic Contours")

        # Connect tab change listener to refresh dynamic layers
        self.tabs.currentChanged.connect(self._on_tab_changed)

        layout.addWidget(self.tabs, stretch=1)

        # Status Bar / Footer
        self.status = QStatusBar()
        self.status.showMessage("GeoCad Ready • AriesPlus Geospatial Solutions (+233 (0) 593400774 / 0503809181)")
        self.status.setStyleSheet("color: #666; font-size: 10px;")
        layout.addWidget(self.status)

    def _on_tab_changed(self, index: int):
        """Refreshes layer dropdowns whenever the user switches tabs."""
        widget = self.tabs.widget(index)
        if widget and hasattr(widget, "_refresh_layers"):
            widget._refresh_layers()

    def showEvent(self, event):
        super().showEvent(event)
        for i in range(self.tabs.count()):
            w = self.tabs.widget(i)
            if w and hasattr(w, "_sync_project_crs"):
                w._sync_project_crs()
        self._on_tab_changed(self.tabs.currentIndex())

    def closeEvent(self, event):
        if hasattr(self, "ad_banner"):
            self.ad_banner.stop_animation()
        if hasattr(self, "tab_traverse") and hasattr(self.tab_traverse, "cleanup_map_tool"):
            self.tab_traverse.cleanup_map_tool()
        super().closeEvent(event)

    def _open_about(self):
        dlg = AboutDialog(parent=self)
        exec_dialog(dlg)
