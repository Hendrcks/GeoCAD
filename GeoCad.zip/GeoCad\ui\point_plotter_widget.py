"""
GeoCad - Field Coordinate Point Ingestion Widget.
Plots survey points from CSV/TXT/KDMS coordinate files and connects sequential boundary strings.

Developed by GeoCad (geocad@example.com).
"""

import os
from typing import Optional

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QComboBox, QCheckBox, QSpinBox,
        QDoubleSpinBox, QFileDialog, QMessageBox, QTextEdit
    )
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
        QgsPoint, QgsField, QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
        QgsTextFormat, QgsTextBufferSettings
    )
    from qgis.gui import QgsProjectionSelectionDialog
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QComboBox, QCheckBox, QSpinBox,
        QDoubleSpinBox, QFileDialog, QMessageBox, QTextEdit
    )
    HAS_QGIS = False

from ..core.compat import make_qgs_field, exec_dialog, set_label_placement
from ..core.point_plotter import PointPlotter, PointPlottingResult


class PointPlotterWidget(QWidget):
    """GUI widget for plotting survey coordinate files into QGIS."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.last_result: Optional[PointPlottingResult] = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # File Selection Group
        gb_file = QGroupBox("Coordinate File Selection")
        gb_file_layout = QGridLayout(gb_file)

        gb_file_layout.addWidget(QLabel("Coordinate File:"), 0, 0)
        self.txt_filepath = QLineEdit()
        self.txt_filepath.setPlaceholderText("Select CSV, TXT, or KDMS survey file...")
        self.btn_browse = QPushButton("Browse...")
        self.btn_browse.clicked.connect(self._browse_file)
        self.btn_preview = QPushButton("Preview")
        self.btn_preview.clicked.connect(self._preview_file)

        gb_file_layout.addWidget(self.txt_filepath, 0, 1)
        gb_file_layout.addWidget(self.btn_browse, 0, 2)
        gb_file_layout.addWidget(self.btn_preview, 0, 3)

        layout.addWidget(gb_file)

        # Ingestion Parameters Group
        gb_params = QGroupBox("Import Parameters & Coordinate Format")
        p_layout = QGridLayout(gb_params)
        p_layout.setVerticalSpacing(8)

        # Format Profile
        p_layout.addWidget(QLabel("Coordinate Format:"), 0, 0)
        self.cmb_format = QComboBox()
        self.cmb_format.addItems(PointPlotter.PROFILES)
        self.cmb_format.setCurrentText("Auto-detect")
        p_layout.addWidget(self.cmb_format, 0, 1)

        # Delimiter
        p_layout.addWidget(QLabel("Delimiter:"), 0, 2)
        self.cmb_delim = QComboBox()
        self.cmb_delim.addItem("Auto-detect", "auto")
        self.cmb_delim.addItem("Comma (,)", ",")
        self.cmb_delim.addItem("Semicolon (;)", ";")
        self.cmb_delim.addItem("Tab (\\t)", "\t")
        self.cmb_delim.addItem("Space ( )", " ")
        p_layout.addWidget(self.cmb_delim, 0, 3)

        # Header skip checkbox
        self.chk_has_header = QCheckBox("File has header row")
        self.chk_has_header.setChecked(False)
        p_layout.addWidget(self.chk_has_header, 1, 0, 1, 2)

        # Target CRS
        p_layout.addWidget(QLabel("Target CRS:"), 2, 0)
        crs_row = QHBoxLayout()
        self.txt_crs = QLineEdit("EPSG:3124 — PRS92 / Philippine Zone 4")
        self.btn_crs = QPushButton("...")
        self.btn_crs.setFixedWidth(28)
        self.btn_crs.clicked.connect(self._select_crs)
        crs_row.addWidget(self.txt_crs)
        crs_row.addWidget(self.btn_crs)
        p_layout.addLayout(crs_row, 2, 1, 1, 3)

        layout.addWidget(gb_params)

        # Symbology & Sequential Connection Group
        gb_style = QGroupBox("Point Display, Labels, & Sequential Joining (seqline)")
        s_layout = QGridLayout(gb_style)
        s_layout.setVerticalSpacing(8)

        s_layout.addWidget(QLabel("Point Symbol Size:"), 0, 0)
        self.spn_pnt_size = QDoubleSpinBox()
        self.spn_pnt_size.setValue(3.0)
        self.spn_pnt_size.setRange(0.5, 50.0)
        s_layout.addWidget(self.spn_pnt_size, 0, 1)

        s_layout.addWidget(QLabel("Text Label Size:"), 0, 2)
        self.spn_txt_size = QDoubleSpinBox()
        self.spn_txt_size.setValue(9.0)
        self.spn_txt_size.setRange(4.0, 30.0)
        s_layout.addWidget(self.spn_txt_size, 0, 3)

        s_layout.addWidget(QLabel("Label Offset Distance:"), 1, 0)
        self.spn_offset = QDoubleSpinBox()
        self.spn_offset.setValue(5.0)
        self.spn_offset.setRange(0.0, 100.0)
        s_layout.addWidget(self.spn_offset, 1, 1)

        # Sequential Connection
        self.chk_seq = QCheckBox("Sequential Connection (Join matching station prefixes with lines)")
        self.chk_seq.setChecked(True)
        s_layout.addWidget(self.chk_seq, 2, 0, 1, 3)

        s_layout.addWidget(QLabel("Prefix Length:"), 2, 3)
        self.spn_prefix = QSpinBox()
        self.spn_prefix.setValue(2)
        self.spn_prefix.setRange(1, 5)
        s_layout.addWidget(self.spn_prefix, 2, 4 if s_layout.columnCount() > 4 else 3)

        layout.addWidget(gb_style)

        # Preview Log / Output status
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setPlaceholderText("File summary and parsing diagnostics will appear here...")
        self.txt_log.setMaximumHeight(130)
        layout.addWidget(self.txt_log)

        # Bottom Actions
        act_row = QHBoxLayout()
        self.btn_parse = QPushButton("Analyze File")
        self.btn_plot = QPushButton("Plot Points to QGIS")
        self.btn_plot.setStyleSheet("background-color: #2e7d32; color: white; font-weight: bold; padding: 7px 18px;")

        act_row.addWidget(self.btn_parse)
        act_row.addStretch()
        act_row.addWidget(self.btn_plot)
        layout.addLayout(act_row)

        self.btn_parse.clicked.connect(self._parse_file)
        self.btn_plot.clicked.connect(self._plot_to_qgis)

        # Auto-reparse on settings change if a file is already loaded
        self.cmb_format.currentIndexChanged.connect(self._on_settings_changed)
        self.cmb_delim.currentIndexChanged.connect(self._on_settings_changed)
        self.chk_has_header.toggled.connect(self._on_settings_changed)
        self.chk_seq.toggled.connect(self._on_settings_changed)
        self.spn_prefix.valueChanged.connect(self._on_settings_changed)

    def _on_settings_changed(self):
        """Re-analyzes file if one is already selected when user toggles settings."""
        if self.txt_filepath.text().strip():
            self._parse_file()

    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Coordinate File", "", "All Coordinate Files (*.csv *.txt *.dat *.prn);;CSV Files (*.csv);;Text Files (*.txt);;All Files (*.*)"
        )
        if path:
            self.txt_filepath.setText(path)
            self._parse_file()

    def _preview_file(self):
        path = self.txt_filepath.text().strip()
        if not path:
            QMessageBox.warning(self, "Preview", "Please select a file first.")
            return
        if not os.path.exists(path):
            QMessageBox.warning(self, "Preview", f"File does not exist:\n{path}")
            return
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                head = [f.readline() for _ in range(25)]
            preview_txt = "".join(head)
            QMessageBox.information(self, f"Preview (First 25 lines of {os.path.basename(path)})", preview_txt)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not preview file:\n{str(e)}")

    def _select_crs(self):
        if HAS_QGIS:
            selector = QgsProjectionSelectionDialog(self)
            if exec_dialog(selector):
                crs = selector.crs()
                self.txt_crs.setText(f"{crs.authid()} — {crs.description()}")

    def _parse_file(self) -> Optional[PointPlottingResult]:
        path = self.txt_filepath.text().strip()
        if not path:
            QMessageBox.warning(self, "Parse", "Please select a coordinate file.")
            return None

        if not os.path.exists(path):
            QMessageBox.warning(self, "Parse", f"Coordinate file not found:\n{path}")
            return None

        try:
            delim = self.cmb_delim.currentData()
            res = PointPlotter.parse_file(
                filepath_or_content=path,
                profile=self.cmb_format.currentText(),
                delimiter=delim,
                enable_sequential_lines=self.chk_seq.isChecked(),
                prefix_length=self.spn_prefix.value(),
                has_header=self.chk_has_header.isChecked()
            )
            self.last_result = res

            log_lines = [
                f"=== GeoCad Coordinate File Analysis ===",
                f"File: {os.path.basename(path)}",
                f"Format Profile: {self.cmb_format.currentText()}",
                f"Total Valid Points Ingested: {len(res.points)}",
                f"Sequential Boundary Line Strings: {len(res.boundary_lines)}",
            ]
            if res.points:
                log_lines.extend([
                    f"Easting Bounds: {res.min_easting:.3f} to {res.max_easting:.3f}",
                    f"Northing Bounds: {res.min_northing:.3f} to {res.max_northing:.3f}",
                    f"Elevation Bounds: {res.min_elevation:.3f} to {res.max_elevation:.3f}",
                ])
            if res.skipped_rows:
                log_lines.append(f"Skipped / Invalid Rows: {len(res.skipped_rows)}")
                for line_no, raw, reason in res.skipped_rows[:10]:
                    log_lines.append(f"  Line {line_no}: {reason} -> '{raw[:50]}'")

            self.txt_log.setPlainText("\n".join(log_lines))
            return res
        except Exception as e:
            self.txt_log.setPlainText(f"Error parsing coordinate file:\n{str(e)}")
            QMessageBox.critical(self, "Parse Error", f"Failed to parse coordinate file:\n{str(e)}")
            return None

    def _plot_to_qgis(self):
        res = self.last_result or self._parse_file()
        if not res or not res.points:
            QMessageBox.warning(self, "Plotting", "No valid points to plot.")
            return

        if not HAS_QGIS or not self.iface:
            QMessageBox.information(self, "Parsed Points", f"Parsed {len(res.points)} points successfully.")
            return

        try:
            crs_str = self.txt_crs.text().split("—")[0].strip() or "EPSG:3124"

            # 1. Point Layer
            pnt_layer = QgsVectorLayer(f"PointZ?crs={crs_str}", "GeoCad - Points", "memory")
            pr = pnt_layer.dataProvider()
            pr.addAttributes([
                make_qgs_field("Point_ID", "string"),
                make_qgs_field("Easting", "double", 12, 3),
                make_qgs_field("Northing", "double", 12, 3),
                make_qgs_field("Elevation", "double", 10, 3),
                make_qgs_field("Label", "string"),
            ])
            pnt_layer.updateFields()

            features = []
            for p in res.points:
                geom = QgsGeometry.fromPoint(QgsPoint(p.easting, p.northing, p.elevation))
                feat = QgsFeature()
                feat.setGeometry(geom)
                feat.setAttributes([p.point_id, p.easting, p.northing, p.elevation, p.label])
                features.append(feat)

            pr.addFeatures(features)
            pnt_layer.updateExtents()

            # Configure Labels
            settings = QgsPalLayerSettings()
            settings.fieldName = "Point_ID"
            set_label_placement(settings, "AroundPoint")
            text_format = QgsTextFormat()
            text_format.setSize(self.spn_txt_size.value())
            buffer = QgsTextBufferSettings()
            buffer.setEnabled(True)
            buffer.setSize(1)
            text_format.setBuffer(buffer)
            settings.setFormat(text_format)
            pnt_layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            pnt_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(pnt_layer)

            # 2. Boundary Lines Layer (if sequential enabled)
            if res.boundary_lines:
                line_layer = QgsVectorLayer(f"LineStringZ?crs={crs_str}", "GeoCad - Boundary Strings", "memory")
                lpr = line_layer.dataProvider()
                lpr.addAttributes([
                    make_qgs_field("String_ID", "string"),
                    make_qgs_field("Vertex_Count", "int"),
                ])
                line_layer.updateFields()

                line_feats = []
                for idx, pts in enumerate(res.boundary_lines):
                    qpts = [QgsPoint(pt[0], pt[1], pt[2]) for pt in pts]
                    lgeom = QgsGeometry.fromPolyline(qpts)
                    lf = QgsFeature()
                    lf.setGeometry(lgeom)
                    lf.setAttributes([f"STR_{idx+1}", len(pts)])
                    line_feats.append(lf)

                lpr.addFeatures(line_feats)
                line_layer.updateExtents()
                QgsProject.instance().addMapLayer(line_layer)

            canvas = self.iface.mapCanvas()
            canvas.setExtent(pnt_layer.extent())
            canvas.refresh()

            QMessageBox.information(
                self,
                "Plotting Completed",
                f"Successfully plotted {len(res.points)} points into QGIS!\n"
                f"Generated {len(res.boundary_lines)} boundary linestrings."
            )
        except Exception as e:
            QMessageBox.critical(self, "Plotting Error", f"Failed to plot points into QGIS:\n{str(e)}")
