"""
GeoCad - OCR Review Dialog.
Matches the cadastral survey review interface for verifying bearings and distances
extracted from scanned titles, technical descriptions, and field sheets.

Compatible with QGIS 3 (Qt5) and QGIS 4 (Qt6).
Developed by GeoCad (geocad@example.com).
"""

from typing import List, Dict, Any, Optional

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget,
        QTableWidgetItem, QTextEdit, QPushButton, QHeaderView, QMessageBox
    )
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget,
        QTableWidgetItem, QTextEdit, QPushButton, QHeaderView, QMessageBox
    )

from ..core.compat import (
    HEADER_RESIZE_TO_CONTENTS,
    HEADER_STRETCH,
    ALIGN_CENTER,
    ALIGN_RIGHT_VCENTER,
)
from ..core.bearing_parser import BearingParser


class OcrReviewDialog(QDialog):
    """Review and editing dialog for extracted traverse bearings and distances."""

    def __init__(self, raw_text: str = "", parsed_rows: Optional[List[Dict[str, Any]]] = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Review extracted bearings and distances")
        self.resize(580, 520)
        self.confirmed_rows: List[Dict[str, Any]] = []

        self._init_ui(raw_text, parsed_rows or [])

    def _init_ui(self, raw_text: str, rows: List[Dict[str, Any]]):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Header instructional note (matching Screenshot 2)
        info_label = QLabel(
            "Compare every N/S and E/W with the source before importing. Missing "
            "directions are not guessed. Check the row count: incomplete rows may "
            "not have been extracted. The original and enhanced OCR readings differ; "
            "check the alternate reading below."
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #444; font-size: 11px; margin-bottom: 5px;")
        layout.addWidget(info_label)

        # Traverse Table
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["From", "To", "Bearing", "Distance (m)"])
        self.table.horizontalHeader().setSectionResizeMode(0, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(1, HEADER_RESIZE_TO_CONTENTS)
        self.table.horizontalHeader().setSectionResizeMode(2, HEADER_STRETCH)
        self.table.horizontalHeader().setSectionResizeMode(3, HEADER_RESIZE_TO_CONTENTS)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table, stretch=2)

        # OCR Source Text Area
        src_row = QHBoxLayout()
        src_label = QLabel("OCR source text (edit and re-parse if needed):")
        src_label.setStyleSheet("font-weight: bold; font-size: 11px;")
        self.btn_reparse = QPushButton("Re-parse Text")
        self.btn_reparse.clicked.connect(self._reparse_text)
        src_row.addWidget(src_label)
        src_row.addStretch()
        src_row.addWidget(self.btn_reparse)
        layout.addLayout(src_row)

        self.text_source = QTextEdit()
        self.text_source.setPlainText(raw_text)
        self.text_source.setMaximumHeight(110)
        self.text_source.setStyleSheet("font-family: monospace; font-size: 11px;")
        layout.addWidget(self.text_source, stretch=1)

        # Buttons
        btn_layout = QHBoxLayout()
        self.btn_add_row = QPushButton("+ Missing row")
        self.btn_remove_row = QPushButton("Remove row")
        self.btn_cancel = QPushButton("Cancel")
        self.btn_import = QPushButton("Import reviewed rows")
        self.btn_import.setStyleSheet(
            "background-color: #2e7d32; color: white; font-weight: bold; padding: 6px 14px; border-radius: 4px;"
        )

        btn_layout.addWidget(self.btn_add_row)
        btn_layout.addWidget(self.btn_remove_row)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_cancel)
        btn_layout.addWidget(self.btn_import)
        layout.addLayout(btn_layout)

        # Connections
        self.btn_add_row.clicked.connect(self._add_row)
        self.btn_remove_row.clicked.connect(self._remove_row)
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_import.clicked.connect(self._accept_rows)

        # Populate rows
        if rows:
            self._populate_rows(rows)
        elif raw_text:
            self._reparse_text()

    def _populate_rows(self, rows: List[Dict[str, Any]]):
        self.table.setRowCount(len(rows))
        for r_idx, r in enumerate(rows):
            f_item = QTableWidgetItem(str(r.get("from", r_idx + 1)))
            t_item = QTableWidgetItem(str(r.get("to", r_idx + 2)))
            b_item = QTableWidgetItem(str(r.get("bearing", "")))
            d_val = r.get("distance", "")
            d_str = f"{float(d_val):.2f}" if d_val != "" else ""
            d_item = QTableWidgetItem(d_str)

            f_item.setTextAlignment(ALIGN_CENTER)
            t_item.setTextAlignment(ALIGN_CENTER)
            d_item.setTextAlignment(ALIGN_RIGHT_VCENTER)

            self.table.setItem(r_idx, 0, f_item)
            self.table.setItem(r_idx, 1, t_item)
            self.table.setItem(r_idx, 2, b_item)
            self.table.setItem(r_idx, 3, d_item)

    def _reparse_text(self):
        from ..core.ocr_reader import OcrTableReader
        rows, _ = OcrTableReader.parse_content(self.text_source.toPlainText())
        self._populate_rows(rows)

    def _add_row(self):
        r_idx = self.table.rowCount()
        self.table.insertRow(r_idx)
        prev_to = self.table.item(r_idx - 1, 1).text() if r_idx > 0 and self.table.item(r_idx - 1, 1) else str(r_idx + 1)
        next_to = str(int(prev_to) + 1) if prev_to.isdigit() else ""

        f_item = QTableWidgetItem(prev_to)
        t_item = QTableWidgetItem(next_to)
        b_item = QTableWidgetItem("")
        d_item = QTableWidgetItem("")

        f_item.setTextAlignment(ALIGN_CENTER)
        t_item.setTextAlignment(ALIGN_CENTER)
        self.table.setItem(r_idx, 0, f_item)
        self.table.setItem(r_idx, 1, t_item)
        self.table.setItem(r_idx, 2, b_item)
        self.table.setItem(r_idx, 3, d_item)

    def _remove_row(self):
        curr = self.table.currentRow()
        if curr >= 0:
            self.table.removeRow(curr)
        elif self.table.rowCount() > 0:
            self.table.removeRow(self.table.rowCount() - 1)

    def _accept_rows(self):
        results = []
        for r_idx in range(self.table.rowCount()):
            f_txt = self.table.item(r_idx, 0).text().strip() if self.table.item(r_idx, 0) else ""
            t_txt = self.table.item(r_idx, 1).text().strip() if self.table.item(r_idx, 1) else ""
            b_txt = self.table.item(r_idx, 2).text().strip() if self.table.item(r_idx, 2) else ""
            d_txt = self.table.item(r_idx, 3).text().strip() if self.table.item(r_idx, 3) else ""

            if not b_txt or not d_txt:
                continue

            try:
                dist_val = float(d_txt.replace(",", ""))
            except ValueError:
                QMessageBox.warning(self, "Validation Error", f"Row {r_idx + 1}: Invalid distance '{d_txt}'.")
                return

            az = BearingParser.parse_to_azimuth(b_txt)
            if az is None:
                QMessageBox.warning(self, "Validation Error", f"Row {r_idx + 1}: Unrecognized bearing '{b_txt}'.")
                return

            results.append({
                "from": f_txt or str(r_idx + 1),
                "to": t_txt or str(r_idx + 2),
                "bearing": BearingParser.azimuth_to_quadrant(az),
                "distance": dist_val
            })

        if not results:
            QMessageBox.warning(self, "No Records", "No valid traverse records found.")
            return

        self.confirmed_rows = results
        self.accept()
