"""
GeoCad - About Dialog & Information Hub.
Compatible with QGIS 3 (Qt5) and QGIS 4 (Qt6).
"""

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame
    )
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame
    )

from ..core.compat import ALIGN_CENTER, FRAME_HLINE, FRAME_SUNKEN


class AboutDialog(QDialog):
    """About dialog presenting GeoCad suite info."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("About GeoCad")
        self.setFixedSize(540, 420)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 25, 25, 20)
        layout.setSpacing(12)

        # Title Banner
        title = QLabel("GeoCad")
        title.setStyleSheet("font-size: 26px; font-weight: bold; color: #1565c0;")
        title.setAlignment(ALIGN_CENTER)
        layout.addWidget(title)

        subtitle = QLabel("Precision Land Surveying & Cadastral CAD Suite for QGIS")
        subtitle.setStyleSheet("font-size: 13px; font-weight: 500; color: #555;")
        subtitle.setAlignment(ALIGN_CENTER)
        layout.addWidget(subtitle)

        ver = QLabel("Version 1.0.0 • Professional Edition")
        ver.setStyleSheet("font-size: 11px; color: #777; margin-bottom: 5px;")
        ver.setAlignment(ALIGN_CENTER)
        layout.addWidget(ver)

        # Separator line
        sep = QFrame()
        sep.setFrameShape(FRAME_HLINE)
        sep.setFrameShadow(FRAME_SUNKEN)
        layout.addWidget(sep)

        # Details
        info_html = (
            "<p style='font-size: 12px; line-height: 1.6; color: #333; text-align: center;'>"
            "<b>GeoCad</b> brings comprehensive land surveying, cadastral boundary computation, "
            "and terrain modeling capabilities to QGIS Desktop.<br><br>"
            "<b>Key Capabilities:</b><br>"
            "• Cadastral Lot Traverse Plotter (OCR, Image Upload, Clipboard Paste, CSV Import)<br>"
            "• Field Coordinate Point Ingestion & Sequential Boundaries (seqline)<br>"
            "• Surveyor Bearing & Distance Annotation (Meters & Feet)<br>"
            "• Cartographic Survey Grid Generator with Collar Callouts<br>"
            "• Delaunay TIN Surface Modeling & 3D Analytics<br>"
            "• Topographic Contour Generation with Spline Smoothing<br>"
            "</p>"
        )
        info_label = QLabel(info_html)
        info_label.setWordWrap(True)
        info_label.setAlignment(ALIGN_CENTER)
        layout.addWidget(info_label)

        layout.addStretch()

        # Close Button
        btn_box = QHBoxLayout()
        btn_box.addStretch()
        btn_close = QPushButton("Close")
        btn_close.setFixedWidth(100)
        btn_close.clicked.connect(self.accept)
        btn_box.addWidget(btn_close)
        btn_box.addStretch()
        layout.addLayout(btn_box)
