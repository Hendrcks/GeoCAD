"""
GeoCad Processing Algorithm: Build Delaunay TIN Surface.
Constructs 2.5D Delaunay triangular meshes and computes terrain surface analytics.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.core import (
        QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer,
        QgsProcessingParameterField, QgsProcessingParameterFeatureSink,
        QgsFeature, QgsGeometry, QgsPoint, QgsFields, QgsField, QgsWkbTypes
    )
    from qgis.PyQt.QtCore import QVariant
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm: pass

from ..core.compat import make_qgs_field
from ..core.tin_engine import TinEngine


class BuildTinAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to build a Delaunay TIN surface."""

    INPUT_POINTS = "INPUT_POINTS"
    Z_FIELD = "Z_FIELD"
    OUTPUT_TIN = "OUTPUT_TIN"

    def createInstance(self):
        return BuildTinAlgorithm()

    def name(self):
        return "build_tin"

    def displayName(self):
        return "Build Delaunay TIN Surface"

    def group(self):
        return "Terrain & Surfaces"

    def groupId(self):
        return "terrain"

    def shortHelpString(self):
        return "Constructs a continuous 3D Delaunay Triangular Irregular Network (TIN) surface from spot elevations."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT_POINTS, "Spot Elevations Point Layer", types=[QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterField(self.Z_FIELD, "Elevation Attribute Field (Optional if PointZ)", parentLayerParameterName=self.INPUT_POINTS, optional=True))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT_TIN, "TIN Surface Polygon Output", type=QgsProcessing.TypeVectorPolygon))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT_POINTS, context)
        z_field = self.parameterAsString(parameters, self.Z_FIELD, context)

        points = []
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            p = geom.asPoint()
            if z_field:
                try:
                    z = float(feat[z_field])
                except (ValueError, TypeError):
                    z = 0.0
            else:
                z = geom.constGet().z() if geom.constGet().is3D() else 0.0
            points.append((p.x(), p.y(), z))

        triangles, report = TinEngine.build_tin(points, surface_name=layer.name())

        fields = QgsFields()
        fields.append(make_qgs_field("Tri_ID", "int"))
        fields.append(make_qgs_field("Area_2D", "double"))
        fields.append(make_qgs_field("Area_3D", "double"))
        fields.append(make_qgs_field("Slope_Deg", "double"))
        fields.append(make_qgs_field("Aspect_Deg", "double"))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_TIN, context, fields, QgsWkbTypes.PolygonZ, layer.crs()
        )

        for tri in triangles:
            qpts = [
                QgsPoint(tri.v1[0], tri.v1[1], tri.v1[2]),
                QgsPoint(tri.v2[0], tri.v2[1], tri.v2[2]),
                QgsPoint(tri.v3[0], tri.v3[1], tri.v3[2]),
                QgsPoint(tri.v1[0], tri.v1[1], tri.v1[2]),
            ]
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPolygonZ([qpts]))
            f.setAttributes([tri.id, tri.area_2d, tri.area_3d, tri.slope_deg, tri.aspect_deg])
            sink.addFeature(f)

        return {self.OUTPUT_TIN: dest_id}

