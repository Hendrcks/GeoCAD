"""
GeoCad Complete Test Suite.
Validates all core computational modules without requiring a live QGIS GUI instance.
"""

import math
import sys
import os

# Add parent directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.bearing_parser import BearingParser
from core.traverse_engine import TraverseEngine
from core.point_plotter import PointPlotter
from core.bearing_distance_annotator import BearingDistanceAnnotator
from core.grid_generator import SurveyGridGenerator
from core.tin_engine import TinEngine
from core.contour_engine import ContourEngine
from core.ocr_reader import OcrTableReader


def test_bearing_parser():
    print("Testing BearingParser...")
    # Quadrant parsing
    az1 = BearingParser.parse_to_azimuth("N 28°38' E")
    assert az1 is not None and abs(az1 - (28 + 38/60)) < 1e-4

    az2 = BearingParser.parse_to_azimuth("N.28-38E.")
    assert az2 is not None and abs(az2 - az1) < 1e-4

    az3 = BearingParser.parse_to_azimuth("S 16°35' W")
    assert az3 is not None and abs(az3 - (180 + 16 + 35/60)) < 1e-4

    # Azimuth to Quadrant formatting
    q_str = BearingParser.azimuth_to_quadrant(az1)
    assert "N" in q_str and "E" in q_str and "28" in q_str

    # Back-azimuth
    back_az = BearingParser.reverse_azimuth(az1)
    assert abs(back_az - (az1 + 180)) < 1e-4
    print("  -> BearingParser passed!")


def test_traverse_engine():
    print("Testing TraverseEngine...")
    # Reference point and tie line calculation from screenshots
    ref_e = 485282.433
    ref_n = 1552300.558
    tie_b = "S 16°35' W"
    tie_d = 4924.70

    tie_az = BearingParser.parse_to_azimuth(tie_b)
    de, dn = BearingParser.delta_en(tie_az, tie_d)
    start_e = ref_e + de
    start_n = ref_n + dn

    # Verify start coordinates match screenshot: ~483876.88, ~1547580.70
    assert abs(start_e - 483876.88) < 0.1
    assert abs(start_n - 1547580.70) < 0.1

    # Six reference lot traverse legs
    legs = [
        {"from": "1", "to": "2", "bearing": "N 28°38' E", "distance": 246.48},
        {"from": "2", "to": "3", "bearing": "S 88°56' E", "distance": 29.99},
        {"from": "3", "to": "4", "bearing": "S 68°50' E", "distance": 42.54},
        {"from": "4", "to": "5", "bearing": "S 52°21' E", "distance": 52.49},
        {"from": "5", "to": "6", "bearing": "S 30°20' W", "distance": 250.38},
        {"from": "6", "to": "1", "bearing": "N 65°06' W", "distance": 113.42},
    ]

    res = TraverseEngine.compute_lot(
        lot_no="LOT 1",
        legs_data=legs,
        start_coord=(start_e, start_n),
        reference_coord=(ref_e, ref_n),
        tie_bearing=tie_b,
        tie_distance=tie_d
    )

    # Perimeter should equal sum of legs = 735.30 m
    assert abs(res.perimeter - 735.30) < 0.01

    # Area should be ~30,000 sq.m
    assert abs(res.area_sqm - 30003.82) < 20.0  # Close tolerance with unadjusted/adjusted coords

    assert len(res.legs) == 6
    assert res.is_closed is True
    print(f"  -> Traverse Area: {res.area_sqm:.2f} sq.m, Perimeter: {res.perimeter:.2f} m")
    print("  -> TraverseEngine passed!")


def test_point_plotter():
    print("Testing PointPlotter...")
    csv_sample = (
        "BD01,1547580.70,483876.88,105.2,Boundary 1\n"
        "BD02,1547797.02,483995.00,108.5,Boundary 2\n"
        "BD03,1547796.46,484024.98,107.8,Boundary 3\n"
        "ST01,1547000.00,483000.00,100.0,Station 1\n"
    )
    res = PointPlotter.parse_file(
        filepath_or_content=csv_sample,
        profile="P,N,E,Z,L",
        enable_sequential_lines=True,
        prefix_length=2
    )
    assert len(res.points) == 4
    # Points with prefix BD (3 points) should be connected into 1 boundary line
    assert len(res.boundary_lines) == 1
    assert len(res.boundary_lines[0]) == 3
    print("  -> PointPlotter passed!")


def test_bearing_distance_annotator():
    print("Testing BearingDistanceAnnotator...")
    p1 = (483876.88, 1547580.70)
    p2 = (483995.00, 1547797.02)
    ann = BearingDistanceAnnotator.annotate_segment(p1, p2, mode="LR", unit="Meters", text_height=2.5)
    assert ann is not None
    assert "N" in ann.bearing_str and "E" in ann.bearing_str
    assert "m" in ann.distance_str

    # Test Feet unit
    ann_ft = BearingDistanceAnnotator.annotate_segment(p1, p2, mode="LR", unit="Feet")
    assert "'" in ann_ft.distance_str
    print("  -> BearingDistanceAnnotator passed!")


def test_grid_generator():
    print("Testing SurveyGridGenerator...")
    res = SurveyGridGenerator.generate_grid(
        x1=483000.0, y1=1547000.0, x2=485000.0, y2=1549000.0, interval_x=200.0, draw_ticks=False
    )
    assert len(res.grid_lines_wkt) > 0
    assert len(res.annotations) > 0
    assert res.bounding_box_wkt.startswith("POLYGON")
    print(f"  -> Generated {len(res.grid_lines_wkt)} grid lines and {len(res.annotations)} collar callouts.")
    print("  -> SurveyGridGenerator passed!")


def test_tin_engine():
    print("Testing TinEngine...")
    pts = [
        (0.0, 0.0, 10.0),
        (100.0, 0.0, 15.0),
        (50.0, 80.0, 25.0),
        (20.0, 40.0, 18.0),
        (80.0, 40.0, 20.0),
    ]
    triangles, report = TinEngine.build_tin(pts, surface_name="TestSurface")
    assert len(triangles) >= 3
    assert report.area_3d_sqm > 0
    assert report.min_z == 10.0
    assert report.max_z == 25.0
    print(f"  -> Built {len(triangles)} triangles, 3D Area: {report.area_3d_sqm:.2f} sq.m")
    print("  -> TinEngine passed!")


def test_contour_engine():
    print("Testing ContourEngine...")
    pts = [
        (0.0, 0.0, 10.0),
        (100.0, 0.0, 10.0),
        (100.0, 100.0, 50.0),
        (0.0, 100.0, 50.0),
        (50.0, 50.0, 30.0),
    ]
    triangles, _ = TinEngine.build_tin(pts)
    res = ContourEngine.generate_contours(triangles, interval=5.0, base_elevation=10.0, index_multiplier=2)
    assert len(res.contours) > 0
    assert len(res.index_contours) > 0
    print(f"  -> Generated {len(res.contours)} contours ({len(res.index_contours)} index contours).")
    print("  -> ContourEngine passed!")


def test_ocr_reader():
    print("Testing OcrTableReader...")
    text = (
        "1-2 N.28-38E. 246.48 M.\n"
        "2-3 S.88-56E. 29.99 M.\n"
        "3-4 s.68-soE. 42.54 M.\n"
        "5-6 S.30-20W. 250.38M.\n"
        "6-1 N.65-D6W. 113.42 M.\n"
    )
    rows = OcrTableReader.parse_text(text)
    assert len(rows) >= 4
    assert rows[0].distance_val == 246.48
    assert "N" in rows[0].bearing_raw and "E" in rows[0].bearing_raw

    # Test CSV parsing (Exported format)
    csv_text = (
        "Index,From,To,Bearing,Distance_m,Azimuth_deg,Start_E,Start_N,End_E,End_N\n"
        "1,1,2,N 28°38' E,246.48,28.6333,483876.88,1547580.70,483995.00,1547797.02\n"
        "2,2,3,S 88°56' E,29.99,91.0667,483995.00,1547797.02,484024.98,1547796.46\n"
    )
    c_rows, coords = OcrTableReader.parse_content(csv_text)
    assert len(c_rows) == 2
    assert coords == (483876.88, 1547580.70)
    print("  -> OcrTableReader passed!")


if __name__ == "__main__":
    test_bearing_parser()
    test_traverse_engine()
    test_point_plotter()
    test_bearing_distance_annotator()
    test_grid_generator()
    test_tin_engine()
    test_contour_engine()
    test_ocr_reader()
    print("\n==============================================")
    print("ALL GEOCAD UNIT TESTS PASSED WITH 100% SUCCESS!")
    print("==============================================")

