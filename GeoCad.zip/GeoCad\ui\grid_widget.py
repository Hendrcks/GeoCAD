"""
GeoCad - Cartographic Survey Grid Widget.
Generates boundary collars, internal grid lines or cross tic marks,
and exterior coordinate callout annotations.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QRadioButton, QDoubleSpinBox,
        QCheckBox, QMessageBox, QComboBox
    )
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
        QgsField, QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
        QgsTextFormat, QgsTextBufferSettings
    )
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QLineEdit, QPushButton, QRadioButton, QDoubleSpinBox,
        QCheckBox, QMessageBox, QComboBox
    )
    HAS_QGIS = False

from ..core.compat import make_qgs_field, set_label_placement
from ..core.grid_generator import SurveyGridGenerator


class SurveyGridWidget(QWidget):
    """UI for generating coordinate survey grids with border collar annotations."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # Extents Group
        gb_extents = QGroupBox("Grid Bounding Limits (Lower-Left & Upper-Right)")
        e_layout = QGridLayout(gb_extents)
        e_layout.setVerticalSpacing(8)

        # Source buttons
        src_row = QHBoxLayout()
        self.btn_canvas_ext = QPushButton("Use Map Canvas Extent")
        self.btn_canvas_ext.clicked.connect(self._get_canvas_extent)
        self.btn_layer_ext = QPushButton("Use Active Layer Extent")
        self.btn_layer_ext.clicked.connect(self._get_layer_extent)
        src_row.addWidget(self.btn_canvas_ext)
        src_row.addWidget(self.btn_layer_ext)
        src_row.addStretch()
        e_layout.addLayout(src_row, 0, 0, 1, 4)

        # Lower-Left
        e_layout.addWidget(QLabel("Lower-Left X1 (Easting):"), 1, 0)
        self.txt_x1 = QLineEdit()
        self.txt_x1.setPlaceholderText("Lower-Left X1")
        e_layout.addWidget(self.txt_x1, 1, 1)

        e_layout.addWidget(QLabel("Lower-Left Y1 (Northing):"), 1, 2)
        self.txt_y1 = QLineEdit()
        self.txt_y1.setPlaceholderText("Lower-Left Y1")
        e_layout.addWidget(self.txt_y1, 1, 3)

        # Upper-Right
        e_layout.addWidget(QLabel("Upper-Right X2 (Easting):"), 2, 0)
        self.txt_x2 = QLineEdit()
        self.txt_x2.setPlaceholderText("Upper-Right X2")
        e_layout.addWidget(self.txt_x2, 2, 1)

        e_layout.addWidget(QLabel("Upper-Right Y2 (Northing):"), 2, 2)
        self.txt_y2 = QLineEdit()
        self.txt_y2.setPlaceholderText("Upper-Right Y2")
        e_layout.addWidget(self.txt_y2, 2, 3)

        layout.addWidget(gb_extents)

        # Grid Style & Spacing Group
        gb_style = QGroupBox("Grid Spacing & Symbology Style")
        s_layout = QGridLayout(gb_style)
        s_layout.setVerticalSpacing(8)

        # Grid Lines vs Tic Marks
        style_row = QHBoxLayout()
        self.rb_lines = QRadioButton("Full Grid Lines (gline)")
        self.rb_lines.setChecked(True)
        self.rb_ticks = QRadioButton("Cross Tic Marks (gtic)")
        style_row.addWidget(self.rb_lines)
        style_row.addWidget(self.rb_ticks)
        style_row.addStretch()
        s_layout.addLayout(style_row, 0, 0, 1, 4)

        # Grid Spacing
        s_layout.addWidget(QLabel("Grid Interval X (m):"), 1, 0)
        self.spn_int_x = QDoubleSpinBox()
        self.spn_int_x.setValue(200.0)
        self.spn_int_x.setRange(10.0, 50000.0)
        s_layout.addWidget(self.spn_int_x, 1, 1)

        s_layout.addWidget(QLabel("Grid Interval Y (m):"), 1, 2)
        self.spn_int_y = QDoubleSpinBox()
        self.spn_int_y.setValue(200.0)
        self.spn_int_y.setRange(10.0, 50000.0)
        s_layout.addWidget(self.spn_int_y, 1, 3)

        # Tic Size
        s_layout.addWidget(QLabel("Tic Mark Arm Size (m):"), 2, 0)
        self.spn_tic_size = QDoubleSpinBox()
        self.spn_tic_size.setValue(10.0)
        self.spn_tic_size.setRange(1.0, 500.0)
        s_layout.addWidget(self.spn_tic_size, 2, 1)

        self.chk_boundary_box = QCheckBox("Draw Outer Bounding Box Collar")
        self.chk_boundary_box.setChecked(True)
        s_layout.addWidget(self.chk_boundary_box, 2, 2, 1, 2)

        layout.addWidget(gb_style)

        # Coordinate Annotation & Collar Suffixes
        gb_ann = QGroupBox("Collar Coordinate Labels & Suffixes")
        a_layout = QGridLayout(gb_ann)
        a_layout.setVerticalSpacing(8)

        a_layout.addWidget(QLabel("Easting Suffix:"), 0, 0)
        self.txt_e_suffix = QLineEdit("m E")
        a_layout.addWidget(self.txt_e_suffix, 0, 1)

        a_layout.addWidget(QLabel("Northing Suffix:"), 0, 2)
        self.txt_n_suffix = QLineEdit("m N")
        a_layout.addWidget(self.txt_n_suffix, 0, 3)

        a_layout.addWidget(QLabel("Label Text Height:"), 1, 0)
        self.spn_txt_sz = QDoubleSpinBox()
        self.spn_txt_sz.setValue(8.0)
        self.spn_txt_sz.setRange(4.0, 40.0)
        a_layout.addWidget(self.spn_txt_sz, 1, 1)

        a_layout.addWidget(QLabel("Collar Margin Clearance:"), 1, 2)
        self.spn_clearance = QDoubleSpinBox()
        self.spn_clearance.setValue(20.0)
        self.spn_clearance.setRange(1.0, 500.0)
        a_layout.addWidget(self.spn_clearance, 1, 3)

        layout.addWidget(gb_ann)
        layout.addStretch()

        # Action Button
        act_row = QHBoxLayout()
        self.btn_generate = QPushButton("Generate Survey Grid in QGIS")
        self.btn_generate.setStyleSheet("background-color: #2e7d32; color: white; font-weight: bold; padding: 8px 20px;")
        self.btn_generate.clicked.connect(self._generate_grid)

        act_row.addStretch()
        act_row.addWidget(self.btn_generate)
        layout.addLayout(act_row)

    def _get_canvas_extent(self):
        if HAS_QGIS and self.iface:
            ext = self.iface.mapCanvas().extent()
            self.txt_x1.setText(f"{ext.xMinimum():.2f}")
            self.txt_y1.setText(f"{ext.yMinimum():.2f}")
            self.txt_x2.setText(f"{ext.xMaximum():.2f}")
            self.txt_y2.setText(f"{ext.yMaximum():.2f}")

    def _get_layer_extent(self):
        if HAS_QGIS and self.iface:
            layer = self.iface.activeLayer()
            if layer:
                ext = layer.extent()
                self.txt_x1.setText(f"{ext.xMinimum():.2f}")
                self.txt_y1.setText(f"{ext.yMinimum():.2f}")
                self.txt_x2.setText(f"{ext.xMaximum():.2f}")
                self.txt_y2.setText(f"{ext.yMaximum():.2f}")

    def _generate_grid(self):
        try:
            x1 = float(self.txt_x1.text())
            y1 = float(self.txt_y1.text())
            x2 = float(self.txt_x2.text())
            y2 = float(self.txt_y2.text())
        except ValueError:
            QMessageBox.critical(self, "Invalid Inputs", "Please enter valid bounding coordinates.")
            return

        res = SurveyGridGenerator.generate_grid(
            x1=x1,
            y1=y1,
            x2=x2,
            y2=y2,
            interval_x=self.spn_int_x.value(),
            interval_y=self.spn_int_y.value(),
            draw_ticks=self.rb_ticks.isChecked(),
            tic_size=self.spn_tic_size.value(),
            easting_suffix=self.txt_e_suffix.text(),
            northing_suffix=self.txt_n_suffix.text(),
            text_clearance=self.spn_clearance.value()
        )

        if not HAS_QGIS or not self.iface:
            QMessageBox.information(
                self, "Grid Generated",
                f"Grid lines: {len(res.grid_lines_wkt) or len(res.tic_marks_wkt)}\n"
                f"Annotations: {len(res.annotations)}"
            )
            return

        crs_str = self.iface.mapCanvas().mapSettings().destinationCrs().authid() or "EPSG:3124"
        proj = QgsProject.instance()

        # 1. Grid Lines / Tic Marks Layer
        elem_name = "Grid Tics" if self.rb_ticks.isChecked() else "Grid Lines"
        grid_layer = QgsVectorLayer(f"LineString?crs={crs_str}", f"GeoCad - {elem_name}", "memory")
        pr = grid_layer.dataProvider()
        feats = []
        wkt_list = res.tic_marks_wkt if self.rb_ticks.isChecked() else res.grid_lines_wkt
        for wkt in wkt_list:
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromWkt(wkt))
            feats.append(f)
        pr.addFeatures(feats)
        grid_layer.updateExtents()
        proj.addMapLayer(grid_layer)

        # 2. Bounding Box Collar Layer (if checked)
        if self.chk_boundary_box.isChecked() and res.bounding_box_wkt:
            box_layer = QgsVectorLayer(f"Polygon?crs={crs_str}", "GeoCad - Grid Boundary Collar", "memory")
            bpr = box_layer.dataProvider()
            bf = QgsFeature()
            bf.setGeometry(QgsGeometry.fromWkt(res.bounding_box_wkt))
            bpr.addFeature(bf)
            box_layer.updateExtents()
            proj.addMapLayer(box_layer)

        # 3. Collar Coordinate Annotations Layer
        ann_layer = QgsVectorLayer(f"Point?crs={crs_str}", "GeoCad - Collar Coordinates", "memory")
        apr = ann_layer.dataProvider()
        apr.addAttributes([
            make_qgs_field("Coord_Text", "string"),
            make_qgs_field("Border_Side", "string"),
        ])
        ann_layer.updateFields()

        ann_feats = []
        for ann in res.annotations:
            af = QgsFeature()
            af.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ann.x, ann.y)))
            af.setAttributes([ann.text, ann.side])
            ann_feats.append(af)

        apr.addFeatures(ann_feats)
        ann_layer.updateExtents()

        # Labeling
        settings = QgsPalLayerSettings()
        settings.fieldName = "Coord_Text"
        set_label_placement(settings, "OverPoint")
        text_format = QgsTextFormat()
        text_format.setSize(self.spn_txt_sz.value())
        buffer = QgsTextBufferSettings()
        buffer.setEnabled(True)
        buffer.setSize(1)
        text_format.setBuffer(buffer)
        settings.setFormat(text_format)
        ann_layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        ann_layer.setLabelsEnabled(True)

        proj.addMapLayer(ann_layer)

        QMessageBox.information(
            self,
            "Grid Generated",
            f"Successfully generated survey grid in QGIS!\n"
            f"Interval: {res.interval_x:.1f} m x {res.interval_y:.1f} m\n"
            f"Grid elements: {len(wkt_list)}\n"
            f"Collar coordinate labels: {len(res.annotations)}"
        )

