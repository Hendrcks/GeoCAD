"""
GeoCad Processing Algorithm: Plot Survey Points & Sequential Lines.
Ingests raw survey coordinate files and connects sequential boundary strings.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.core import (
        QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFile,
        QgsProcessingParameterEnum, QgsProcessingParameterBoolean,
        QgsProcessingParameterCrs, QgsProcessingParameterFeatureSink,
        QgsFeature, QgsGeometry, QgsPoint, QgsFields, QgsField, QgsWkbTypes
    )
    from qgis.PyQt.QtCore import QVariant
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm: pass

from ..core.compat import make_qgs_field
from ..core.point_plotter import PointPlotter


class PlotPointsAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to plot coordinate points."""

    INPUT_FILE = "INPUT_FILE"
    PROFILE = "PROFILE"
    SEQUENTIAL = "SEQUENTIAL"
    CRS = "CRS"
    OUTPUT_POINTS = "OUTPUT_POINTS"

    def createInstance(self):
        return PlotPointsAlgorithm()

    def name(self):
        return "plot_points"

    def displayName(self):
        return "Plot Survey Points (NEZL / KDMS)"

    def group(self):
        return "Point Ingestion"

    def groupId(self):
        return "points"

    def shortHelpString(self):
        return "Plots coordinate points from ASCII/CSV survey data with optional sequential line connection."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterFile(self.INPUT_FILE, "Survey Coordinate File", extension="csv"))
        self.addParameter(QgsProcessingParameterEnum(self.PROFILE, "Coordinate Format", options=PointPlotter.PROFILES, defaultValue=4))
        self.addParameter(QgsProcessingParameterBoolean(self.SEQUENTIAL, "Sequential Connection (seqline)", defaultValue=True))
        self.addParameter(QgsProcessingParameterCrs(self.CRS, "Target CRS", defaultValue="EPSG:3124"))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT_POINTS, "Survey Points Output", type=QgsProcessing.TypeVectorPoint))

    def processAlgorithm(self, parameters, context, feedback):
        file_path = self.parameterAsFile(parameters, self.INPUT_FILE, context)
        profile_idx = self.parameterAsEnum(parameters, self.PROFILE, context)
        profile = PointPlotter.PROFILES[profile_idx]
        seq = self.parameterAsBoolean(parameters, self.SEQUENTIAL, context)
        crs = self.parameterAsCrs(parameters, self.CRS, context)

        res = PointPlotter.parse_file(file_path, profile=profile, enable_sequential_lines=seq)

        fields = QgsFields()
        fields.append(make_qgs_field("Point_ID", "string"))
        fields.append(make_qgs_field("Easting", "double"))
        fields.append(make_qgs_field("Northing", "double"))
        fields.append(make_qgs_field("Elevation", "double"))
        fields.append(make_qgs_field("Label", "string"))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_POINTS, context, fields, QgsWkbTypes.PointZ, crs
        )

        for p in res.points:
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPoint(QgsPoint(p.easting, p.northing, p.elevation)))
            f.setAttributes([p.point_id, p.easting, p.northing, p.elevation, p.label])
            sink.addFeature(f)

        return {self.OUTPUT_POINTS: dest_id}

