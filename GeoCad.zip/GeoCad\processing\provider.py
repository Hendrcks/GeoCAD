"""
GeoCad QGIS Processing Provider.
Registers the GeoCad cadastral, surveying, and terrain algorithm suite.
"""

import os
from typing import List

try:
    from qgis.core import QgsProcessingProvider
    from qgis.PyQt.QtGui import QIcon
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingProvider: pass

from .alg_plot_traverse import PlotTraverseAlgorithm
from .alg_plot_points import PlotPointsAlgorithm
from .alg_measure_bearing_dist import AnnotateBearingDistanceAlgorithm
from .alg_create_grid import CreateSurveyGridAlgorithm
from .alg_create_tin import BuildTinAlgorithm
from .alg_create_contours import CreateContoursAlgorithm


class GeoCadProcessingProvider(QgsProcessingProvider):
    """Processing provider for GeoCad Land Surveying & Cadastral suite."""

    def loadAlgorithms(self):
        """Loads and registers all GeoCad Processing algorithms."""
        self.addAlgorithm(PlotTraverseAlgorithm())
        self.addAlgorithm(PlotPointsAlgorithm())
        self.addAlgorithm(AnnotateBearingDistanceAlgorithm())
        self.addAlgorithm(CreateSurveyGridAlgorithm())
        self.addAlgorithm(BuildTinAlgorithm())
        self.addAlgorithm(CreateContoursAlgorithm())

    def id(self):
        return "geocad"

    def name(self):
        return "GeoCad"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        if HAS_QGIS and os.path.exists(icon_path):
            return QIcon(icon_path)
        return QIcon()
