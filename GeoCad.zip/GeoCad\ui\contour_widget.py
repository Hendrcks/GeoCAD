"""
GeoCad - Topographic Contour Generation, Smoothing, and Tinting Widget.
Extracts contour lines from TIN surfaces, applies cubic spline smoothing (smocont),
and formats Index and Intermediate contours with hypsometric tinting (ezy9).

Developed by GeoCad (geocad@example.com).
"""

import math
from typing import Optional, List

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox,
        QPushButton, QMessageBox, QTextEdit
    )
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
        QgsField, QgsWkbTypes, QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
        QgsTextFormat, QgsTextBufferSettings, QgsSingleSymbolRenderer,
        QgsLineSymbol, QgsMapLayerProxyModel
    )
    from qgis.gui import QgsMapLayerComboBox
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox,
        QPushButton, QMessageBox, QTextEdit
    )
    HAS_QGIS = False

from ..core.compat import make_qgs_field, set_label_placement
from ..core.contour_engine import ContourEngine, ContourResult, ContourLine
from ..core.tin_engine import TinEngine, TinTriangle


class ContourWidget(QWidget):
    """UI for generating, smoothing, and styling topographic contours in QGIS."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.last_result: Optional[ContourResult] = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # Source TIN Layer
        gb_src = QGroupBox("Terrain Surface Source (TIN / Point Mesh)")
        s_layout = QHBoxLayout(gb_src)
        s_layout.addWidget(QLabel("Surface Layer:"))
        if HAS_QGIS:
            self.cmb_tin_layer = QgsMapLayerComboBox()
            self.cmb_tin_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer | QgsMapLayerProxyModel.PointLayer)
        else:
            self.cmb_tin_layer = QComboBox()

        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.clicked.connect(self._refresh_layers)

        s_layout.addWidget(self.cmb_tin_layer, stretch=1)
        s_layout.addWidget(self.btn_refresh)
        layout.addWidget(gb_src)

        # Contour Intervals & Classification
        gb_intervals = QGroupBox("Contour Intervals & Index Contours")
        i_layout = QGridLayout(gb_intervals)
        i_layout.setVerticalSpacing(8)

        i_layout.addWidget(QLabel("Contour Interval dz (m):"), 0, 0)
        self.spn_interval = QDoubleSpinBox()
        self.spn_interval.setValue(2.0)
        self.spn_interval.setRange(0.1, 500.0)
        i_layout.addWidget(self.spn_interval, 0, 1)

        i_layout.addWidget(QLabel("Base Datum Elevation (m):"), 0, 2)
        self.spn_base_z = QDoubleSpinBox()
        self.spn_base_z.setValue(0.0)
        self.spn_base_z.setRange(-1000.0, 10000.0)
        i_layout.addWidget(self.spn_base_z, 0, 3)

        i_layout.addWidget(QLabel("Index Contour Multiplier:"), 1, 0)
        self.spn_index_mult = QSpinBox()
        self.spn_index_mult.setValue(5)
        self.spn_index_mult.setRange(1, 20)
        i_layout.addWidget(self.spn_index_mult, 1, 1)

        self.chk_label_index = QCheckBox("Label Index Contours with Elevations")
        self.chk_label_index.setChecked(True)
        i_layout.addWidget(self.chk_label_index, 1, 2, 1, 2)

        layout.addWidget(gb_intervals)

        # Smoothing & Hypsometric Tinting
        gb_style = QGroupBox("Contour Smoothing (smocont) & Hypsometric Tinting (ezy9)")
        t_layout = QGridLayout(gb_style)
        t_layout.setVerticalSpacing(8)

        self.chk_smooth = QCheckBox("Apply Cubic Spline Smoothing (smocont)")
        self.chk_smooth.setChecked(True)
        t_layout.addWidget(self.chk_smooth, 0, 0, 1, 2)

        t_layout.addWidget(QLabel("Smoothing Passes:"), 0, 2)
        self.spn_smooth_iter = QSpinBox()
        self.spn_smooth_iter.setValue(2)
        self.spn_smooth_iter.setRange(1, 4)
        t_layout.addWidget(self.spn_smooth_iter, 0, 3)

        self.chk_tinting = QCheckBox("Apply 6-Zone Hypsometric Color Tinting (ezy9)")
        self.chk_tinting.setChecked(True)
        t_layout.addWidget(self.chk_tinting, 1, 0, 1, 4)

        layout.addWidget(gb_style)

        # Diagnostics Log
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setPlaceholderText("Contour statistics, intervals, and line counts will appear here...")
        layout.addWidget(self.txt_log, stretch=1)

        # Action Button
        act_row = QHBoxLayout()
        self.btn_generate = QPushButton("Generate Topographic Contours in QGIS")
        self.btn_generate.setStyleSheet("background-color: #2e7d32; color: white; font-weight: bold; padding: 8px 20px;")
        self.btn_generate.clicked.connect(self._generate_contours)

        act_row.addStretch()
        act_row.addWidget(self.btn_generate)
        layout.addLayout(act_row)

        self._refresh_layers()

    def _refresh_layers(self):
        """Refreshes available polygon and point layers from QgsProject."""
        if not HAS_QGIS:
            self.cmb_tin_layer.clear()
            self.cmb_tin_layer.addItem("Sample TIN Surface (Standalone)")
            return

        if isinstance(self.cmb_tin_layer, QgsMapLayerComboBox):
            self.cmb_tin_layer.setProject(QgsProject.instance())
            self.cmb_tin_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer | QgsMapLayerProxyModel.PointLayer)
        else:
            self.cmb_tin_layer.clear()
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer) and layer.geometryType() in (QgsWkbTypes.PolygonGeometry, QgsWkbTypes.PointGeometry):
                    self.cmb_tin_layer.addItem(layer.name(), layer.id())

    def _generate_contours(self):
        triangles: List[TinTriangle] = []
        layer = None

        if not HAS_QGIS or not self.iface:
            # Generate synthetic dome terrain for standalone test
            import random
            pts = []
            for i in range(12):
                for j in range(12):
                    x = 484000.0 + (i * 80.0)
                    y = 1548000.0 + (j * 80.0)
                    dist = math.hypot(x - 484480.0, y - 1548480.0)
                    z = max(10.0, 150.0 - (dist * 0.25) + random.uniform(-2, 2))
                    pts.append((x, y, z))
            triangles, _ = TinEngine.build_tin(pts)
        else:
            if hasattr(self.cmb_tin_layer, 'currentLayer'):
                layer = self.cmb_tin_layer.currentLayer()
            elif hasattr(self.cmb_tin_layer, 'currentData'):
                layer_id = self.cmb_tin_layer.currentData()
                layer = QgsProject.instance().mapLayer(layer_id)

            if not layer or not isinstance(layer, QgsVectorLayer):
                QMessageBox.warning(self, "Contours", "Please select a valid surface layer.")
                return

            if layer.geometryType() == QgsWkbTypes.PolygonGeometry:
                # Read TIN 3D triangles from PolygonZ features
                tid = 1
                for feat in layer.getFeatures():
                    geom = feat.geometry()
                    if not geom or geom.isEmpty():
                        continue
                    poly = geom.asPolygon()
                    if poly and len(poly[0]) >= 4:
                        ring = poly[0]
                        v1 = (ring[0].x(), ring[0].y(), ring[0].z() if hasattr(ring[0], 'z') else 0.0)
                        v2 = (ring[1].x(), ring[1].y(), ring[1].z() if hasattr(ring[1], 'z') else 0.0)
                        v3 = (ring[2].x(), ring[2].y(), ring[2].z() if hasattr(ring[2], 'z') else 0.0)
                        triangles.append(TinTriangle(id=tid, v1=v1, v2=v2, v3=v3))
                        tid += 1
            else:
                # Point layer -> build TIN on the fly
                pts = []
                for feat in layer.getFeatures():
                    geom = feat.geometry()
                    if geom and not geom.isEmpty():
                        p = geom.asPoint()
                        z = geom.constGet().z() if geom.constGet().is3D() else 0.0
                        pts.append((p.x(), p.y(), z))
                triangles, _ = TinEngine.build_tin(pts)

        if not triangles:
            QMessageBox.warning(self, "Contours", "No valid 3D surface geometry could be extracted.")
            return

        dz = self.spn_interval.value()
        z0 = self.spn_base_z.value()
        m_mult = self.spn_index_mult.value()
        smooth = self.chk_smooth.isChecked()
        s_iter = self.spn_smooth_iter.value()

        res = ContourEngine.generate_contours(
            triangles=triangles,
            interval=dz,
            base_elevation=z0,
            index_multiplier=m_mult,
            smooth=smooth,
            smooth_iterations=s_iter
        )
        self.last_result = res

        log_lines = [
            f"=== GeoCad Topographic Contour Extraction ===",
            f"Surface Elevation Range: {res.min_elevation:.2f} m to {res.max_elevation:.2f} m",
            f"Contour Interval: {dz:.2f} m (Base: {z0:.2f} m)",
            f"Index Multiplier: Every {m_mult} contours",
            f"Total Contours Generated: {len(res.contours)}",
            f"• Index (Major) Contours: {len(res.index_contours)}",
            f"• Intermediate (Minor) Contours: {len(res.intermediate_contours)}",
            f"Cubic Spline Smoothing (smocont): {'Active' if smooth else 'Disabled'}",
        ]
        self.txt_log.setPlainText("\n".join(log_lines))

        if not HAS_QGIS or not self.iface:
            QMessageBox.information(self, "Contours Generated", f"Generated {len(res.contours)} contour lines.")
            return

        # Add to QGIS Project
        crs_str = layer.crs().authid() if layer else "EPSG:3124"
        c_layer = QgsVectorLayer(f"LineString?crs={crs_str}", "GeoCad - Topographic Contours", "memory")
        pr = c_layer.dataProvider()
        pr.addAttributes([
            make_qgs_field("Contour_ID", "int"),
            make_qgs_field("Elevation", "double", 10, 2),
            make_qgs_field("Level_Type", "string"),
            make_qgs_field("Length_m", "double", 10, 2),
            make_qgs_field("Color_Hex", "string"),
        ])
        c_layer.updateFields()

        feats = []
        for c in res.contours:
            qpts = [QgsPointXY(pt[0], pt[1]) for pt in c.coordinates]
            geom = QgsGeometry.fromPolylineXY(qpts)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([c.id, c.elevation, c.level_type, c.length, c.color_hex])
            feats.append(f)

        pr.addFeatures(feats)
        c_layer.updateExtents()

        # Labeling (on Index Contours)
        if self.chk_label_index.isChecked():
            settings = QgsPalLayerSettings()
            settings.fieldName = "Elevation"
            set_label_placement(settings, "Line")
            text_format = QgsTextFormat()
            text_format.setSize(8)
            buffer = QgsTextBufferSettings()
            buffer.setEnabled(True)
            buffer.setSize(1)
            text_format.setBuffer(buffer)
            settings.setFormat(text_format)
            settings.filterExpression = "\"Level_Type\" = 'Index'"
            c_layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            c_layer.setLabelsEnabled(True)

        QgsProject.instance().addMapLayer(c_layer)

        QMessageBox.information(
            self,
            "Contouring Complete",
            f"Successfully generated {len(res.contours)} topographic contours!\n"
            f"Index Contours: {len(res.index_contours)}\n"
            f"Intermediate Contours: {len(res.intermediate_contours)}"
        )
