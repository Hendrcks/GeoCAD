"""
GeoCad - Boundary Bearing and Distance Annotation Widget.
Implements the 8 placement configurations (LR, RL, LL, RR, BL, BR, DL, DR)
for annotating cadastral boundaries in Meters or Feet with auto-readability text flipping.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QComboBox, QCheckBox, QDoubleSpinBox, QSpinBox,
        QPushButton, QMessageBox, QTextEdit
    )
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
        QgsField, QgsWkbTypes, QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
        QgsTextFormat, QgsTextBufferSettings, QgsMapLayerProxyModel
    )
    from qgis.gui import QgsMapLayerComboBox
    HAS_QGIS = True
except ImportError:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox,
        QLabel, QComboBox, QCheckBox, QDoubleSpinBox, QSpinBox,
        QPushButton, QMessageBox, QTextEdit
    )
    HAS_QGIS = False

from ..core.compat import make_qgs_field, set_label_placement
from ..core.bearing_distance_annotator import BearingDistanceAnnotator


class BearingDistanceWidget(QWidget):
    """UI for annotating existing vector linework with surveyor bearings and distances."""

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # Layer Selection Group
        gb_layer = QGroupBox("Target Linework / Polygon Layer")
        l_layout = QHBoxLayout(gb_layer)
        l_layout.addWidget(QLabel("Select Layer:"))
        if HAS_QGIS:
            self.cmb_layers = QgsMapLayerComboBox()
            self.cmb_layers.setFilters(QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer)
        else:
            self.cmb_layers = QComboBox()

        self.btn_refresh_layers = QPushButton("Refresh")
        self.btn_refresh_layers.clicked.connect(self._refresh_layers)

        l_layout.addWidget(self.cmb_layers, stretch=1)
        l_layout.addWidget(self.btn_refresh_layers)
        layout.addWidget(gb_layer)

        # Annotation Settings Group
        gb_settings = QGroupBox("Surveyor Bearing & Distance Placement Settings")
        s_layout = QGridLayout(gb_settings)
        s_layout.setVerticalSpacing(8)

        # Format Keyword Mode
        s_layout.addWidget(QLabel("Placement Mode:"), 0, 0)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItem("LR — Bearing Left / Distance Right", "LR")
        self.cmb_mode.addItem("RL — Bearing Right / Distance Left", "RL")
        self.cmb_mode.addItem("LL — Combined Bearing-Distance on Left", "LL")
        self.cmb_mode.addItem("RR — Combined Bearing-Distance on Right", "RR")
        self.cmb_mode.addItem("BL — Bearing Only on Left", "BL")
        self.cmb_mode.addItem("BR — Bearing Only on Right", "BR")
        self.cmb_mode.addItem("DL — Distance Only on Left", "DL")
        self.cmb_mode.addItem("DR — Distance Only on Right", "DR")
        s_layout.addWidget(self.cmb_mode, 0, 1)

        # Units
        s_layout.addWidget(QLabel("Distance Unit:"), 0, 2)
        self.cmb_unit = QComboBox()
        self.cmb_unit.addItem("Meters (m)", BearingDistanceAnnotator.UNITS_METERS)
        self.cmb_unit.addItem("Feet (')", BearingDistanceAnnotator.UNITS_FEET)
        s_layout.addWidget(self.cmb_unit, 0, 3)

        # Reverse Direction
        self.chk_reverse = QCheckBox("Reverse Bearing Direction (Back-Azimuth)")
        self.chk_reverse.setChecked(False)
        s_layout.addWidget(self.chk_reverse, 1, 0, 1, 2)

        # Flip for Readability
        self.chk_flip = QCheckBox("Automatic Text Flipping (Prevents upside-down text)")
        self.chk_flip.setChecked(True)
        s_layout.addWidget(self.chk_flip, 1, 2, 1, 2)

        # Text Height & Offset
        s_layout.addWidget(QLabel("Text Height (map units):"), 2, 0)
        self.spn_txt_height = QDoubleSpinBox()
        self.spn_txt_height.setValue(2.5)
        self.spn_txt_height.setRange(0.1, 100.0)
        s_layout.addWidget(self.spn_txt_height, 2, 1)

        s_layout.addWidget(QLabel("Offset Factor:"), 2, 2)
        self.spn_offset_fac = QDoubleSpinBox()
        self.spn_offset_fac.setValue(1.125)
        self.spn_offset_fac.setRange(0.5, 10.0)
        s_layout.addWidget(self.spn_offset_fac, 2, 3)

        # Distance Decimal Precision
        s_layout.addWidget(QLabel("Distance Decimals:"), 3, 0)
        self.spn_dist_dec = QSpinBox()
        self.spn_dist_dec.setValue(2)
        self.spn_dist_dec.setRange(0, 4)
        s_layout.addWidget(self.spn_dist_dec, 3, 1)

        layout.addWidget(gb_settings)

        # Log & Action
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setPlaceholderText("Annotation metrics and segment details will be logged here...")
        self.txt_log.setMaximumHeight(140)
        layout.addWidget(self.txt_log)

        act_layout = QHBoxLayout()
        self.btn_annotate = QPushButton("Annotate Layer with Bearings & Distances")
        self.btn_annotate.setStyleSheet("background-color: #2e7d32; color: white; font-weight: bold; padding: 7px 18px;")
        self.btn_annotate.clicked.connect(self._run_annotation)

        act_layout.addStretch()
        act_layout.addWidget(self.btn_annotate)
        layout.addLayout(act_layout)

        self._refresh_layers()

    def _refresh_layers(self):
        """Refreshes available line and polygon layers from QgsProject."""
        if not HAS_QGIS:
            self.cmb_layers.clear()
            self.cmb_layers.addItem("Sample Line Layer (Standalone)")
            return

        if isinstance(self.cmb_layers, QgsMapLayerComboBox):
            self.cmb_layers.setProject(QgsProject.instance())
            self.cmb_layers.setFilters(QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer)
        else:
            self.cmb_layers.clear()
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer) and layer.geometryType() in (QgsWkbTypes.LineGeometry, QgsWkbTypes.PolygonGeometry):
                    self.cmb_layers.addItem(layer.name(), layer.id())

    def _run_annotation(self):
        if not HAS_QGIS or not self.iface:
            QMessageBox.information(self, "GeoCad Bearing & Distance", "Annotation executed in standalone mode.")
            return

        layer = None
        if isinstance(self.cmb_layers, QgsMapLayerComboBox):
            layer = self.cmb_layers.currentLayer()
        elif hasattr(self.cmb_layers, 'currentData'):
            layer_id = self.cmb_layers.currentData()
            layer = QgsProject.instance().mapLayer(layer_id)

        if not layer or not isinstance(layer, QgsVectorLayer):
            QMessageBox.warning(self, "No Layer", "Please select a valid linework or polygon layer.")
            return

        mode = self.cmb_mode.currentData()
        unit = self.cmb_unit.currentData()
        reverse = self.chk_reverse.isChecked()
        th = self.spn_txt_height.value()
        fac = self.spn_offset_fac.value()
        prec = self.spn_dist_dec.value()

        # Extract segments from all features
        all_segments = []
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]

            for line in lines:
                for i in range(len(line) - 1):
                    p1 = (line[i].x(), line[i].y())
                    p2 = (line[i+1].x(), line[i+1].y())
                    ann = BearingDistanceAnnotator.annotate_segment(
                        p1, p2,
                        mode=mode,
                        unit=unit,
                        reverse_direction=reverse,
                        text_height=th,
                        offset_multiplier=fac,
                        precision_dist=prec,
                        segment_id=len(all_segments) + 1
                    )
                    if ann:
                        all_segments.append(ann)

        if not all_segments:
            QMessageBox.warning(self, "Empty", "No valid line segments found in the selected layer.")
            return

        # Create Annotation Output Layer (Points Layer with rotated text)
        crs_str = layer.crs().authid()
        ann_layer = QgsVectorLayer(f"Point?crs={crs_str}", f"{layer.name()} - Bearings & Distances", "memory")
        pr = ann_layer.dataProvider()
        pr.addAttributes([
            make_qgs_field("Seg_ID", "int"),
            make_qgs_field("Bearing", "string"),
            make_qgs_field("Distance", "string"),
            make_qgs_field("Text_Left", "string"),
            make_qgs_field("Text_Right", "string"),
            make_qgs_field("Combined", "string"),
            make_qgs_field("Rotation", "double", 6, 2),
        ])
        ann_layer.updateFields()

        feats = []
        for ann in all_segments:
            pt_geom = QgsGeometry.fromPointXY(QgsPointXY(ann.midpoint[0], ann.midpoint[1]))
            f = QgsFeature()
            f.setGeometry(pt_geom)
            comb = f"{ann.bearing_str} | {ann.distance_str}"
            f.setAttributes([
                ann.segment_id,
                ann.bearing_str,
                ann.distance_str,
                ann.text_left,
                ann.text_right,
                comb,
                ann.text_angle_deg
            ])
            feats.append(f)

        pr.addFeatures(feats)
        ann_layer.updateExtents()

        # Apply Labeling with rotation
        settings = QgsPalLayerSettings()
        settings.fieldName = "Combined"
        set_label_placement(settings, "OverPoint")
        text_format = QgsTextFormat()
        text_format.setSize(9)
        buffer = QgsTextBufferSettings()
        buffer.setEnabled(True)
        buffer.setSize(1)
        text_format.setBuffer(buffer)
        settings.setFormat(text_format)
        ann_layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        ann_layer.setLabelsEnabled(True)

        QgsProject.instance().addMapLayer(ann_layer)

        # Log
        log_text = [
            f"=== GeoCad Bearing & Distance Annotation ===",
            f"Target Layer: {layer.name()}",
            f"Total Segments Annotated: {len(all_segments)}",
            f"Placement Mode: {mode}",
            f"Unit: {unit}",
            f"Reverse Vector: {reverse}",
            f"Annotation Layer Created: {ann_layer.name()}"
        ]
        self.txt_log.setPlainText("\n".join(log_text))

        QMessageBox.information(
            self,
            "Annotation Complete",
            f"Annotated {len(all_segments)} line segments with bearings and distances!"
        )
