"""
GeoCad - Bearing and Angle Parsing Engine.
Supports cadastral quadrant bearings, decimal azimuths, DMS representations,
and coordinate departures/latitudes.

Developed by GeoCad (geocad@example.com).
"""

import math
import re
from typing import Optional, Tuple


class BearingParser:
    """Robust parser and formatter for surveyor bearings and azimuths."""

    # Regex pattern to match cadastral quadrant bearings like:
    # N 28°38' E, N.28-38E., S 88°56' E, S16*35' W, S 30-20-15 W, N 65 06 W
    QUADRANT_PATTERN = re.compile(
        r'^\s*([NSns])[\.\s]*'                       # North or South prefix
        r'([0-9]{1,3})'                              # Degrees
        r'(?:[\s°\*dD\-\.]+([0-9]{1,2}))?'           # Minutes (optional)
        r'(?:[\s\'\-\.]+([0-9]{1,2}(?:\.[0-9]+)?))?' # Seconds (optional)
        r'[\s\"\'\.]*([EWew])[\.\s]*$',              # East or West suffix
        re.IGNORECASE
    )

    @classmethod
    def parse_to_azimuth(cls, raw: str) -> Optional[float]:
        """Parses a bearing or azimuth string into whole-circle azimuth degrees (0 <= az < 360).

        Clockwise from North (0° = North, 90° = East, 180° = South, 270° = West).
        Returns None if parsing fails.
        """
        if raw is None:
            return None
        text = str(raw).strip()
        if not text:
            return None

        # Clean common OCR artifacts
        cleaned = text.strip()
        # Replace double V with W
        cleaned = re.sub(r'VV|vv', 'W', cleaned)
        # Normalize underscores, semicolons to spaces
        cleaned = cleaned.replace('_', ' ').replace(';', ' ')
        # Fix trailing periods
        cleaned = re.sub(r'\.+$', '', cleaned)

        # Check pure cardinal names
        upper = cleaned.upper().strip('.')
        if upper in ("N", "NORTH"):
            return 0.0
        if upper in ("E", "EAST"):
            return 90.0
        if upper in ("S", "SOUTH"):
            return 180.0
        if upper in ("W", "WEST"):
            return 270.0

        # Try parsing quadrant bearing: [N|S] Deg Min Sec [E|W]
        m = cls.QUADRANT_PATTERN.match(cleaned)
        if not m:
            # Try OCR letter substitution in bearing
            ocr_cand = re.match(r'^\s*([NSns])[\.\s_]*(.*?)[\.\s_]*([EWew]|VV|vv)[\.\s_]*$', cleaned)
            if ocr_cand:
                ns = ocr_cand.group(1).upper()
                mid = ocr_cand.group(2)
                ew = 'W' if ocr_cand.group(3).upper() in ('W', 'VV') else ocr_cand.group(3).upper()
                fixed_mid = re.sub(r'[oOD]', '0', mid)
                fixed_mid = re.sub(r'[lIi]', '1', fixed_mid)
                fixed_mid = re.sub(r'[zZ]', '2', fixed_mid)
                fixed_mid = re.sub(r'(?<=\d)[sS]|[sS](?=\d)', '5', fixed_mid)
                test_str = f"{ns} {fixed_mid} {ew}"
                m = cls.QUADRANT_PATTERN.match(test_str)

        if m:
            ns = m.group(1).upper()
            deg = float(m.group(2))
            minute = float(m.group(3)) if m.group(3) is not None else 0.0
            sec = float(m.group(4)) if m.group(4) is not None else 0.0
            ew = m.group(5).upper()

            angle = deg + (minute / 60.0) + (sec / 3600.0)
            if angle > 90.0001:
                return None  # Quadrant angles must be <= 90°

            if ns == 'N' and ew == 'E':
                azimuth = angle
            elif ns == 'S' and ew == 'E':
                azimuth = 180.0 - angle
            elif ns == 'S' and ew == 'W':
                azimuth = 180.0 + angle
            elif ns == 'N' and ew == 'W':
                azimuth = 360.0 - angle
            else:
                return None

            return azimuth % 360.0

        # Try parsing pure numeric azimuth (decimal degrees)
        # First clean out degree symbol
        cleaned = re.sub(r'[°\*dD]', '', text).strip()
        try:
            az = float(cleaned)
            return az % 360.0
        except ValueError:
            pass

        return None

    @classmethod
    def azimuth_to_quadrant(
        cls,
        azimuth: float,
        precision_seconds: int = 0,
        use_dms_symbols: bool = True,
        separator: str = " "
    ) -> str:
        """Converts an azimuth in degrees into standard surveyor quadrant notation.

        Example: 28.63333° -> 'N 28°38\' E'
        """
        az = float(azimuth) % 360.0

        # Exact cardinals
        if abs(az - 0.0) < 1e-7 or abs(az - 360.0) < 1e-7:
            return "North" if not use_dms_symbols else "N 00°00'00\" E"
        if abs(az - 90.0) < 1e-7:
            return "East" if not use_dms_symbols else "N 90°00'00\" E"
        if abs(az - 180.0) < 1e-7:
            return "South" if not use_dms_symbols else "S 00°00'00\" E"
        if abs(az - 270.0) < 1e-7:
            return "West" if not use_dms_symbols else "S 90°00'00\" W"

        if 0.0 <= az < 90.0:
            ns = "N"
            ew = "E"
            quad_angle = az
        elif 90.0 <= az < 180.0:
            ns = "S"
            ew = "E"
            quad_angle = 180.0 - az
        elif 180.0 <= az < 270.0:
            ns = "S"
            ew = "W"
            quad_angle = az - 180.0
        else:
            ns = "N"
            ew = "W"
            quad_angle = 360.0 - az

        # Decompose into deg, min, sec
        total_sec = round(quad_angle * 3600.0, precision_seconds)
        deg = int(total_sec // 3600)
        rem = total_sec - (deg * 3600)
        minutes = int(rem // 60)
        sec = rem - (minutes * 60)

        deg_sym = "°" if use_dms_symbols else "-"
        min_sym = "'" if use_dms_symbols else "-"
        sec_sym = '"' if use_dms_symbols else ""

        if precision_seconds > 0:
            sec_str = f"{sec:05.{precision_seconds}f}"
            angle_str = f"{deg:02d}{deg_sym}{minutes:02d}{min_sym}{sec_str}{sec_sym}"
        elif sec > 0:
            angle_str = f"{deg:02d}{deg_sym}{minutes:02d}{min_sym}{int(round(sec)):02d}{sec_sym}"
        else:
            angle_str = f"{deg:02d}{deg_sym}{minutes:02d}{min_sym}"

        if separator:
            return f"{ns}{separator}{angle_str}{separator}{ew}"
        return f"{ns}{angle_str}{ew}"

    @classmethod
    def reverse_azimuth(cls, azimuth: float) -> float:
        """Calculates back-azimuth (+180°)."""
        return (float(azimuth) + 180.0) % 360.0

    @classmethod
    def azimuth_to_cartesian_radians(cls, azimuth: float) -> float:
        """Converts survey azimuth (0°=N, clockwise) to CAD/Cartesian angle (0=E, counterclockwise)."""
        # theta = (90° - azimuth) in radians
        return math.radians((90.0 - float(azimuth)) % 360.0)

    @classmethod
    def cartesian_radians_to_azimuth(cls, theta_rad: float) -> float:
        """Converts CAD/Cartesian angle (radians) to survey azimuth (degrees)."""
        deg = math.degrees(theta_rad)
        return (90.0 - deg) % 360.0

    @classmethod
    def delta_en(cls, azimuth: float, distance: float) -> Tuple[float, float]:
        """Calculates Easting departure and Northing latitude.

        dE = dist * sin(azimuth)
        dN = dist * cos(azimuth)
        """
        az_rad = math.radians(float(azimuth))
        d_east = distance * math.sin(az_rad)
        d_north = distance * math.cos(az_rad)
        return (d_east, d_north)

    @classmethod
    def coordinates_to_azimuth_distance(
        cls,
        p1: Tuple[float, float],
        p2: Tuple[float, float]
    ) -> Tuple[float, float]:
        """Calculates survey azimuth (degrees) and horizontal distance between two (E, N) points."""
        d_east = p2[0] - p1[0]
        d_north = p2[1] - p1[1]
        dist = math.hypot(d_east, d_north)
        # Azimuth: atan2(dE, dN) in degrees
        az_deg = math.degrees(math.atan2(d_east, d_north))
        return (az_deg % 360.0, dist)

