"""
GeoCad Processing Algorithm: Create Survey Grid.
Generates coordinate grids, boundary collars, and collar callout annotations.

Developed by GeoCad (geocad@example.com).
"""

try:
    from qgis.core import (
        QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterExtent,
        QgsProcessingParameterNumber, QgsProcessingParameterBoolean,
        QgsProcessingParameterString, QgsProcessingParameterCrs,
        QgsProcessingParameterFeatureSink, QgsFeature, QgsGeometry,
        QgsFields, QgsField, QgsWkbTypes
    )
    from qgis.PyQt.QtCore import QVariant
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    class QgsProcessingAlgorithm: pass

from ..core.compat import make_qgs_field
from ..core.grid_generator import SurveyGridGenerator


class CreateSurveyGridAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to generate a survey grid."""

    EXTENT = "EXTENT"
    INTERVAL = "INTERVAL"
    TICKS = "TICKS"
    CRS = "CRS"
    OUTPUT_GRID = "OUTPUT_GRID"

    def createInstance(self):
        return CreateSurveyGridAlgorithm()

    def name(self):
        return "create_survey_grid"

    def displayName(self):
        return "Create Cartographic Survey Grid"

    def group(self):
        return "Survey Grid"

    def groupId(self):
        return "grid"

    def shortHelpString(self):
        return "Generates coordinate grid lines or tick marks across a bounding extent."

    def initAlgorithm(self, config=None):
        if not HAS_QGIS:
            return
        self.addParameter(QgsProcessingParameterExtent(self.EXTENT, "Grid Bounding Extents"))
        self.addParameter(QgsProcessingParameterNumber(self.INTERVAL, "Grid Spacing / Interval (m)", type=QgsProcessingParameterNumber.Double, defaultValue=100.0))
        self.addParameter(QgsProcessingParameterBoolean(self.TICKS, "Draw Cross Tic Marks Instead of Full Lines", defaultValue=False))
        self.addParameter(QgsProcessingParameterCrs(self.CRS, "Grid CRS", defaultValue="EPSG:3124"))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT_GRID, "Grid Linework Output", type=QgsProcessing.TypeVectorLine))

    def processAlgorithm(self, parameters, context, feedback):
        extent = self.parameterAsExtent(parameters, self.EXTENT, context)
        interval = self.parameterAsDouble(parameters, self.INTERVAL, context)
        ticks = self.parameterAsBoolean(parameters, self.TICKS, context)
        crs = self.parameterAsCrs(parameters, self.CRS, context)

        res = SurveyGridGenerator.generate_grid(
            x1=extent.xMinimum(),
            y1=extent.yMinimum(),
            x2=extent.xMaximum(),
            y2=extent.yMaximum(),
            interval_x=interval,
            interval_y=interval,
            draw_ticks=ticks
        )

        fields = QgsFields()
        fields.append(make_qgs_field("Element", "string"))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT_GRID, context, fields, QgsWkbTypes.LineString, crs
        )

        wkt_list = res.tic_marks_wkt if ticks else res.grid_lines_wkt
        for wkt in wkt_list:
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromWkt(wkt))
            f.setAttributes(["Tic" if ticks else "GridLine"])
            sink.addFeature(f)

        return {self.OUTPUT_GRID: dest_id}

